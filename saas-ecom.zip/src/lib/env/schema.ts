import { z } from "zod";

/**
 * Environment contracts. Pure module (no `server-only`) so it can be unit tested.
 * Server code reads values through `@/lib/env/server`; browser code through
 * `@/lib/env/public`. Never add a secret to `publicEnvSchema`.
 */

const hostnameLike = z
  .string()
  .trim()
  .toLowerCase()
  .regex(
    /^(localhost|([a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?)(\.[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?)+)$/,
    "must be a bare hostname such as paliya.store or localhost (no scheme, port or path)",
  );

export const publicEnvSchema = z.object({
  NEXT_PUBLIC_SUPABASE_URL: z.url(),
  /** Supabase publishable (formerly "anon") key. Safe for the browser; RLS protects data. */
  NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY: z.string().min(20),
  /** Root domain that hosts the platform, e.g. `paliya.store`. Stores live at `{slug}.{root}`. */
  NEXT_PUBLIC_PLATFORM_ROOT_DOMAIN: hostnameLike,
  /** Full origin of the platform app for links in emails, e.g. https://paliya.store (defaults from root domain). */
  NEXT_PUBLIC_PLATFORM_URL: z.url().optional(),
});

export const serverEnvSchema = publicEnvSchema.extend({
  NODE_ENV: z.enum(["development", "test", "production"]).default("development"),
  /** Supabase secret (formerly "service_role") key. Server-only, bypasses RLS. */
  SUPABASE_SECRET_KEY: z.string().min(20),
  /**
   * Shared secret between the Cloudflare domain-router Worker and this app.
   * Used to verify the signed forwarded-host header. Optional until the Worker is deployed;
   * when unset, the app trusts only the literal Host header.
   */
  EDGE_SHARED_SECRET: z.string().min(32).optional(),
  LOG_LEVEL: z.enum(["debug", "info", "warn", "error"]).default("info"),
  /**
   * 32+ random chars. Root secret for HMAC-signed cart/session tokens and for encrypting
   * per-tenant payment credentials (keys are derived per purpose with HKDF; see lib/crypto.ts).
   */
  APP_SECRET: z.string().min(32),
  /** Bearer token required by /api/cron/* endpoints (Vercel Cron / Cloudflare Cron Triggers). */
  CRON_SECRET: z.string().min(24).optional(),
  /** Transactional email (Resend). When unset, emails are logged instead of sent. */
  RESEND_API_KEY: z.string().min(10).optional(),
  EMAIL_FROM: z.string().min(3).default("The Paliya <no-reply@example.com>"),
  /** Cloudflare for SaaS custom hostnames (Phase 11). Optional until custom domains go live. */
  CLOUDFLARE_API_TOKEN: z.string().min(20).optional(),
  CLOUDFLARE_ZONE_ID: z.string().min(10).optional(),
  /** CNAME target customers point custom domains at, e.g. stores.paliya.store */
  CUSTOM_DOMAIN_CNAME_TARGET: hostnameLike.optional(),
  /** Shiprocket API account (platform-level credentials; per-tenant pickup location). */
  SHIPROCKET_EMAIL: z.string().optional(),
  SHIPROCKET_PASSWORD: z.string().optional(),
});

export type PublicEnv = z.infer<typeof publicEnvSchema>;
export type ServerEnv = z.infer<typeof serverEnvSchema>;

export class EnvValidationError extends Error {
  constructor(public readonly issues: string[]) {
    super(`Invalid environment configuration:\n  - ${issues.join("\n  - ")}`);
    this.name = "EnvValidationError";
  }
}

export function parseEnv<S extends z.ZodType>(schema: S, source: Record<string, string | undefined>): z.infer<S> {
  // Treat empty strings as unset so `.optional()` behaves as expected with blank .env lines.
  const cleaned = Object.fromEntries(Object.entries(source).map(([k, v]) => [k, v === "" ? undefined : v]));
  const result = schema.safeParse(cleaned);
  if (!result.success) {
    // Report variable names and reasons only, never values.
    throw new EnvValidationError(result.error.issues.map((i) => `${i.path.join(".") || "(root)"}: ${i.message}`));
  }
  return result.data;
}
