import "server-only";
import { cache } from "react";
import { createSupabaseAdminClient } from "@/lib/supabase/admin";
import { logger } from "@/lib/observability/logger";
import type { ResolvedTenant, TenantDirectory, TenantStatus } from "./context";

/**
 * Hostname -> tenant directory (ADR-005). Reads ONLY verified, non-removed `domains` rows
 * with the secret-key client (the lookup must work for anonymous shoppers and for
 * suspended tenants, which RLS would hide). Returns just the fields routing needs.
 * Memoised per request; cross-request caching is added with Cache Components (ADR-010).
 */
const findByHost = cache(async (host: string): Promise<ResolvedTenant | null> => {
  const admin = createSupabaseAdminClient();
  const { data, error } = await admin
    .from("domains")
    .select("hostname, tenant_id, tenants!inner(id, slug, status, stores(name))")
    .eq("hostname", host)
    .eq("status", "verified")
    .maybeSingle();
  if (error) {
    logger.error("tenant_directory.lookup_failed", { host, error: error.message });
    return null;
  }
  if (!data) return null;

  const { data: primary } = await admin
    .from("domains")
    .select("hostname")
    .eq("tenant_id", data.tenant_id)
    .eq("is_primary", true)
    .eq("status", "verified")
    .maybeSingle();

  const tenant = data.tenants;
  const store = Array.isArray(tenant.stores) ? tenant.stores[0] : tenant.stores;
  return {
    tenantId: data.tenant_id,
    slug: tenant.slug,
    name: store?.name ?? tenant.slug,
    status: tenant.status as TenantStatus,
    host,
    primaryHost: primary?.hostname ?? host,
  };
});

export const tenantDirectory: TenantDirectory = { findByHost };
