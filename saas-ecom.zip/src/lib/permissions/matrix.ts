/**
 * Single source of truth for roles and permissions.
 * - The app uses `can()` for UI gating and server-side authorization.
 * - Phase 2 seeds `roles`, `permissions` and `role_permissions` from these constants,
 *   and RLS policies call `has_tenant_permission(tenant_id, key)` against those tables.
 * UI checks are convenience only; the server check + RLS are the real boundary.
 */

export const TENANT_PERMISSIONS = [
  "store.read",
  "catalog.read",
  "catalog.write",
  "inventory.read",
  "inventory.write",
  "orders.read",
  "orders.write",
  "orders.refund",
  "customers.read",
  "customers.write",
  "marketing.read",
  "marketing.write",
  "content.write",
  "theme.edit",
  "theme.publish",
  "reviews.moderate",
  "analytics.read",
  "settings.write",
  "payments.manage",
  "domains.manage",
  "members.manage",
  "billing.manage",
] as const;
export type TenantPermission = (typeof TENANT_PERMISSIONS)[number];

export const TENANT_ROLES = ["owner", "admin", "manager", "staff", "viewer"] as const;
export type TenantRole = (typeof TENANT_ROLES)[number];

const READ_ONLY: TenantPermission[] = [
  "store.read",
  "catalog.read",
  "inventory.read",
  "orders.read",
  "customers.read",
  "marketing.read",
  "analytics.read",
];

const STAFF: TenantPermission[] = [...READ_ONLY, "catalog.write", "inventory.write", "orders.write", "customers.write"];

const MANAGER: TenantPermission[] = [
  ...STAFF,
  "orders.refund",
  "marketing.write",
  "content.write",
  "theme.edit",
  "reviews.moderate",
];

const ADMIN: TenantPermission[] = [...MANAGER, "theme.publish", "settings.write", "payments.manage", "domains.manage", "members.manage"];

export const TENANT_ROLE_PERMISSIONS: Readonly<Record<TenantRole, ReadonlySet<TenantPermission>>> = {
  owner: new Set(TENANT_PERMISSIONS),
  admin: new Set(ADMIN),
  manager: new Set(MANAGER),
  staff: new Set(STAFF),
  viewer: new Set(READ_ONLY),
};

export const PLATFORM_PERMISSIONS = [
  "platform.tenants.read",
  "platform.tenants.manage",
  "platform.plans.manage",
  "platform.flags.manage",
  "platform.users.manage",
  "platform.audit.read",
  "platform.support.impersonate",
  "platform.settings.manage",
  "platform.usage.read",
] as const;
export type PlatformPermission = (typeof PLATFORM_PERMISSIONS)[number];

export const PLATFORM_ROLES = ["super_admin", "support", "finance"] as const;
export type PlatformRole = (typeof PLATFORM_ROLES)[number];

export const PLATFORM_ROLE_PERMISSIONS: Readonly<Record<PlatformRole, ReadonlySet<PlatformPermission>>> = {
  super_admin: new Set(PLATFORM_PERMISSIONS),
  support: new Set(["platform.tenants.read", "platform.audit.read", "platform.support.impersonate", "platform.usage.read"]),
  finance: new Set(["platform.tenants.read", "platform.plans.manage", "platform.usage.read"]),
};

export function tenantRoleCan(role: TenantRole, permission: TenantPermission): boolean {
  return TENANT_ROLE_PERMISSIONS[role].has(permission);
}

export function platformRoleCan(role: PlatformRole, permission: PlatformPermission): boolean {
  return PLATFORM_ROLE_PERMISSIONS[role].has(permission);
}
