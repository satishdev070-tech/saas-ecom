import Link from "next/link";
import type { ProductCardData } from "@/features/storefront/server/catalog";
import type { ProductCardSettings } from "@/features/theme/schema/tokens";
import { IMAGE_RATIOS } from "@/features/theme/schema/tokens";
import { paths } from "@/features/storefront/urls";
import { discountPercent } from "@/lib/money";
import { Price, Stars } from "./price";
import { StoreImage } from "./store-image";
import { QuickAdd } from "./quick-add";

export function ProductCard({ product, settings, priority = false }: { product: ProductCardData; settings: ProductCardSettings; priority?: boolean }) {
  const pct = discountPercent(product.priceMinor, product.compareAtMinor);
  const hasAlt = settings.secondImageOnHover && !!product.hoverImagePath;
  const badges: { label: string; cls: string }[] = [];
  if (settings.showBadges) {
    if (!product.inStock) badges.push({ label: "Sold out", cls: "sf-badge" });
    else if (pct) badges.push({ label: settings.showDiscountPercent ? `${pct}% off` : "Sale", cls: "sf-badge sf-badge-sale" });
    if (product.isNew) badges.push({ label: "New", cls: settings.badgeStyle === "filled" ? "sf-badge sf-badge-filled" : "sf-badge" });
    else if (product.isBestseller) badges.push({ label: "Bestseller", cls: "sf-badge" });
  }
  return (
    <article className={`sf-card group relative flex flex-col ${settings.textAlign === "center" ? "text-center" : ""}`}>
      <Link href={paths.product(product.slug)} className="block">
        <div className={`sf-card-media relative overflow-hidden ${hasAlt ? "sf-has-alt" : ""}`} style={{ aspectRatio: IMAGE_RATIOS[settings.imageRatio] }}>
          <StoreImage path={product.imagePath} alt={product.imageAlt || product.title} sizes="(min-width: 1024px) 25vw, 50vw" priority={priority} className="sf-img-main" />
          {hasAlt ? <StoreImage path={product.hoverImagePath} alt="" sizes="(min-width: 1024px) 25vw, 50vw" className="sf-img-alt" /> : null}
          {badges.length ? (
            <div className="absolute left-2 top-2 flex flex-col items-start gap-1">
              {badges.slice(0, 2).map((b) => (
                <span key={b.label} className={b.cls}>
                  {b.label}
                </span>
              ))}
            </div>
          ) : null}
        </div>
        <div className="mt-3 space-y-1">
          {product.brand ? <p className="sf-eyebrow">{product.brand}</p> : null}
          <h3 className="line-clamp-2 text-sm leading-snug">{product.title}</h3>
          <Price
            priceMinor={product.priceMinor}
            compareAtMinor={product.compareAtMinor}
            fromPrice={product.hasPriceRange}
            showCompare={settings.showComparePrice}
            showPercent={settings.showDiscountPercent && !settings.showBadges}
            size="sm"
          />
          {settings.showRating && product.ratingCount > 0 ? <Stars rating={product.ratingAvg} count={product.ratingCount} small /> : null}
        </div>
      </Link>
      {settings.showQuickAdd && product.singleVariantId && product.inStock ? (
        <div className="mt-2">
          <QuickAdd variantId={product.singleVariantId} label={`Add ${product.title} to cart`} />
        </div>
      ) : null}
    </article>
  );
}

export function ProductGrid({ products, settings, columns = 4, priorityCount = 0 }: { products: ProductCardData[]; settings: ProductCardSettings; columns?: number; priorityCount?: number }) {
  const cols = columns >= 4 ? "@[64rem]:grid-cols-4" : columns === 3 ? "@[64rem]:grid-cols-3" : "@[64rem]:grid-cols-2";
  return (
    <ul className={`grid grid-cols-2 gap-x-4 gap-y-8 @[48rem]:grid-cols-3 ${cols}`}>
      {products.map((p, i) => (
        <li key={p.id}>
          <ProductCard product={p} settings={settings} priority={i < priorityCount} />
        </li>
      ))}
    </ul>
  );
}

export function ProductRow({ products, settings }: { products: ProductCardData[]; settings: ProductCardSettings }) {
  return (
    <ul className="sf-scroll-row">
      {products.map((p) => (
        <li key={p.id} className="w-[44%] shrink-0 @[48rem]:w-[30%] @[64rem]:w-[23%]">
          <ProductCard product={p} settings={settings} />
        </li>
      ))}
    </ul>
  );
}
