"use client";

import Image from "next/image";
import { useActionState, useMemo, useRef, useState } from "react";
import { addToCartAction } from "@/features/cart/actions";
import { findVariant, initialSelection, isColourOption, isSizeOption, selectValue, stockLabel, valueState, type PdpOption, type PdpVariant, type Selection } from "@/features/storefront/variants";
import type { ProductMedia, SizeChart } from "@/features/storefront/server/catalog";
import { assetUrl } from "@/lib/storage/assets";
import { Price } from "./price";

function Gallery({ media, activePath, title }: { media: ProductMedia[]; activePath: string | null; title: string }) {
  const ordered = useMemo(() => {
    if (!activePath) return media;
    const first = media.find((m) => m.path === activePath);
    return first ? [first, ...media.filter((m) => m !== first)] : media;
  }, [media, activePath]);
  const [index, setIndex] = useState(0);
  const [zoom, setZoom] = useState<{ x: number; y: number } | null>(null);
  const dialog = useRef<HTMLDialogElement>(null);
  const current = ordered[Math.min(index, ordered.length - 1)];
  const src = current ? assetUrl(current.path) : null;
  return (
    <div className="flex flex-col-reverse gap-3 @[64rem]:flex-row">
      {ordered.length > 1 ? (
        <ul className="flex gap-2 overflow-x-auto @[64rem]:w-20 @[64rem]:flex-col" aria-label="Product images">
          {ordered.map((m, i) => {
            const u = assetUrl(m.path);
            return u ? (
              <li key={m.id} className="shrink-0">
                <button type="button" onClick={() => setIndex(i)} aria-label={`Show image ${i + 1}`} aria-current={i === index} className={`relative block aspect-[3/4] w-16 overflow-hidden border-2 @[64rem]:w-20 ${i === index ? "border-[var(--sf-primary)]" : "border-transparent"}`}>
                  <Image src={u} alt="" fill sizes="80px" className="object-cover" />
                </button>
              </li>
            ) : null;
          })}
        </ul>
      ) : null}
      <div
        className="sf-card-media relative aspect-[3/4] flex-1 cursor-zoom-in overflow-hidden"
        onMouseMove={(e) => {
          const r = e.currentTarget.getBoundingClientRect();
          setZoom({ x: ((e.clientX - r.left) / r.width) * 100, y: ((e.clientY - r.top) / r.height) * 100 });
        }}
        onMouseLeave={() => setZoom(null)}
        onClick={() => dialog.current?.showModal()}
      >
        {src ? (
          <Image
            src={src}
            alt={current?.alt || title}
            fill
            priority
            sizes="(min-width: 1024px) 50vw, 100vw"
            className="object-cover transition-transform duration-200 motion-reduce:transition-none"
            style={zoom ? { transform: "scale(1.8)", transformOrigin: `${zoom.x}% ${zoom.y}%` } : undefined}
          />
        ) : (
          <div aria-hidden className="absolute inset-0 bg-[var(--sf-border)]" />
        )}
      </div>
      <dialog ref={dialog} className="sf-dialog sf-dialog-full" aria-label={`${title} images`}>
        <button type="button" onClick={() => dialog.current?.close()} className="sf-btn sf-btn-outline fixed right-4 top-4 z-10 min-h-10 py-2">
          Close
        </button>
        <div className="space-y-4 p-4">
          {ordered.map((m) => {
            const u = assetUrl(m.path);
            // eslint-disable-next-line @next/next/no-img-element -- full-resolution zoom view
            return u ? <img key={m.id} src={u} alt={m.alt || title} className="mx-auto max-h-[90vh] w-auto" loading="lazy" /> : null;
          })}
        </div>
      </dialog>
    </div>
  );
}

function SizeGuide({ chart }: { chart: SizeChart }) {
  const ref = useRef<HTMLDialogElement>(null);
  return (
    <>
      <button type="button" className="sf-link text-sm" onClick={() => ref.current?.showModal()}>
        Size guide
      </button>
      <dialog ref={ref} className="sf-dialog sf-dialog-center" aria-labelledby="sg-title">
        <div className="p-5">
          <div className="mb-4 flex items-center justify-between gap-4">
            <h2 id="sg-title" className="sf-heading text-xl">
              {chart.name} <span className="sf-muted text-sm">({chart.unit === "cm" ? "centimetres" : "inches"})</span>
            </h2>
            <button type="button" onClick={() => ref.current?.close()} className="sf-link text-sm">
              Close
            </button>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead>
                <tr>
                  {chart.columns.map((c) => (
                    <th key={c} scope="col" className="sf-border border-b px-3 py-2">
                      {c}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {chart.rows.map((r, i) => (
                  <tr key={i}>
                    {r.map((cell, j) =>
                      j === 0 ? (
                        <th key={j} scope="row" className="sf-border border-b px-3 py-2 font-medium">
                          {cell}
                        </th>
                      ) : (
                        <td key={j} className="sf-border border-b px-3 py-2">
                          {cell}
                        </td>
                      ),
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {chart.note ? <p className="sf-muted mt-3 text-xs">{chart.note}</p> : null}
        </div>
      </dialog>
    </>
  );
}

/** Product gallery + variant selection + add to cart / buy now. */
export function ProductPurchase({
  title,
  options,
  variants,
  media,
  sizeChart,
  codNote,
}: {
  title: string;
  options: PdpOption[];
  variants: PdpVariant[];
  media: ProductMedia[];
  sizeChart: SizeChart | null;
  codNote: string | null;
}) {
  const [sel, setSel] = useState<Selection>(() => initialSelection(variants, options));
  const [qty, setQty] = useState(1);
  const [state, action, pending] = useActionState(addToCartAction, null);
  const variant = findVariant(variants, options, sel);
  const label = stockLabel(variant);
  const maxQty = Math.max(1, Math.min(10, variant?.available ?? 10));
  const complete = options.every((o) => sel[o.position]);
  const priceV = variant ?? variants[0];

  return (
    <div className="grid gap-8 @[64rem]:grid-cols-[minmax(0,1.1fr)_minmax(0,1fr)] @[64rem]:gap-12">
      <Gallery media={media} activePath={variant?.imagePath ?? null} title={title} />
      <div className="space-y-6">
        <div className="space-y-2">
          <h1 className="sf-heading text-3xl @[64rem]:text-4xl">{title}</h1>
          {priceV ? <Price priceMinor={priceV.priceMinor} compareAtMinor={priceV.compareAtMinor} size="lg" /> : null}
          <p className="sf-muted text-xs">Inclusive of all taxes</p>
        </div>

        {options.map((o) => {
          const colour = isColourOption(o.name);
          return (
            <fieldset key={o.position}>
              <legend className="mb-2 flex w-full items-center justify-between text-sm">
                <span>
                  <span className="font-medium">{o.name}</span>
                  {sel[o.position] ? <span className="sf-muted">: {sel[o.position]}</span> : null}
                </span>
                {isSizeOption(o.name) && sizeChart ? <SizeGuide chart={sizeChart} /> : null}
              </legend>
              <div className="flex flex-wrap gap-2">
                {o.values.map((v) => {
                  const st = valueState(variants, options, sel, o.position, v.value);
                  const selected = sel[o.position] === v.value;
                  return (
                    <label
                      key={v.value}
                      className={`relative flex min-h-10 min-w-10 cursor-pointer items-center justify-center border px-3 text-sm transition ${
                        selected ? "border-[var(--sf-primary)] bg-[var(--sf-primary)] text-[var(--sf-primary-fg)]" : "sf-border"
                      } ${st !== "available" ? "opacity-45 line-through" : ""} ${colour ? "rounded-full px-1" : "rounded-[var(--sf-radius-btn)]"}`}
                      title={st === "soldout" ? `${v.value} — sold out` : v.value}
                    >
                      <input
                        type="radio"
                        name={`opt-${o.position}`}
                        value={v.value}
                        checked={selected}
                        disabled={st === "unavailable"}
                        onChange={() => setSel((s) => selectValue(variants, options, s, o.position, v.value))}
                        className="sr-only"
                      />
                      {colour && v.swatch ? (
                        <span aria-hidden className="block size-7 rounded-full border border-black/10" style={{ background: v.swatch }} />
                      ) : null}
                      <span className={colour && v.swatch ? "sr-only" : ""}>{v.value}</span>
                    </label>
                  );
                })}
              </div>
            </fieldset>
          );
        })}

        <p aria-live="polite" className={`text-sm ${label.tone === "out" ? "text-[var(--sf-sale)]" : label.tone === "low" ? "text-[var(--sf-accent)]" : "sf-muted"}`}>
          {complete ? label.text : `Select ${options.filter((o) => !sel[o.position]).map((o) => o.name.toLowerCase()).join(" and ")}`}
        </p>

        <form action={action} className="space-y-3">
          <input type="hidden" name="variantId" value={variant?.id ?? ""} />
          <div className="flex items-center gap-3">
            <label htmlFor="pdp-qty" className="text-sm">
              Quantity
            </label>
            <select id="pdp-qty" name="quantity" value={qty} onChange={(e) => setQty(Number(e.target.value))} className="sf-input w-20 py-1.5">
              {Array.from({ length: maxQty }, (_, i) => i + 1).map((n) => (
                <option key={n} value={n}>
                  {n}
                </option>
              ))}
            </select>
          </div>
          <div className="grid gap-2 @[30rem]:grid-cols-2">
            <button type="submit" disabled={!variant || !variant.inStock || pending} className="sf-btn sf-btn-outline w-full">
              {pending ? "Adding…" : state?.ok ? "Added to bag ✓" : "Add to bag"}
            </button>
            <button type="submit" name="buyNow" value="1" disabled={!variant || !variant.inStock || pending} className="sf-btn w-full">
              Buy now
            </button>
          </div>
          {state && !state.ok ? (
            <p role="alert" className="text-sm text-[var(--sf-sale)]">
              {state.error.message}
            </p>
          ) : null}
          {state?.ok ? (
            <p role="status" className="text-sm">
              Added. <a href="/cart" className="sf-link">View bag ({state.data.count})</a>
            </p>
          ) : null}
        </form>
        {codNote ? <p className="sf-muted text-sm">{codNote}</p> : null}
      </div>
    </div>
  );
}
