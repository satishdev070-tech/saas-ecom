import Image from "next/image";
import { assetUrl } from "@/lib/storage/assets";

/**
 * Tenant image from Supabase Storage via next/image. Renders a neutral placeholder when the
 * path is empty/invalid (assetUrl only accepts tenant/{uuid}/... paths).
 */
export function StoreImage({
  path,
  alt,
  sizes,
  priority = false,
  className = "",
}: {
  path: string | null | undefined;
  alt: string;
  sizes: string;
  priority?: boolean;
  className?: string;
}) {
  const src = assetUrl(path);
  if (!src) {
    return <div aria-hidden className={`absolute inset-0 bg-[color-mix(in_srgb,var(--sf-border)_60%,var(--sf-surface))] ${className}`} />;
  }
  return <Image src={src} alt={alt} fill sizes={sizes} priority={priority} className={`object-cover ${className}`} />;
}
