import "server-only";
import { cache } from "react";
import { createSupabaseAdminClient } from "@/lib/supabase/admin";
import { createSupabaseServerClient } from "@/lib/supabase/server";
import { mapDbError } from "@/lib/supabase/errors";
import { AppError } from "@/lib/errors";
import { audit } from "@/lib/audit";
import { toMinor } from "@/lib/money";
import { logger } from "@/lib/observability/logger";
import { assertPermission, type TenantContext } from "@/lib/tenant/membership";
import { getEntitlements } from "@/features/platform";
import { readOrderAddress } from "@/features/customer-account/address";
import { manualShippingProvider } from "./manual";
import { shiprocketConfigured, shiprocketProvider } from "./shiprocket";
import type { CreatedShipment, Serviceability, ShippingProvider } from "./types";

export type ShippingSetup = { provider: ShippingProvider; pickupLocation: string; pickupPostcode: string | null };

/**
 * Which provider a tenant uses. Shiprocket only when the platform credentials exist AND the
 * tenant has the `shiprocket` feature; its per-tenant config lives in
 * tenant_feature_flags.config = {"pickup_location": "...", "pickup_postcode": "302001"}.
 * `tenantId` must be server-resolved.
 */
export const getShippingSetup = cache(async (tenantId: string): Promise<ShippingSetup> => {
  const admin = createSupabaseAdminClient();
  const { data: store } = await admin.from("stores").select("address").eq("tenant_id", tenantId).maybeSingle();
  const address = (store?.address ?? {}) as Record<string, unknown>;
  const storePostcode = typeof address.postal_code === "string" && /^[1-9]\d{5}$/.test(address.postal_code) ? address.postal_code : null;
  const manual: ShippingSetup = { provider: manualShippingProvider, pickupLocation: "Primary", pickupPostcode: storePostcode };
  if (!shiprocketConfigured()) return manual;
  try {
    const ent = await getEntitlements(tenantId);
    if (!ent.isEnabled("shiprocket")) return manual;
  } catch (err) {
    logger.warn("shipping.entitlements_unavailable", { tenantId, error: err });
    return manual;
  }
  const { data: flag } = await admin.from("tenant_feature_flags").select("config").eq("tenant_id", tenantId).eq("feature_key", "shiprocket").maybeSingle();
  const config = (flag?.config ?? {}) as Record<string, unknown>;
  const pickupLocation = typeof config.pickup_location === "string" && config.pickup_location.trim() ? config.pickup_location.trim().slice(0, 60) : "Primary";
  const pickupPostcode = typeof config.pickup_postcode === "string" && /^[1-9]\d{5}$/.test(config.pickup_postcode) ? config.pickup_postcode : storePostcode;
  return { provider: shiprocketProvider, pickupLocation, pickupPostcode };
});

/** Courier serviceability for a PIN (informational; never throws, null = unknown). */
export async function checkServiceability(tenantId: string, pincode: string, weightGrams: number, cod: boolean): Promise<Serviceability> {
  try {
    const setup = await getShippingSetup(tenantId);
    return await setup.provider.serviceability({ pickupPostcode: setup.pickupPostcode, deliveryPostcode: pincode, weightGrams: Math.max(100, weightGrams), cod });
  } catch (err) {
    logger.warn("shipping.serviceability_failed", { tenantId, error: err });
    return { serviceable: null, codAvailable: null, etaDays: null, courier: null };
  }
}

/**
 * Books a shipment with the tenant's provider for a confirmed, unshipped order (seller
 * dashboard; permission orders.write). Reads and writes through the user-scoped client, so RLS
 * applies too. Returns the created shipment; tracking can then be set via update_fulfillment.
 */
export async function createShipmentForOrder(ctx: TenantContext, orderId: string): Promise<CreatedShipment & { shipmentId: string }> {
  assertPermission(ctx, "orders.write");
  const supabase = await createSupabaseServerClient();
  const { data: o, error } = await supabase
    .from("orders")
    .select(
      "id, order_number, placed_at, status, fulfillment_status, payment_method, grand_total, subtotal, discount_total, shipping_total, email, phone, shipping_address, order_items(product_title, sku, quantity, unit_price, hsn_code, variant_id)",
    )
    .eq("tenant_id", ctx.tenantId)
    .eq("id", orderId)
    .maybeSingle();
  if (error) throw mapDbError(error);
  if (!o) throw new AppError("NOT_FOUND");
  if (o.status !== "confirmed" || o.fulfillment_status !== "unfulfilled") {
    throw new AppError("CONFLICT", { message: "Only confirmed orders that haven't shipped can be booked with a courier." });
  }
  const { data: existing } = await supabase.from("shipments").select("id").eq("tenant_id", ctx.tenantId).eq("order_id", orderId).limit(1).maybeSingle();
  if (existing) throw new AppError("CONFLICT", { message: "A shipment already exists for this order." });
  const address = readOrderAddress(o.shipping_address);
  if (!address) throw new AppError("VALIDATION", { message: "The order has no shipping address." });

  const variantIds = (o.order_items ?? []).map((i) => i.variant_id).filter((v): v is string => Boolean(v));
  const { data: variants } = variantIds.length
    ? await supabase.from("product_variants").select("id, weight_grams").eq("tenant_id", ctx.tenantId).in("id", variantIds)
    : { data: [] as { id: string; weight_grams: number }[] };
  const weightById = new Map((variants ?? []).map((v) => [v.id, v.weight_grams]));
  const weightGrams = (o.order_items ?? []).reduce((sum, i) => sum + (i.variant_id ? (weightById.get(i.variant_id) ?? 500) : 500) * i.quantity, 0);

  const { data: store } = await supabase.from("stores").select("order_prefix").eq("tenant_id", ctx.tenantId).maybeSingle();
  const setup = await getShippingSetup(ctx.tenantId);
  const created = await setup.provider.createShipment(
    {
      orderId: o.id,
      orderNumber: `${store?.order_prefix ?? "#"}${o.order_number}`,
      placedAt: o.placed_at,
      paymentMethod: o.payment_method === "cod" ? "cod" : "online",
      grandTotal: toMinor(o.grand_total),
      subtotal: toMinor(o.subtotal),
      discountTotal: toMinor(o.discount_total),
      shippingTotal: toMinor(o.shipping_total),
      email: o.email,
      phone: o.phone,
      address,
      items: (o.order_items ?? []).map((i) => ({ title: i.product_title, sku: i.sku, quantity: i.quantity, unitPrice: toMinor(i.unit_price), hsn: i.hsn_code })),
      weightGrams,
    },
    { pickupLocation: setup.pickupLocation },
  );

  const { data: row, error: insertError } = await supabase
    .from("shipments")
    .insert({
      tenant_id: ctx.tenantId,
      order_id: o.id,
      provider: created.provider,
      provider_ref: created.providerRef,
      carrier: created.carrier,
      tracking_number: created.trackingNumber,
      tracking_url: created.trackingUrl,
      status: "pending",
      weight_grams: weightGrams,
      metadata: created.metadata,
    })
    .select("id")
    .single();
  if (insertError || !row) {
    logger.error("shipping.record_failed", { tenantId: ctx.tenantId, orderId, providerRef: created.providerRef, error: insertError?.message });
    throw insertError ? mapDbError(insertError) : new AppError("INTERNAL");
  }
  await audit({
    tenantId: ctx.tenantId,
    actorUserId: ctx.user.id,
    action: "order.shipment_created",
    entityType: "order",
    entityId: o.id,
    metadata: { provider: created.provider, provider_ref: created.providerRef },
  });
  return { ...created, shipmentId: row.id };
}
