import "server-only";
import { serverEnv } from "@/lib/env/server";
import { AppError } from "@/lib/errors";
import { logger } from "@/lib/observability/logger";
import { buildShiprocketOrder, parseServiceability } from "./shiprocket-format";
import type { ShippingProvider } from "./types";

/** Shiprocket REST adapter (fetch, no SDK). Platform-level API user from SHIPROCKET_EMAIL/PASSWORD. */
const API = "https://apiv2.shiprocket.in/v1/external";
/** Tokens are valid for 10 days; refresh well before that. */
const TOKEN_TTL_MS = 8 * 24 * 60 * 60 * 1000;

let cachedToken: { value: string; expiresAt: number } | null = null;

export function shiprocketConfigured(): boolean {
  const env = serverEnv();
  return Boolean(env.SHIPROCKET_EMAIL && env.SHIPROCKET_PASSWORD);
}

async function token(forceRefresh = false): Promise<string> {
  if (!forceRefresh && cachedToken && cachedToken.expiresAt > Date.now()) return cachedToken.value;
  const env = serverEnv();
  if (!env.SHIPROCKET_EMAIL || !env.SHIPROCKET_PASSWORD) throw new AppError("CONFLICT", { message: "Shiprocket isn't configured." });
  const res = await fetch(`${API}/auth/login`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email: env.SHIPROCKET_EMAIL, password: env.SHIPROCKET_PASSWORD }),
    signal: AbortSignal.timeout(10_000),
    cache: "no-store",
  }).catch((err: unknown) => {
    throw new AppError("INTERNAL", { message: "Shiprocket is unreachable.", context: { error: err instanceof Error ? err.message : String(err) } });
  });
  const json = (await res.json().catch(() => ({}))) as { token?: string };
  if (!res.ok || !json.token) throw new AppError("INTERNAL", { message: "Shiprocket authentication failed.", context: { status: res.status } });
  cachedToken = { value: json.token, expiresAt: Date.now() + TOKEN_TTL_MS };
  return json.token;
}

async function call<T>(method: "GET" | "POST", path: string, body?: unknown, retried = false): Promise<T> {
  const res = await fetch(`${API}${path}`, {
    method,
    headers: { Authorization: `Bearer ${await token(retried)}`, ...(body ? { "Content-Type": "application/json" } : {}) },
    body: body ? JSON.stringify(body) : undefined,
    signal: AbortSignal.timeout(15_000),
    cache: "no-store",
  }).catch((err: unknown) => {
    throw new AppError("INTERNAL", { message: "Shiprocket is unreachable.", context: { path, error: err instanceof Error ? err.message : String(err) } });
  });
  if (res.status === 401 && !retried) return call<T>(method, path, body, true);
  const json = (await res.json().catch(() => ({}))) as T & { message?: string };
  if (!res.ok) {
    logger.warn("shiprocket.api_error", { path, status: res.status, message: String(json.message ?? "").slice(0, 200) });
    throw new AppError(res.status === 422 || res.status === 400 ? "VALIDATION" : "INTERNAL", { message: "Shiprocket rejected the request.", context: { path, status: res.status } });
  }
  return json;
}

export const shiprocketProvider: ShippingProvider = {
  id: "shiprocket",
  async serviceability({ pickupPostcode, deliveryPostcode, weightGrams, cod }) {
    if (!pickupPostcode) return { serviceable: null, codAvailable: null, etaDays: null, courier: null };
    const qs = new URLSearchParams({
      pickup_postcode: pickupPostcode,
      delivery_postcode: deliveryPostcode,
      weight: String(Math.max(0.1, Math.round(weightGrams / 10) / 100)),
      cod: cod ? "1" : "0",
    });
    return parseServiceability(await call<unknown>("GET", `/courier/serviceability/?${qs.toString()}`));
  },
  async createShipment(order, { pickupLocation }) {
    const res = await call<{ order_id?: number; shipment_id?: number; status?: string; awb_code?: string; courier_name?: string }>(
      "POST",
      "/orders/create/adhoc",
      buildShiprocketOrder(order, pickupLocation),
    );
    if (!res.shipment_id) throw new AppError("INTERNAL", { message: "Shiprocket didn't return a shipment.", context: { status: res.status } });
    const awb = res.awb_code || null;
    return {
      provider: "shiprocket",
      providerRef: String(res.shipment_id),
      carrier: res.courier_name || null,
      trackingNumber: awb,
      trackingUrl: awb ? `https://shiprocket.co/tracking/${encodeURIComponent(awb)}` : null,
      metadata: { shiprocket_order_id: res.order_id ?? null, shiprocket_shipment_id: res.shipment_id },
    };
  },
};
