/**
 * Shipping provider abstraction (ADR-020). "manual" = the seller ships with any courier and
 * enters tracking by hand (dashboard fulfilment); "shiprocket" = aggregator adapter, used only
 * when platform credentials are configured AND the tenant has the `shiprocket` feature.
 */
export type ShippingProviderId = "manual" | "shiprocket";

export type Serviceability = {
  /** null = provider couldn't tell (fall back to the store's own PIN rules) */
  serviceable: boolean | null;
  codAvailable: boolean | null;
  /** fastest courier estimate in days, when known */
  etaDays: number | null;
  courier: string | null;
};

export type ShipmentOrder = {
  orderId: string;
  orderNumber: string;
  placedAt: string;
  paymentMethod: "cod" | "online";
  /** paise */
  grandTotal: number;
  /** paise */
  subtotal: number;
  /** paise */
  discountTotal: number;
  /** paise */
  shippingTotal: number;
  email: string | null;
  phone: string;
  address: { name: string; phone: string; line1: string; line2: string | null; landmark: string | null; city: string; state: string; postal_code: string };
  items: { title: string; sku: string | null; quantity: number; unitPrice: number; hsn: string | null }[];
  weightGrams: number;
};

export type CreatedShipment = {
  provider: ShippingProviderId;
  providerRef: string | null;
  carrier: string | null;
  trackingNumber: string | null;
  trackingUrl: string | null;
  metadata: Record<string, string | number | null>;
};

export interface ShippingProvider {
  readonly id: ShippingProviderId;
  serviceability(input: { pickupPostcode: string | null; deliveryPostcode: string; weightGrams: number; cod: boolean }): Promise<Serviceability>;
  createShipment(order: ShipmentOrder, options: { pickupLocation: string }): Promise<CreatedShipment>;
}
