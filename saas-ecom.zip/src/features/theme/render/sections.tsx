import Link from "next/link";
import type { ReactNode } from "react";
import type { SectionSettings } from "@/features/theme/sections/definitions";
import type { SectionInstance, SectionType } from "@/features/theme/sections/types";
import { isSectionHidden } from "@/features/theme/schema/config";
import { parseVideoUrl } from "@/features/theme/schema/primitives";
import { getAllCategories, getCollections, listProducts, type ListArgs } from "@/features/storefront/server/catalog";
import { getBlogPostById, getFaqs, getLatestReviews, getPageById } from "@/features/storefront/server/content";
import { paths } from "@/features/storefront/urls";
import { ProductGrid as Grid, ProductRow } from "@/features/storefront/components/product-card";
import { StoreImage } from "@/features/storefront/components/store-image";
import { Stars } from "@/features/storefront/components/price";
import { NewsletterForm } from "@/features/storefront/components/islands";
import { assetUrl } from "@/lib/storage/assets";
import { AnnouncementBar, Footer, Header, MegaMenu } from "./chrome";
import type { RenderContext } from "./context";

type P<T extends SectionType> = { s: SectionSettings<T>; ctx: RenderContext };

function Intro({ eyebrow, heading, subheading, action }: { eyebrow?: string; heading?: string; subheading?: string; action?: ReactNode }) {
  if (!eyebrow && !heading && !subheading && !action) return null;
  return (
    <div className="mb-8 flex flex-col gap-2 @[48rem]:flex-row @[48rem]:items-end @[48rem]:justify-between">
      <div className="max-w-2xl space-y-2">
        {eyebrow ? <p className="sf-eyebrow">{eyebrow}</p> : null}
        {heading ? <h2 className="sf-heading text-3xl @[64rem]:text-4xl">{heading}</h2> : null}
        {subheading ? <p className="sf-muted">{subheading}</p> : null}
      </div>
      {action}
    </div>
  );
}

function Cta({ label, href, className = "sf-btn" }: { label?: string; href?: string; className?: string }) {
  if (!label || !href) return null;
  return (
    <Link href={href} className={className}>
      {label}
    </Link>
  );
}

function ViewAll({ href }: { href?: string }) {
  return href ? (
    <Link href={href} className="sf-link text-sm">
      View all →
    </Link>
  ) : null;
}

type ProductSourceSettings = SectionSettings<"ProductGrid">;
function sourceArgs(s: Pick<ProductSourceSettings, "source" | "collectionId" | "categoryId" | "productIds" | "ruleTags" | "ruleProductTypes" | "ruleMaxPrice" | "ruleOnSale" | "limit">): ListArgs | null {
  const base: ListArgs = { p_limit: s.limit, p_offset: 0, p_sort: "featured" };
  switch (s.source) {
    case "collection":
      return s.collectionId ? { ...base, p_collection: s.collectionId, p_sort: "manual" } : null;
    case "category":
      return s.categoryId ? { ...base, p_category: s.categoryId } : null;
    case "products":
      return s.productIds.length ? { ...base, p_product_ids: s.productIds } : null;
    case "rules":
      return {
        ...base,
        ...(s.ruleTags.length ? { p_tags: s.ruleTags } : {}),
        ...(s.ruleProductTypes.length ? { p_product_types: s.ruleProductTypes } : {}),
        ...(s.ruleMaxPrice > 0 ? { p_max_price: s.ruleMaxPrice } : {}),
        ...(s.ruleOnSale ? { p_on_sale: true } : {}),
      };
    case "newest":
      return { ...base, p_sort: "newest" };
    case "bestselling":
      return { ...base, p_sort: "best_selling" };
    case "featured":
      return { ...base, p_featured: true };
    case "sale":
      return { ...base, p_on_sale: true };
  }
}

async function Products({ ctx, args, layout, columns }: { ctx: RenderContext; args: ListArgs | null; layout: "grid" | "carousel"; columns?: number }) {
  if (!args) return null;
  const { cards } = await listProducts(ctx.sf.tenant.tenantId, args);
  if (!cards.length) return <p className="sf-muted text-sm">Products will appear here soon.</p>;
  return layout === "carousel" ? <ProductRow products={cards} settings={ctx.sf.theme.productCard} /> : <Grid products={cards} settings={ctx.sf.theme.productCard} columns={columns} />;
}

async function Hero({ s }: P<"Hero">) {
  const h = s.height === "large" ? "min-h-[78svh]" : s.height === "medium" ? "min-h-[60svh]" : "min-h-[44svh]";
  return (
    <section aria-roledescription="carousel" className="sf-scroll-row !gap-0">
      {s.slides.map((sl, i) => (
        <div key={i} className={`relative w-full shrink-0 ${h} flex items-end`}>
          <StoreImage path={sl.imagePath} alt={sl.alt} sizes="100vw" priority={i === 0} />
          <div aria-hidden className="absolute inset-0 bg-black" style={{ opacity: s.overlay / 100 }} />
          <div className={`sf-container relative py-16 ${sl.align === "center" ? "text-center" : ""} ${sl.textTone === "light" ? "text-white" : ""}`}>
            <div className={`max-w-xl space-y-4 ${sl.align === "center" ? "mx-auto" : ""}`}>
              {sl.eyebrow ? <p className="sf-eyebrow !text-current opacity-85">{sl.eyebrow}</p> : null}
              {i === 0 ? <h1 className="sf-heading text-4xl @[64rem]:text-6xl">{sl.heading}</h1> : <h2 className="sf-heading text-4xl @[64rem]:text-6xl">{sl.heading}</h2>}
              {sl.subheading ? <p className="text-lg opacity-90">{sl.subheading}</p> : null}
              <Cta label={sl.ctaLabel} href={sl.ctaHref} className={sl.textTone === "light" ? "sf-btn sf-btn-light" : "sf-btn"} />
            </div>
          </div>
        </div>
      ))}
    </section>
  );
}

function PromoBanner({ s }: P<"PromoBanner">) {
  const aspect = s.aspect === "wide" ? "aspect-[16/9]" : s.aspect === "square" ? "aspect-square" : "aspect-[3/4]";
  return (
    <section className="sf-container sf-section">
      <ul className={`grid gap-4 ${s.tiles.length > 1 ? "@[48rem]:grid-cols-2" : ""} ${s.tiles.length > 2 ? "@[64rem]:grid-cols-3" : ""}`}>
        {s.tiles.map((t, i) => (
          <li key={i} className={`relative overflow-hidden rounded-[var(--sf-radius-card)] ${aspect}`}>
            <StoreImage path={t.imagePath} alt={t.alt} sizes="(min-width: 768px) 50vw, 100vw" />
            <div className="absolute inset-0 flex flex-col justify-end bg-gradient-to-t from-black/55 to-transparent p-6 text-white">
              <h2 className="sf-heading text-2xl">{t.heading}</h2>
              {t.text ? <p className="mt-1 text-sm opacity-90">{t.text}</p> : null}
              <div className="mt-3">
                <Cta label={t.ctaLabel} href={t.ctaHref} className="sf-btn sf-btn-light" />
              </div>
            </div>
          </li>
        ))}
      </ul>
    </section>
  );
}

async function CategoryGrid({ s, ctx }: P<"CategoryGrid">) {
  const all = await getAllCategories(ctx.sf.tenant.tenantId);
  const byId = new Map(all.map((c) => [c.id, c]));
  const tiles =
    s.mode === "manual"
      ? s.items.flatMap((it) => {
          const c = byId.get(it.id);
          return c ? [{ href: paths.category(c.slug), label: it.label || c.name, imagePath: it.imagePath || c.imagePath }] : [];
        })
      : all.filter((c) => !c.parentId).slice(0, s.limit).map((c) => ({ href: paths.category(c.slug), label: c.name, imagePath: c.imagePath }));
  if (!tiles.length) return null;
  const aspect = s.shape === "circle" ? "aspect-square rounded-full" : s.shape === "square" ? "aspect-square" : "aspect-[3/4]";
  return (
    <section className="sf-container sf-section">
      <Intro eyebrow={s.eyebrow} heading={s.heading} subheading={s.subheading} />
      <ul className="grid grid-cols-2 gap-4 @[48rem]:grid-cols-3 @[64rem]:grid-cols-6">
        {tiles.map((t) => (
          <li key={t.href}>
            <Link href={t.href} className="group block text-center">
              <div className={`relative overflow-hidden ${aspect}`}>
                <StoreImage path={t.imagePath} alt="" sizes="(min-width: 1024px) 16vw, 50vw" className="transition duration-500 group-hover:scale-105" />
              </div>
              <p className="mt-2 text-sm font-medium">{t.label}</p>
            </Link>
          </li>
        ))}
      </ul>
    </section>
  );
}

async function CollectionGrid({ s, ctx }: P<"CollectionGrid">) {
  const ids = s.mode === "manual" ? s.items.map((i) => i.id).filter(Boolean) : undefined;
  const cols = await getCollections(ctx.sf.tenant.tenantId, ids ? { ids } : { limit: s.limit });
  const labels = new Map(s.items.map((i) => [i.id, i]));
  const ordered = ids ? ids.flatMap((id) => cols.filter((c) => c.id === id)) : cols;
  if (!ordered.length) return null;
  return (
    <section className="sf-container sf-section">
      <Intro eyebrow={s.eyebrow} heading={s.heading} subheading={s.subheading} />
      <ul className={`grid grid-cols-2 gap-4 ${s.columns >= 4 ? "@[64rem]:grid-cols-4" : s.columns === 3 ? "@[64rem]:grid-cols-3" : ""}`}>
        {ordered.map((c) => (
          <li key={c.id}>
            <Link href={paths.collection(c.slug)} className="group relative block aspect-[4/5] overflow-hidden rounded-[var(--sf-radius-card)]">
              <StoreImage path={labels.get(c.id)?.imagePath || c.imagePath} alt="" sizes="(min-width: 1024px) 25vw, 50vw" className="transition duration-500 group-hover:scale-105" />
              <span className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/60 to-transparent p-4 text-white">
                <span className="sf-heading text-xl">{labels.get(c.id)?.label || c.title}</span>
              </span>
            </Link>
          </li>
        ))}
      </ul>
    </section>
  );
}

async function ProductCarouselSection({ s, ctx }: P<"ProductCarousel">) {
  return (
    <section className="sf-container sf-section">
      <Intro eyebrow={s.eyebrow} heading={s.heading} subheading={s.subheading} action={<ViewAll href={s.viewAllHref} />} />
      <Products ctx={ctx} args={sourceArgs(s)} layout="carousel" />
    </section>
  );
}

async function ProductGridSection({ s, ctx }: P<"ProductGrid">) {
  return (
    <section className="sf-container sf-section">
      <Intro eyebrow={s.eyebrow} heading={s.heading} subheading={s.subheading} action={<ViewAll href={s.viewAllHref} />} />
      <Products ctx={ctx} args={sourceArgs(s)} layout="grid" columns={s.columns} />
    </section>
  );
}

async function Bestseller({ s, ctx }: P<"Bestseller">) {
  return (
    <section className="sf-container sf-section">
      <Intro eyebrow={s.eyebrow} heading={s.heading} subheading={s.subheading} action={<ViewAll href={s.viewAllHref} />} />
      <Products ctx={ctx} args={{ p_sort: "best_selling", p_limit: s.limit, p_offset: 0 }} layout={s.layout === "carousel" ? "carousel" : "grid"} />
    </section>
  );
}

async function NewArrivals({ s, ctx }: P<"NewArrivals">) {
  return (
    <section className="sf-container sf-section">
      <Intro eyebrow={s.eyebrow} heading={s.heading} subheading={s.subheading} action={<ViewAll href={s.viewAllHref} />} />
      <Products ctx={ctx} args={{ p_sort: "newest", p_limit: s.limit, p_offset: 0 }} layout={s.layout === "carousel" ? "carousel" : "grid"} />
    </section>
  );
}

function SaleBanner({ s }: P<"SaleBanner">) {
  return (
    <section style={{ background: s.background, color: s.textColor }}>
      <div className="sf-container sf-section text-center">
        {s.eyebrow ? <p className="sf-eyebrow !text-current opacity-80">{s.eyebrow}</p> : null}
        <h2 className="sf-heading mt-2 text-4xl @[64rem]:text-5xl">{s.heading}</h2>
        {s.subheading ? <p className="mt-3 opacity-90">{s.subheading}</p> : null}
        {s.code ? (
          <p className="mt-4 text-sm">
            Use code <span className="rounded border border-current px-2 py-0.5 font-mono tracking-widest">{s.code}</span>
          </p>
        ) : null}
        {s.endsText ? <p className="mt-2 text-xs opacity-80">{s.endsText}</p> : null}
        <div className="mt-6">
          <Cta label={s.ctaLabel} href={s.ctaHref} className="sf-btn sf-btn-light" />
        </div>
      </div>
    </section>
  );
}

async function EditorialImageText({ s, ctx }: P<"EditorialImageText">) {
  let heading = s.heading;
  let body = s.body;
  let href = s.ctaHref;
  let imagePath = s.imagePath;
  if (s.source === "page" && s.pageId) {
    const page = await getPageById(ctx.sf.tenant.tenantId, s.pageId);
    if (page) {
      heading ||= page.title;
      href ||= paths.page(page.slug);
      const firstPara = page.blocks.find((b) => b.type === "paragraph");
      body ||= firstPara && firstPara.type === "paragraph" ? firstPara.text : "";
    }
  } else if (s.source === "blog" && s.blogPostId) {
    const post = await getBlogPostById(ctx.sf.tenant.tenantId, s.blogPostId);
    if (post) {
      heading ||= post.title;
      body ||= post.excerpt ?? "";
      href ||= paths.blogPost(post.slug);
      imagePath ||= post.coverPath ?? "";
    }
  }
  return (
    <section className={`sf-tone-${s.tone}`}>
      <div className={`sf-container sf-section grid items-center gap-10 @[48rem]:grid-cols-2 ${s.imagePosition === "right" ? "@[48rem]:[&>*:first-child]:order-2" : ""}`}>
        <div className="relative aspect-[4/5] overflow-hidden rounded-[var(--sf-radius-card)]">
          <StoreImage path={imagePath} alt={s.alt} sizes="(min-width: 768px) 50vw, 100vw" />
        </div>
        <div className="space-y-4">
          {s.eyebrow ? <p className="sf-eyebrow">{s.eyebrow}</p> : null}
          {heading ? <h2 className="sf-heading text-3xl @[64rem]:text-5xl">{heading}</h2> : null}
          {s.subheading ? <p className="text-lg">{s.subheading}</p> : null}
          {body ? <p className="sf-muted whitespace-pre-line leading-relaxed">{body}</p> : null}
          <Cta label={s.ctaLabel || (href ? "Read more" : "")} href={href} className="sf-btn sf-btn-outline" />
        </div>
      </div>
    </section>
  );
}

function VideoBanner({ s }: P<"VideoBanner">) {
  const video = s.videoUrl ? parseVideoUrl(s.videoUrl) : null;
  const poster = assetUrl(s.posterPath) ?? undefined;
  return (
    <section className="sf-container sf-section">
      <Intro eyebrow={s.eyebrow} heading={s.heading} subheading={s.subheading} />
      <div className="relative aspect-video overflow-hidden rounded-[var(--sf-radius-card)] bg-black">
        {video?.provider === "file" && assetUrl(video.path) ? (
          <video src={assetUrl(video.path)!} poster={poster} className="h-full w-full object-cover" playsInline controls={!s.autoplayMuted} autoPlay={s.autoplayMuted} muted={s.autoplayMuted} loop={s.autoplayMuted} />
        ) : video && video.provider !== "file" ? (
          <iframe
            src={`${video.embedUrl}${s.autoplayMuted ? (video.embedUrl.includes("?") ? "&" : "?") + "autoplay=1&mute=1&muted=1&loop=1" : ""}`}
            title={s.heading || "Video"}
            className="h-full w-full"
            loading="lazy"
            allow="autoplay; encrypted-media; picture-in-picture"
            referrerPolicy="strict-origin-when-cross-origin"
            sandbox="allow-scripts allow-same-origin allow-presentation"
          />
        ) : poster ? (
          // eslint-disable-next-line @next/next/no-img-element -- poster fallback
          <img src={poster} alt="" className="h-full w-full object-cover" />
        ) : null}
      </div>
      <div className="mt-6 text-center">
        <Cta label={s.ctaLabel} href={s.ctaHref} />
      </div>
    </section>
  );
}

function Lookbook({ s }: P<"Lookbook">) {
  if (!s.looks.length) return null;
  return (
    <section className="sf-container sf-section">
      <Intro eyebrow={s.eyebrow} heading={s.heading} subheading={s.subheading} />
      <ul className={s.layout === "masonry" ? "columns-2 gap-4 @[64rem]:columns-3 [&>li]:mb-4 [&>li]:break-inside-avoid" : "grid grid-cols-2 gap-4 @[64rem]:grid-cols-3"}>
        {s.looks.map((l, i) => (
          <li key={i}>
            <figure>
              <div className={`relative overflow-hidden rounded-[var(--sf-radius-card)] ${i % 3 === 1 ? "aspect-[3/5]" : "aspect-[3/4]"}`}>
                <StoreImage path={l.imagePath} alt={l.alt} sizes="(min-width: 1024px) 33vw, 50vw" />
              </div>
              {l.caption ? <figcaption className="sf-muted mt-2 text-sm">{l.caption}</figcaption> : null}
            </figure>
          </li>
        ))}
      </ul>
    </section>
  );
}

function BrandStory({ s }: P<"BrandStory">) {
  return (
    <section className="sf-container sf-section grid items-center gap-10 @[48rem]:grid-cols-2">
      <div className="space-y-5">
        {s.eyebrow ? <p className="sf-eyebrow">{s.eyebrow}</p> : null}
        <h2 className="sf-heading text-3xl @[64rem]:text-5xl">{s.heading}</h2>
        {s.subheading ? <p className="text-lg">{s.subheading}</p> : null}
        {s.body ? <p className="sf-muted whitespace-pre-line leading-relaxed">{s.body}</p> : null}
        {s.stats.length ? (
          <dl className="grid grid-cols-2 gap-6 pt-2 @[48rem]:grid-cols-4">
            {s.stats.map((st, i) => (
              <div key={i}>
                <dt className="sf-muted text-xs">{st.label}</dt>
                <dd className="sf-heading text-3xl">{st.value}</dd>
              </div>
            ))}
          </dl>
        ) : null}
        <Cta label={s.ctaLabel} href={s.ctaHref} className="sf-btn sf-btn-outline" />
      </div>
      <div className="relative aspect-[4/5] overflow-hidden rounded-[var(--sf-radius-card)]">
        <StoreImage path={s.imagePath} alt={s.alt} sizes="(min-width: 768px) 50vw, 100vw" />
      </div>
    </section>
  );
}

function Testimonials({ s }: P<"Testimonials">) {
  if (!s.items.length) return null;
  return (
    <section className="sf-surface">
      <div className="sf-container sf-section">
        <Intro eyebrow={s.eyebrow} heading={s.heading} subheading={s.subheading} />
        <ul className="grid gap-6 @[48rem]:grid-cols-3">
          {s.items.map((t, i) => (
            <li key={i}>
              <figure className="space-y-3">
                {t.rating ? <Stars rating={t.rating} /> : null}
                <blockquote className="sf-heading text-xl leading-snug">“{t.quote}”</blockquote>
                <figcaption className="sf-muted text-sm">
                  {t.author}
                  {t.location ? `, ${t.location}` : ""}
                </figcaption>
              </figure>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}

async function ReviewsSection({ s, ctx }: P<"Reviews">) {
  if (!ctx.sf.features.reviews) return null;
  const reviews = await getLatestReviews(ctx.sf.tenant.tenantId, s.minRating, s.limit);
  if (!reviews.length) return null;
  return (
    <section className="sf-container sf-section">
      <Intro eyebrow={s.eyebrow} heading={s.heading} subheading={s.subheading} />
      <ul className="grid gap-6 @[48rem]:grid-cols-3">
        {reviews.map((r) => (
          <li key={r.id} className="sf-border space-y-2 rounded-[var(--sf-radius-card)] border p-5">
            <Stars rating={r.rating} />
            {r.title ? <p className="font-medium">{r.title}</p> : null}
            {r.body ? <p className="sf-muted line-clamp-5 text-sm">{r.body}</p> : null}
            <p className="text-xs">
              {r.authorName}
              {r.verified ? " · Verified buyer" : ""}
            </p>
            {s.showProduct && r.product ? (
              <Link href={paths.product(r.product.slug)} className="sf-link text-xs">
                {r.product.title}
              </Link>
            ) : null}
          </li>
        ))}
      </ul>
    </section>
  );
}

function SocialProof({ s }: P<"SocialProof">) {
  if (!s.posts.length) return null;
  return (
    <section className="sf-container sf-section">
      <Intro eyebrow={s.eyebrow} heading={s.heading} subheading={s.subheading} action={s.profileUrl ? <a href={s.profileUrl} rel="noopener noreferrer" target="_blank" className="sf-link text-sm">{s.handle || "Follow us"} →</a> : null} />
      <ul className="grid grid-cols-3 gap-2 @[64rem]:grid-cols-6">
        {s.posts.map((p, i) => {
          const img = (
            <div className="relative aspect-square overflow-hidden">
              <StoreImage path={p.imagePath} alt={p.alt} sizes="(min-width: 1024px) 16vw, 33vw" />
            </div>
          );
          return (
            <li key={i}>
              {p.href ? (
                <a href={p.href} rel="noopener noreferrer" target="_blank" aria-label={p.alt || "Open post"}>
                  {img}
                </a>
              ) : (
                img
              )}
            </li>
          );
        })}
      </ul>
    </section>
  );
}

function Newsletter({ s }: P<"Newsletter">) {
  return (
    <section className={`sf-tone-${s.tone}`}>
      <div className="sf-container sf-section mx-auto max-w-2xl space-y-4 text-center">
        {s.eyebrow ? <p className="sf-eyebrow">{s.eyebrow}</p> : null}
        <h2 className="sf-heading text-3xl">{s.heading}</h2>
        {s.subheading ? <p className="sf-muted">{s.subheading}</p> : null}
        <NewsletterForm buttonLabel={s.buttonLabel} />
      </div>
    </section>
  );
}

async function FAQ({ s, ctx }: P<"FAQ">) {
  const items = s.source === "manual" ? s.items : (await getFaqs(ctx.sf.tenant.tenantId, { group: s.group || undefined, limit: s.limit })).map((f) => ({ question: f.question, answer: f.answer }));
  if (!items.length) return null;
  return (
    <section className="sf-container sf-section mx-auto max-w-3xl">
      <Intro eyebrow={s.eyebrow} heading={s.heading} subheading={s.subheading} />
      <div className="sf-border divide-y divide-[var(--sf-border)] border-y">
        {items.map((f, i) => (
          <details key={i} className="group py-4">
            <summary className="flex cursor-pointer list-none items-center justify-between gap-4 font-medium">
              {f.question}
              <span aria-hidden className="transition group-open:rotate-45">+</span>
            </summary>
            <p className="sf-muted mt-3 whitespace-pre-line text-sm leading-relaxed">{f.answer}</p>
          </details>
        ))}
      </div>
    </section>
  );
}

const TRUST_GLYPHS: Record<string, string> = { truck: "🚚", return: "↺", cod: "₹", handmade: "✋", secure: "🔒", india: "🇮🇳", gift: "🎁", leaf: "🌿" };

function TrustBadges({ s }: P<"TrustBadges">) {
  return (
    <section className={`sf-tone-${s.tone}`}>
      <ul className="sf-container grid grid-cols-2 gap-6 py-10 text-center @[64rem]:grid-cols-4">
        {s.items.map((t, i) => (
          <li key={i} className="space-y-1">
            <span aria-hidden className="text-2xl">
              {TRUST_GLYPHS[t.icon] ?? "✓"}
            </span>
            <p className="text-sm font-medium">{t.title}</p>
            {t.text ? <p className="sf-muted text-xs">{t.text}</p> : null}
          </li>
        ))}
      </ul>
    </section>
  );
}

type Renderer<K extends SectionType> = (p: P<K>) => ReactNode | Promise<ReactNode>;

/** Section registry: type -> renderer. Unknown types never reach here (config is schema-validated). */
const REGISTRY: { [K in SectionType]: Renderer<K> } = {
  AnnouncementBar,
  Header,
  MegaMenu,
  Hero,
  PromoBanner,
  CategoryGrid,
  CollectionGrid,
  ProductCarousel: ProductCarouselSection,
  ProductGrid: ProductGridSection,
  Bestseller,
  NewArrivals,
  SaleBanner,
  EditorialImageText,
  VideoBanner,
  Lookbook,
  BrandStory,
  Testimonials,
  Reviews: ReviewsSection,
  SocialProof,
  Newsletter,
  FAQ,
  TrustBadges,
  Footer,
};

function visibilityClass(section: SectionInstance): string {
  const v = section.visibility;
  if (v.desktop && !v.mobile) return "sf-hide-mobile";
  if (!v.desktop && v.mobile) return "sf-hide-desktop";
  return "";
}

/** Renders an ordered list of theme sections (layout group or page template). */
export function SectionList({ sections, ctx }: { sections: SectionInstance[]; ctx: RenderContext }) {
  return (
    <>
      {sections.map((section) => {
        if (isSectionHidden(section)) return null;
        const Render = REGISTRY[section.type] as Renderer<SectionType>;
        const cls = visibilityClass(section);
        const node = <Render s={section.settings as never} ctx={ctx} />;
        return cls ? (
          <div key={section.id} className={cls} data-section={section.type}>
            {node}
          </div>
        ) : (
          <div key={section.id} className="contents" data-section={section.type}>
            {node}
          </div>
        );
      })}
    </>
  );
}
