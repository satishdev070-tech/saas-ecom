import Link from "next/link";
import type { SectionSettings } from "@/features/theme/sections/definitions";
import type { MenuNode } from "@/features/storefront/urls";
import { assetUrl } from "@/lib/storage/assets";
import { formatAddress, telHref, whatsappUrl } from "@/features/storefront/store-profile";
import { paths } from "@/features/storefront/urls";
import type { RenderContext } from "./context";

function MenuLink({ node, className }: { node: MenuNode; className?: string }) {
  if (!node.href) return <span className={className}>{node.title}</span>;
  return node.external ? (
    <a href={node.href} className={className} rel="noopener noreferrer" target="_blank">
      {node.title}
    </a>
  ) : (
    <Link href={node.href} className={className}>
      {node.title}
    </Link>
  );
}

function Logo({ ctx }: { ctx: RenderContext }) {
  const h = ctx.sf.theme.header;
  const src = assetUrl(h.logoPath || ctx.sf.store.logoPath);
  return (
    <Link href="/" className="flex items-center gap-2" aria-label={`${ctx.sf.store.name} home`}>
      {src ? (
        // eslint-disable-next-line @next/next/no-img-element -- logo keeps intrinsic ratio; width capped by theme
        <img src={src} alt={h.logoAlt || ctx.sf.store.name} style={{ maxWidth: h.logoMaxWidth, maxHeight: 56 }} className="h-auto w-auto" />
      ) : h.showStoreName ? (
        <span className="sf-heading text-2xl">{ctx.sf.store.name}</span>
      ) : null}
    </Link>
  );
}

function MobileMenu({ items }: { items: MenuNode[] }) {
  return (
    <details className="relative @[64rem]:hidden">
      <summary className="cursor-pointer list-none p-2" aria-label="Open menu">
        <span aria-hidden className="text-xl">☰</span>
      </summary>
      <nav aria-label="Mobile" className="sf-surface sf-border fixed inset-x-0 top-0 z-50 max-h-dvh overflow-y-auto border-b p-5 shadow-lg">
        <ul className="space-y-3">
          {items.map((n) => (
            <li key={n.id}>
              {n.children.length ? (
                <details>
                  <summary className="cursor-pointer font-medium">{n.title}</summary>
                  <ul className="mt-2 space-y-2 pl-4">
                    {n.href ? (
                      <li>
                        <MenuLink node={{ ...n, title: `All ${n.title}`, children: [] }} className="sf-link-quiet" />
                      </li>
                    ) : null}
                    {n.children.map((c) => (
                      <li key={c.id}>
                        <MenuLink node={c} className="sf-link-quiet" />
                      </li>
                    ))}
                  </ul>
                </details>
              ) : (
                <MenuLink node={n} className={n.highlight ? "font-medium text-[var(--sf-sale)]" : "font-medium"} />
              )}
            </li>
          ))}
          <li className="sf-border border-t pt-3">
            <Link href={paths.account()} className="sf-link-quiet">
              Account
            </Link>
          </li>
        </ul>
      </nav>
    </details>
  );
}

export function AnnouncementBar({ s }: { s: SectionSettings<"AnnouncementBar">; ctx: RenderContext }) {
  if (!s.messages.length) return null;
  return (
    <div className={`sf-tone-${s.tone} px-4 py-2 text-center text-xs tracking-wide`}>
      <ul className="flex flex-wrap justify-center gap-x-8 gap-y-1">
        {s.messages.map((m, i) => (
          <li key={i}>{m.href ? <Link href={m.href} className="underline-offset-2 hover:underline">{m.text}</Link> : m.text}</li>
        ))}
      </ul>
    </div>
  );
}

export function Header({ s, ctx }: { s: SectionSettings<"Header">; ctx: RenderContext }) {
  const h = ctx.sf.theme.header;
  const menu = ctx.menus[h.menuHandle]?.items ?? [];
  const icons = (
    <div className="flex items-center gap-1 text-sm">
      {h.showSearch ? (
        <Link href={paths.search()} className="p-2" aria-label="Search">
          <span aria-hidden>⌕</span>
        </Link>
      ) : null}
      {h.showAccount ? (
        <Link href={paths.account()} className="hidden p-2 @[48rem]:inline" aria-label={ctx.signedIn ? "Your account" : "Sign in"}>
          <span aria-hidden>◯</span>
        </Link>
      ) : null}
      {h.showWishlist ? (
        <Link href={paths.wishlist()} className="hidden p-2 @[48rem]:inline" aria-label="Wishlist">
          <span aria-hidden>♡</span>
        </Link>
      ) : null}
      {h.showCart ? (
        <Link href={paths.cart()} className="relative p-2" aria-label={`Cart, ${ctx.cartCount} items`}>
          <span aria-hidden>👜</span>
          {ctx.cartCount > 0 ? (
            <span className="absolute -right-0.5 -top-0.5 min-w-4 rounded-full bg-[var(--sf-primary)] px-1 text-center text-[10px] leading-4 text-[var(--sf-primary-fg)]">{ctx.cartCount}</span>
          ) : null}
        </Link>
      ) : null}
    </div>
  );
  return (
    <header className={`sf-surface sf-border z-40 border-b ${h.sticky ? "sticky top-0" : ""}`}>
      <div className={`sf-container grid items-center gap-3 py-3 ${s.layout === "logo-center" ? "grid-cols-[1fr_auto_1fr]" : "grid-cols-[auto_1fr_auto]"}`}>
        <div className="flex items-center gap-2">
          <MobileMenu items={menu} />
          {s.layout === "logo-center" ? (
            h.showSearch ? (
              <form action={paths.search()} role="search" className="hidden @[64rem]:block">
                <label htmlFor="hdr-q" className="sr-only">
                  Search products
                </label>
                <input id="hdr-q" name="q" type="search" placeholder="Search" className="sf-input w-48 py-1.5 text-sm" />
              </form>
            ) : null
          ) : (
            <Logo ctx={ctx} />
          )}
        </div>
        <div className={s.layout === "logo-center" ? "flex justify-center" : "hidden @[64rem]:block"}>
          {s.layout === "logo-center" ? (
            <Logo ctx={ctx} />
          ) : s.showInlineMenu ? (
            <nav aria-label="Main">
              <ul className="flex flex-wrap gap-6 text-sm">
                {menu.map((n) => (
                  <li key={n.id}>
                    <MenuLink node={n} className="sf-link-quiet" />
                  </li>
                ))}
              </ul>
            </nav>
          ) : null}
        </div>
        <div className="flex justify-end">{icons}</div>
      </div>
    </header>
  );
}

export function MegaMenu({ s, ctx }: { s: SectionSettings<"MegaMenu">; ctx: RenderContext }) {
  const items = ctx.menus[s.menuHandle]?.items ?? [];
  if (!items.length) return null;
  return (
    <nav aria-label="Main" className="sf-surface sf-border hidden border-b @[64rem]:block">
      <ul className={`sf-container flex flex-wrap justify-center gap-x-8 text-sm ${s.uppercase ? "uppercase tracking-[0.14em] text-xs" : ""}`}>
        {items.map((n) => (
          <li key={n.id} className="group relative">
            <MenuLink node={n} className={`block py-3 ${n.highlight ? "text-[var(--sf-sale)]" : ""}`} />
            {n.children.length ? (
              <div className="sf-surface sf-border invisible absolute left-1/2 top-full z-40 w-[min(90vw,640px)] -translate-x-1/2 border p-6 opacity-0 shadow-lg transition group-focus-within:visible group-focus-within:opacity-100 group-hover:visible group-hover:opacity-100">
                <ul className="grid grid-cols-3 gap-4 normal-case tracking-normal">
                  {n.children.map((c) => (
                    <li key={c.id}>
                      {s.showImages && c.imagePath && assetUrl(c.imagePath) ? (
                        // eslint-disable-next-line @next/next/no-img-element -- small menu thumbnails
                        <img src={assetUrl(c.imagePath)!} alt="" className="mb-2 aspect-[4/5] w-full object-cover" loading="lazy" />
                      ) : null}
                      <MenuLink node={c} className="sf-link-quiet font-medium" />
                      {c.children.length ? (
                        <ul className="mt-1 space-y-1">
                          {c.children.map((g) => (
                            <li key={g.id}>
                              <MenuLink node={g} className="sf-link-quiet sf-muted" />
                            </li>
                          ))}
                        </ul>
                      ) : null}
                    </li>
                  ))}
                </ul>
              </div>
            ) : null}
          </li>
        ))}
      </ul>
    </nav>
  );
}

export function Footer({ s, ctx }: { s: SectionSettings<"Footer">; ctx: RenderContext }) {
  const store = ctx.sf.store;
  const address = formatAddress(store.address);
  const wa = whatsappUrl(store.whatsapp);
  const year = new Date().getFullYear();
  return (
    <footer className={`sf-tone-${s.tone} mt-auto`}>
      <div className="sf-container grid gap-10 py-14 @[48rem]:grid-cols-2 @[64rem]:grid-cols-4">
        <div className="space-y-3">
          <p className="sf-heading text-2xl">{store.name}</p>
          {s.about || store.tagline ? <p className="text-sm opacity-80">{s.about || store.tagline}</p> : null}
          {s.showSocial && store.social.length ? (
            <ul className="flex flex-wrap gap-3 text-sm">
              {store.social.map((l) => (
                <li key={l.url}>
                  <a href={l.url} rel="noopener noreferrer" target="_blank" className="underline-offset-2 hover:underline">
                    {l.label}
                  </a>
                </li>
              ))}
            </ul>
          ) : null}
        </div>
        {s.menuHandles.map((handle) => {
          const menu = ctx.menus[handle];
          if (!menu?.items.length) return null;
          return (
            <nav key={handle} aria-label={menu.title}>
              <p className="sf-eyebrow mb-3 !text-current opacity-70">{menu.title}</p>
              <ul className="space-y-2 text-sm">
                {menu.items.map((n) => (
                  <li key={n.id}>
                    <MenuLink node={n} className="opacity-85 hover:opacity-100" />
                  </li>
                ))}
              </ul>
            </nav>
          );
        })}
        {s.showContact ? (
          <div className="space-y-2 text-sm">
            <p className="sf-eyebrow mb-3 !text-current opacity-70">Contact</p>
            {store.email ? (
              <p>
                <a href={`mailto:${store.email}`}>{store.email}</a>
              </p>
            ) : null}
            {store.phone && telHref(store.phone) ? (
              <p>
                <a href={telHref(store.phone)!}>{store.phone}</a>
              </p>
            ) : null}
            {wa ? (
              <p>
                <a href={wa} rel="noopener noreferrer" target="_blank">
                  WhatsApp us
                </a>
              </p>
            ) : null}
            {address.length ? <address className="not-italic opacity-80">{address.join(", ")}</address> : null}
          </div>
        ) : null}
      </div>
      <div className="sf-container flex flex-col gap-2 border-t border-current/15 py-5 text-xs opacity-75 @[48rem]:flex-row @[48rem]:justify-between">
        <p>{s.copyright || `© ${year} ${store.name}. All rights reserved.`}</p>
        {s.showPaymentNote ? <p>Secure payments · UPI · Cards · Net banking{ctx.sf.features.cod && store.cod.enabled ? " · Cash on delivery" : ""}</p> : null}
      </div>
    </footer>
  );
}
