import { z } from "zod";
import { PRODUCT_TYPES, PRODUCT_TYPE_LABELS } from "@/features/storefront/constants";
import { hexColor, imagePath, menuHandle, plainText, safeHref, socialUrl, uuidOrEmpty, videoUrl } from "../schema/primitives";
import type { EditorField, SectionDefinition, SectionType } from "./types";

/**
 * The section registry (definitions half). One entry per section type: label, allowed groups,
 * zod settings schema (every field defaulted, unknown keys stripped) and editor field metadata.
 * The storefront renderers are registered separately in ./renderers.tsx under the same keys.
 */

const uuid = z.string().regex(/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i);
const txt = (max: number, def = "") => plainText(max).default(def);
const opts = <T extends string>(values: readonly T[], labels?: Partial<Record<T, string>>) =>
  values.map((v) => ({ value: v, label: labels?.[v] ?? v.charAt(0).toUpperCase() + v.slice(1).replace(/[_-]/g, " ") }));

// -----------------------------------------------------------------------------
// Shared setting groups
// -----------------------------------------------------------------------------
const TONES = ["light", "dark", "accent", "muted"] as const;

const headingFields = {
  eyebrow: txt(60),
  heading: txt(120),
  subheading: txt(300),
};
const headingEditor: EditorField[] = [
  { kind: "text", key: "eyebrow", label: "Eyebrow", maxLength: 60, placeholder: "Small text above the heading" },
  { kind: "text", key: "heading", label: "Heading", maxLength: 120 },
  { kind: "text", key: "subheading", label: "Subheading", maxLength: 300, multiline: true },
];

export const PRODUCT_SOURCES = ["collection", "category", "products", "rules", "newest", "bestselling", "featured", "sale"] as const;
export type ProductSource = (typeof PRODUCT_SOURCES)[number];
const SOURCE_LABELS: Record<ProductSource, string> = {
  collection: "A collection",
  category: "A category",
  products: "Hand-picked products",
  rules: "Rules (tags, type, price)",
  newest: "Newest products",
  bestselling: "Best sellers",
  featured: "Featured products",
  sale: "Products on sale",
};

const productSourceFields = {
  source: z.enum(PRODUCT_SOURCES).default("newest"),
  collectionId: uuidOrEmpty.default(""),
  categoryId: uuidOrEmpty.default(""),
  productIds: z.array(uuid).max(24).default([]),
  ruleTags: z.array(plainText(40).pipe(z.string().min(1))).max(10).default([]),
  ruleProductTypes: z.array(z.enum(PRODUCT_TYPES)).max(PRODUCT_TYPES.length).default([]),
  ruleMaxPrice: z.coerce.number().int().min(0).max(1_000_000).default(0),
  ruleOnSale: z.boolean().default(false),
  limit: z.coerce.number().int().min(2).max(24).default(8),
  viewAllHref: safeHref.default(""),
};
function productSourceEditor(defaultLimitMax = 24): EditorField[] {
  return [
    { kind: "select", key: "source", label: "Products from", options: PRODUCT_SOURCES.map((v) => ({ value: v, label: SOURCE_LABELS[v] })) },
    { kind: "picker", key: "collectionId", label: "Collection", picker: "collection", showIf: { key: "source", equals: ["collection"] } },
    { kind: "picker", key: "categoryId", label: "Category", picker: "category", showIf: { key: "source", equals: ["category"] } },
    { kind: "multiPicker", key: "productIds", label: "Products", picker: "product", max: 24, showIf: { key: "source", equals: ["products"] } },
    { kind: "tags", key: "ruleTags", label: "Has any of these tags", max: 10, showIf: { key: "source", equals: ["rules"] } },
    {
      kind: "tags",
      key: "ruleProductTypes",
      label: "Product types",
      max: PRODUCT_TYPES.length,
      placeholder: PRODUCT_TYPES.join(", "),
      showIf: { key: "source", equals: ["rules"] },
      help: `Allowed: ${PRODUCT_TYPES.map((t) => PRODUCT_TYPE_LABELS[t]).join(", ")}`,
    },
    { kind: "number", key: "ruleMaxPrice", label: "Maximum price (₹, 0 = any)", min: 0, max: 1_000_000, step: 100, showIf: { key: "source", equals: ["rules"] } },
    { kind: "toggle", key: "ruleOnSale", label: "Only products on sale", showIf: { key: "source", equals: ["rules"] } },
    { kind: "number", key: "limit", label: "Number of products", min: 2, max: defaultLimitMax },
    { kind: "link", key: "viewAllHref", label: "“View all” link", placeholder: "/collections/new-arrivals" },
  ];
}

const ctaFields = { ctaLabel: txt(40), ctaHref: safeHref.default("") };
const ctaEditor: EditorField[] = [
  { kind: "text", key: "ctaLabel", label: "Button label", maxLength: 40 },
  { kind: "link", key: "ctaHref", label: "Button link", placeholder: "/collections/festive-edit" },
];

// -----------------------------------------------------------------------------
// Definitions
// -----------------------------------------------------------------------------
const announcementBar = {
  type: "AnnouncementBar",
  label: "Announcement bar",
  description: "Short messages above the header (offers, shipping, COD).",
  groups: ["header", "home"],
  schema: z.object({
    messages: z
      .array(z.object({ text: plainText(120).pipe(z.string().min(1, "Required")), href: safeHref.default("") }))
      .min(1)
      .max(3)
      .default([{ text: "Free shipping on orders above ₹1,499", href: "" }]),
    tone: z.enum(TONES).default("dark"),
  }),
  fields: [
    {
      kind: "list",
      key: "messages",
      label: "Messages",
      itemLabel: "Message",
      min: 1,
      max: 3,
      fields: [
        { kind: "text", key: "text", label: "Text", maxLength: 120 },
        { kind: "link", key: "href", label: "Link (optional)" },
      ],
    },
    { kind: "select", key: "tone", label: "Colour", options: opts(TONES) },
  ],
} satisfies SectionDefinition;

const header = {
  type: "Header",
  label: "Header",
  description: "Logo, navigation, search, account, wishlist and bag. Uses the global header settings.",
  groups: ["header"],
  singleton: true,
  schema: z.object({
    layout: z.enum(["logo-left", "logo-center"]).default("logo-center"),
    showInlineMenu: z.boolean().default(false),
  }),
  fields: [
    { kind: "select", key: "layout", label: "Layout", options: opts(["logo-left", "logo-center"] as const, { "logo-left": "Logo left", "logo-center": "Logo centred" }) },
    { kind: "toggle", key: "showInlineMenu", label: "Show menu inside the header (desktop)", help: "Turn off when using a Mega menu section below the header." },
  ],
} satisfies SectionDefinition;

const megaMenu = {
  type: "MegaMenu",
  label: "Mega menu",
  description: "Full-width desktop navigation with dropdown panels built from a menu.",
  groups: ["header"],
  singleton: true,
  schema: z.object({ menuHandle: menuHandle.default("main"), showImages: z.boolean().default(true), uppercase: z.boolean().default(true) }),
  fields: [
    { kind: "picker", key: "menuHandle", label: "Menu", picker: "menu" },
    { kind: "toggle", key: "showImages", label: "Show menu item images in dropdowns" },
    { kind: "toggle", key: "uppercase", label: "Uppercase labels" },
  ],
} satisfies SectionDefinition;

const heroSlide = z.object({
  imagePath: imagePath.default(""),
  mobileImagePath: imagePath.default(""),
  alt: txt(200),
  eyebrow: txt(60),
  heading: txt(120),
  subheading: txt(240),
  ...ctaFields,
  align: z.enum(["left", "center", "right"]).default("left"),
  textTone: z.enum(["light", "dark"]).default("light"),
});
const hero = {
  type: "Hero",
  label: "Hero / slideshow",
  description: "Large editorial images with headline and call to action. Several slides become a swipeable carousel.",
  groups: ["home", "collection"],
  schema: z.object({
    slides: z.array(heroSlide).min(1).max(5).default([heroSlide.parse({ heading: "The festive edit", subheading: "Hand block printed in Jaipur", ctaLabel: "Shop now", ctaHref: "/collections" })]),
    height: z.enum(["medium", "large", "full"]).default("large"),
    overlay: z.coerce.number().int().min(0).max(80).default(25),
  }),
  fields: [
    {
      kind: "list",
      key: "slides",
      label: "Slides",
      itemLabel: "Slide",
      min: 1,
      max: 5,
      fields: [
        { kind: "image", key: "imagePath", label: "Image (desktop)" },
        { kind: "image", key: "mobileImagePath", label: "Image (mobile, optional)" },
        { kind: "text", key: "alt", label: "Image description (alt text)", maxLength: 200 },
        { kind: "text", key: "eyebrow", label: "Eyebrow", maxLength: 60 },
        { kind: "text", key: "heading", label: "Heading", maxLength: 120 },
        { kind: "text", key: "subheading", label: "Subheading", maxLength: 240, multiline: true },
        ...ctaEditor,
        { kind: "select", key: "align", label: "Text position", options: opts(["left", "center", "right"] as const) },
        { kind: "select", key: "textTone", label: "Text colour", options: opts(["light", "dark"] as const) },
      ],
    },
    { kind: "select", key: "height", label: "Height", options: opts(["medium", "large", "full"] as const, { full: "Full screen" }) },
    { kind: "number", key: "overlay", label: "Image darkening (%)", min: 0, max: 80, step: 5 },
  ],
} satisfies SectionDefinition;

const promoTile = z.object({ imagePath: imagePath.default(""), alt: txt(200), heading: txt(80), text: txt(160), ...ctaFields });
const promoBanner = {
  type: "PromoBanner",
  label: "Promo banner",
  description: "One to three image tiles promoting a collection or offer.",
  groups: ["header", "home", "collection", "product"],
  schema: z.object({
    tiles: z.array(promoTile).min(1).max(3).default([promoTile.parse({ heading: "Everyday cottons", ctaLabel: "Explore", ctaHref: "/collections" })]),
    aspect: z.enum(["wide", "square", "portrait"]).default("wide"),
  }),
  fields: [
    {
      kind: "list",
      key: "tiles",
      label: "Tiles",
      itemLabel: "Tile",
      min: 1,
      max: 3,
      fields: [
        { kind: "image", key: "imagePath", label: "Image" },
        { kind: "text", key: "alt", label: "Image description", maxLength: 200 },
        { kind: "text", key: "heading", label: "Heading", maxLength: 80 },
        { kind: "text", key: "text", label: "Text", maxLength: 160 },
        ...ctaEditor,
      ],
    },
    { kind: "select", key: "aspect", label: "Tile shape", options: opts(["wide", "square", "portrait"] as const) },
  ],
} satisfies SectionDefinition;

const gridItem = z.object({ id: uuidOrEmpty.default(""), imagePath: imagePath.default(""), label: txt(60) });
const categoryGrid = {
  type: "CategoryGrid",
  label: "Category tiles",
  description: "Image tiles linking to categories. Automatic mode shows your top-level categories.",
  groups: ["home", "collection"],
  schema: z.object({
    ...headingFields,
    mode: z.enum(["auto", "manual"]).default("auto"),
    items: z.array(gridItem).max(12).default([]),
    limit: z.coerce.number().int().min(2).max(12).default(6),
    shape: z.enum(["portrait", "square", "circle"]).default("portrait"),
  }),
  fields: [
    ...headingEditor,
    { kind: "select", key: "mode", label: "Categories", options: [{ value: "auto", label: "Top-level categories" }, { value: "manual", label: "Choose categories" }] },
    {
      kind: "list",
      key: "items",
      label: "Tiles",
      itemLabel: "Tile",
      max: 12,
      showIf: { key: "mode", equals: ["manual"] },
      fields: [
        { kind: "picker", key: "id", label: "Category", picker: "category" },
        { kind: "image", key: "imagePath", label: "Image override (optional)" },
        { kind: "text", key: "label", label: "Label override (optional)", maxLength: 60 },
      ],
    },
    { kind: "number", key: "limit", label: "Maximum tiles", min: 2, max: 12 },
    { kind: "select", key: "shape", label: "Tile shape", options: opts(["portrait", "square", "circle"] as const) },
  ],
} satisfies SectionDefinition;

const collectionGrid = {
  type: "CollectionGrid",
  label: "Collection / occasion grid",
  description: "Image tiles linking to collections, e.g. shop by occasion.",
  groups: ["home", "collection", "product"],
  schema: z.object({
    ...headingFields,
    mode: z.enum(["auto", "manual"]).default("auto"),
    items: z.array(gridItem).max(12).default([]),
    limit: z.coerce.number().int().min(2).max(12).default(4),
    columns: z.coerce.number().int().min(2).max(4).default(4),
  }),
  fields: [
    ...headingEditor,
    { kind: "select", key: "mode", label: "Collections", options: [{ value: "auto", label: "All collections (by position)" }, { value: "manual", label: "Choose collections" }] },
    {
      kind: "list",
      key: "items",
      label: "Tiles",
      itemLabel: "Tile",
      max: 12,
      showIf: { key: "mode", equals: ["manual"] },
      fields: [
        { kind: "picker", key: "id", label: "Collection", picker: "collection" },
        { kind: "image", key: "imagePath", label: "Image override (optional)" },
        { kind: "text", key: "label", label: "Label override (optional)", maxLength: 60 },
      ],
    },
    { kind: "number", key: "limit", label: "Maximum tiles", min: 2, max: 12 },
    { kind: "number", key: "columns", label: "Columns (desktop)", min: 2, max: 4 },
  ],
} satisfies SectionDefinition;

const productCarousel = {
  type: "ProductCarousel",
  label: "Product carousel",
  description: "A swipeable row of products from a collection, category, rules or a hand-picked list.",
  groups: ["home", "collection", "product"],
  schema: z.object({ ...headingFields, ...productSourceFields }),
  fields: [...headingEditor, ...productSourceEditor()],
} satisfies SectionDefinition;

const productGrid = {
  type: "ProductGrid",
  label: "Product grid",
  description: "A grid of products, e.g. a featured collection.",
  groups: ["home", "collection", "product"],
  schema: z.object({ ...headingFields, ...productSourceFields, columns: z.coerce.number().int().min(2).max(5).default(4) }),
  fields: [...headingEditor, ...productSourceEditor(), { kind: "number", key: "columns", label: "Columns (desktop)", min: 2, max: 5 }],
} satisfies SectionDefinition;

const presetProducts = (type: SectionType, label: string, description: string, heading: string, layout: "carousel" | "grid") =>
  ({
    type,
    label,
    description,
    groups: ["home", "collection", "product"],
    schema: z.object({
      ...headingFields,
      heading: txt(120, heading),
      limit: z.coerce.number().int().min(2).max(24).default(8),
      layout: z.enum(["carousel", "grid"]).default(layout),
      viewAllHref: safeHref.default(""),
    }),
    fields: [
      ...headingEditor,
      { kind: "number", key: "limit", label: "Number of products", min: 2, max: 24 },
      { kind: "select", key: "layout", label: "Layout", options: opts(["carousel", "grid"] as const) },
      { kind: "link", key: "viewAllHref", label: "“View all” link" },
    ],
  }) satisfies SectionDefinition;

const bestseller = presetProducts("Bestseller", "Bestsellers", "Your best-selling products, updated automatically.", "Bestsellers", "grid");
const newArrivals = presetProducts("NewArrivals", "New arrivals", "The newest published products, updated automatically.", "New arrivals", "carousel");

const saleBanner = {
  type: "SaleBanner",
  label: "Sale banner",
  description: "A bold band announcing a sale, with an optional coupon code.",
  groups: ["home", "collection", "product"],
  schema: z.object({
    ...headingFields,
    heading: txt(120, "The Summer Sale"),
    code: z
      .string()
      .trim()
      .toUpperCase()
      .max(30)
      .regex(/^[A-Z0-9_-]*$/, "Letters, numbers, - and _ only")
      .default(""),
    endsText: txt(80),
    ...ctaFields,
    background: hexColor.default("#7a2e1f"),
    textColor: hexColor.default("#fbf8f3"),
  }),
  fields: [
    ...headingEditor,
    { kind: "text", key: "code", label: "Coupon code (optional)", maxLength: 30 },
    { kind: "text", key: "endsText", label: "Ends text (e.g. “Ends Sunday midnight”)", maxLength: 80 },
    ...ctaEditor,
    { kind: "color", key: "background", label: "Background" },
    { kind: "color", key: "textColor", label: "Text colour" },
  ],
} satisfies SectionDefinition;

const editorial = {
  type: "EditorialImageText",
  label: "Editorial image + text",
  description: "Large image beside a story. Can pull its text from a page or blog post.",
  groups: ["home", "collection", "product"],
  schema: z.object({
    source: z.enum(["manual", "page", "blog"]).default("manual"),
    pageId: uuidOrEmpty.default(""),
    blogPostId: uuidOrEmpty.default(""),
    imagePath: imagePath.default(""),
    alt: txt(200),
    ...headingFields,
    body: txt(1200),
    ...ctaFields,
    imagePosition: z.enum(["left", "right"]).default("left"),
    tone: z.enum(TONES).default("light"),
  }),
  fields: [
    { kind: "select", key: "source", label: "Content", options: [{ value: "manual", label: "Write it here" }, { value: "page", label: "From a page" }, { value: "blog", label: "From a blog post" }] },
    { kind: "picker", key: "pageId", label: "Page", picker: "page", showIf: { key: "source", equals: ["page"] } },
    { kind: "picker", key: "blogPostId", label: "Blog post", picker: "blogPost", showIf: { key: "source", equals: ["blog"] } },
    { kind: "image", key: "imagePath", label: "Image" },
    { kind: "text", key: "alt", label: "Image description", maxLength: 200 },
    ...headingEditor,
    { kind: "text", key: "body", label: "Text", maxLength: 1200, multiline: true, showIf: { key: "source", equals: ["manual"] } },
    ...ctaEditor,
    { kind: "select", key: "imagePosition", label: "Image position", options: opts(["left", "right"] as const) },
    { kind: "select", key: "tone", label: "Background", options: opts(TONES) },
  ],
} satisfies SectionDefinition;

const videoBanner = {
  type: "VideoBanner",
  label: "Video banner",
  description: "A YouTube or Vimeo film, or an uploaded MP4. No other embeds are allowed.",
  groups: ["home", "collection", "product"],
  schema: z.object({
    ...headingFields,
    videoUrl: videoUrl.default(""),
    posterPath: imagePath.default(""),
    autoplayMuted: z.boolean().default(true),
    ...ctaFields,
  }),
  fields: [
    ...headingEditor,
    { kind: "video", key: "videoUrl", label: "Video", help: "YouTube or Vimeo link, or upload an MP4 in Media and paste its path." },
    { kind: "image", key: "posterPath", label: "Cover image" },
    { kind: "toggle", key: "autoplayMuted", label: "Autoplay muted (MP4 only)" },
    ...ctaEditor,
  ],
} satisfies SectionDefinition;

const lookbook = {
  type: "Lookbook",
  label: "Lookbook",
  description: "An editorial image gallery; each look can link to a product.",
  groups: ["home", "collection"],
  schema: z.object({
    ...headingFields,
    looks: z
      .array(z.object({ imagePath: imagePath.default(""), alt: txt(200), caption: txt(120), productId: uuidOrEmpty.default("") }))
      .max(12)
      .default([]),
    layout: z.enum(["masonry", "row"]).default("masonry"),
  }),
  fields: [
    ...headingEditor,
    {
      kind: "list",
      key: "looks",
      label: "Looks",
      itemLabel: "Look",
      max: 12,
      fields: [
        { kind: "image", key: "imagePath", label: "Image" },
        { kind: "text", key: "alt", label: "Image description", maxLength: 200 },
        { kind: "text", key: "caption", label: "Caption", maxLength: 120 },
        { kind: "picker", key: "productId", label: "Shop the look (product)", picker: "product" },
      ],
    },
    { kind: "select", key: "layout", label: "Layout", options: opts(["masonry", "row"] as const) },
  ],
} satisfies SectionDefinition;

const brandStory = {
  type: "BrandStory",
  label: "Brand story",
  description: "Who you are, with optional numbers (artisans, years, cities).",
  groups: ["home", "product"],
  schema: z.object({
    ...headingFields,
    heading: txt(120, "Made by hand, in Jaipur"),
    body: txt(1500),
    imagePath: imagePath.default(""),
    alt: txt(200),
    stats: z.array(z.object({ value: plainText(12).pipe(z.string().min(1)), label: plainText(40).pipe(z.string().min(1)) })).max(4).default([]),
    ...ctaFields,
  }),
  fields: [
    ...headingEditor,
    { kind: "text", key: "body", label: "Story", maxLength: 1500, multiline: true },
    { kind: "image", key: "imagePath", label: "Image (optional)" },
    { kind: "text", key: "alt", label: "Image description", maxLength: 200 },
    {
      kind: "list",
      key: "stats",
      label: "Numbers",
      itemLabel: "Number",
      max: 4,
      fields: [
        { kind: "text", key: "value", label: "Value (e.g. 120+)", maxLength: 12 },
        { kind: "text", key: "label", label: "Label (e.g. artisans)", maxLength: 40 },
      ],
    },
    ...ctaEditor,
  ],
} satisfies SectionDefinition;

const testimonials = {
  type: "Testimonials",
  label: "Testimonials",
  description: "Quotes from customers that you write in.",
  groups: ["home", "product"],
  schema: z.object({
    ...headingFields,
    heading: txt(120, "Loved by our customers"),
    items: z
      .array(
        z.object({
          quote: plainText(400).pipe(z.string().min(1, "Required")),
          author: plainText(60).pipe(z.string().min(1, "Required")),
          location: txt(60),
          rating: z.coerce.number().int().min(0).max(5).default(5),
        }),
      )
      .max(8)
      .default([]),
  }),
  fields: [
    ...headingEditor,
    {
      kind: "list",
      key: "items",
      label: "Testimonials",
      itemLabel: "Testimonial",
      max: 8,
      fields: [
        { kind: "text", key: "quote", label: "Quote", maxLength: 400, multiline: true },
        { kind: "text", key: "author", label: "Name", maxLength: 60 },
        { kind: "text", key: "location", label: "City (optional)", maxLength: 60 },
        { kind: "number", key: "rating", label: "Stars (0 = hide)", min: 0, max: 5 },
      ],
    },
  ],
} satisfies SectionDefinition;

const reviews = {
  type: "Reviews",
  label: "Customer reviews",
  description: "Latest approved product reviews, pulled automatically.",
  groups: ["home", "collection", "product"],
  schema: z.object({
    ...headingFields,
    heading: txt(120, "What customers say"),
    minRating: z.coerce.number().int().min(1).max(5).default(4),
    limit: z.coerce.number().int().min(2).max(12).default(6),
    showProduct: z.boolean().default(true),
  }),
  fields: [
    ...headingEditor,
    { kind: "number", key: "minRating", label: "Minimum stars", min: 1, max: 5 },
    { kind: "number", key: "limit", label: "Number of reviews", min: 2, max: 12 },
    { kind: "toggle", key: "showProduct", label: "Show product name" },
  ],
} satisfies SectionDefinition;

const socialProof = {
  type: "SocialProof",
  label: "Instagram / social",
  description: "A grid of your social posts (images you upload, linked to the post). No third-party scripts.",
  groups: ["home", "footer", "product"],
  schema: z.object({
    ...headingFields,
    heading: txt(120, "#WearAangan"),
    handle: z
      .string()
      .trim()
      .max(31)
      .regex(/^@?[A-Za-z0-9._]*$/, "Letters, numbers, . and _ only")
      .default(""),
    profileUrl: socialUrl.default(""),
    posts: z.array(z.object({ imagePath: imagePath.default(""), alt: txt(200), href: socialUrl.default("") })).max(12).default([]),
  }),
  fields: [
    ...headingEditor,
    { kind: "text", key: "handle", label: "Handle (e.g. @aangan)", maxLength: 31 },
    { kind: "link", key: "profileUrl", label: "Profile link", placeholder: "https://instagram.com/yourbrand" },
    {
      kind: "list",
      key: "posts",
      label: "Posts",
      itemLabel: "Post",
      max: 12,
      fields: [
        { kind: "image", key: "imagePath", label: "Image" },
        { kind: "text", key: "alt", label: "Image description", maxLength: 200 },
        { kind: "link", key: "href", label: "Post link (optional)" },
      ],
    },
  ],
} satisfies SectionDefinition;

const newsletter = {
  type: "Newsletter",
  label: "Newsletter sign-up",
  description: "Email sign-up with marketing consent.",
  groups: ["home", "footer", "product"],
  schema: z.object({
    ...headingFields,
    heading: txt(120, "Join the Aangan circle"),
    subheading: txt(300, "New prints, restocks and early access to sales. No spam."),
    buttonLabel: txt(30, "Subscribe"),
    tone: z.enum(TONES).default("muted"),
  }),
  fields: [...headingEditor, { kind: "text", key: "buttonLabel", label: "Button label", maxLength: 30 }, { kind: "select", key: "tone", label: "Background", options: opts(TONES) }],
} satisfies SectionDefinition;

const faq = {
  type: "FAQ",
  label: "FAQ",
  description: "Questions and answers — write them here or use your store FAQs.",
  groups: ["home", "collection", "product"],
  schema: z.object({
    ...headingFields,
    heading: txt(120, "Frequently asked questions"),
    source: z.enum(["store", "manual"]).default("store"),
    group: txt(60),
    items: z
      .array(z.object({ question: plainText(300).pipe(z.string().min(1, "Required")), answer: plainText(2000).pipe(z.string().min(1, "Required")) }))
      .max(20)
      .default([]),
    limit: z.coerce.number().int().min(1).max(30).default(8),
  }),
  fields: [
    ...headingEditor,
    { kind: "select", key: "source", label: "Questions", options: [{ value: "store", label: "Store FAQs" }, { value: "manual", label: "Write them here" }] },
    { kind: "text", key: "group", label: "Only this FAQ group (optional)", maxLength: 60, showIf: { key: "source", equals: ["store"] } },
    { kind: "number", key: "limit", label: "Maximum questions", min: 1, max: 30, showIf: { key: "source", equals: ["store"] } },
    {
      kind: "list",
      key: "items",
      label: "Questions",
      itemLabel: "Question",
      max: 20,
      showIf: { key: "source", equals: ["manual"] },
      fields: [
        { kind: "text", key: "question", label: "Question", maxLength: 300 },
        { kind: "text", key: "answer", label: "Answer", maxLength: 2000, multiline: true },
      ],
    },
  ],
} satisfies SectionDefinition;

export const TRUST_ICONS = ["truck", "return", "cod", "handmade", "secure", "india", "gift", "leaf"] as const;
const trustBadges = {
  type: "TrustBadges",
  label: "Trust strip",
  description: "Icons with short promises: shipping, returns, COD, handmade.",
  groups: ["home", "footer", "collection", "product"],
  schema: z.object({
    items: z
      .array(z.object({ icon: z.enum(TRUST_ICONS).default("truck"), title: plainText(40).pipe(z.string().min(1, "Required")), text: txt(100) }))
      .min(1)
      .max(6)
      .default([
        { icon: "truck", title: "Free shipping", text: "On orders above ₹1,499" },
        { icon: "cod", title: "Cash on delivery", text: "Across most PIN codes" },
        { icon: "return", title: "Easy returns", text: "7-day hassle-free returns" },
        { icon: "handmade", title: "Handcrafted", text: "Made by artisans in India" },
      ]),
    tone: z.enum(TONES).default("light"),
  }),
  fields: [
    {
      kind: "list",
      key: "items",
      label: "Promises",
      itemLabel: "Promise",
      min: 1,
      max: 6,
      fields: [
        { kind: "select", key: "icon", label: "Icon", options: opts(TRUST_ICONS, { cod: "Cash on delivery", india: "Made in India" }) },
        { kind: "text", key: "title", label: "Title", maxLength: 40 },
        { kind: "text", key: "text", label: "Text", maxLength: 100 },
      ],
    },
    { kind: "select", key: "tone", label: "Background", options: opts(TONES) },
  ],
} satisfies SectionDefinition;

const footer = {
  type: "Footer",
  label: "Footer",
  description: "Menus, contact details, social links and policies.",
  groups: ["footer"],
  singleton: true,
  schema: z.object({
    menuHandles: z.array(menuHandle.pipe(z.string().min(2))).max(4).default(["footer"]),
    about: txt(400),
    showContact: z.boolean().default(true),
    showSocial: z.boolean().default(true),
    showPolicies: z.boolean().default(true),
    showPaymentNote: z.boolean().default(true),
    copyright: txt(120),
    tone: z.enum(["dark", "light", "muted"]).default("dark"),
  }),
  fields: [
    { kind: "tags", key: "menuHandles", label: "Menus (handles)", max: 4, placeholder: "footer" },
    { kind: "text", key: "about", label: "About text", maxLength: 400, multiline: true },
    { kind: "toggle", key: "showContact", label: "Show contact details" },
    { kind: "toggle", key: "showSocial", label: "Show social links" },
    { kind: "toggle", key: "showPolicies", label: "Show policy pages" },
    { kind: "toggle", key: "showPaymentNote", label: "Show “UPI, cards & COD accepted”" },
    { kind: "text", key: "copyright", label: "Copyright line (optional)", maxLength: 120 },
    { kind: "select", key: "tone", label: "Colour", options: opts(["dark", "light", "muted"] as const) },
  ],
} satisfies SectionDefinition;

export const SECTION_DEFINITIONS = {
  AnnouncementBar: announcementBar,
  Header: header,
  MegaMenu: megaMenu,
  Hero: hero,
  PromoBanner: promoBanner,
  CategoryGrid: categoryGrid,
  CollectionGrid: collectionGrid,
  ProductCarousel: productCarousel,
  ProductGrid: productGrid,
  Bestseller: bestseller,
  NewArrivals: newArrivals,
  SaleBanner: saleBanner,
  EditorialImageText: editorial,
  VideoBanner: videoBanner,
  Lookbook: lookbook,
  BrandStory: brandStory,
  Testimonials: testimonials,
  Reviews: reviews,
  SocialProof: socialProof,
  Newsletter: newsletter,
  FAQ: faq,
  TrustBadges: trustBadges,
  Footer: footer,
} as const satisfies Record<SectionType, SectionDefinition>;

export type SectionSettings<T extends SectionType> = z.infer<(typeof SECTION_DEFINITIONS)[T]["schema"]>;

export function getSectionDefinition(type: string): SectionDefinition | null {
  return Object.prototype.hasOwnProperty.call(SECTION_DEFINITIONS, type) ? (SECTION_DEFINITIONS as Record<string, SectionDefinition>)[type]! : null;
}

/** Default settings for a section type (every field defaulted). */
export function defaultSettings(type: SectionType): Record<string, unknown> {
  return SECTION_DEFINITIONS[type].schema.parse({}) as Record<string, unknown>;
}
