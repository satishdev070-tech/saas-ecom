import { z } from "zod";
import { hexColor, imagePath, menuHandle, plainText } from "./primitives";

/**
 * Global design tokens, header settings and product-card settings. Every field has a default
 * so a partial/older config is completed on parse. Values are enumerations or validated hex
 * colours: the CSS emitted from them (ThemeTokensStyle) cannot contain seller-controlled text.
 */

/** Font stacks allowlist (ADR-019: no web-font downloads at build; system/self-hosted stacks only). */
export const FONT_STACKS = {
  "editorial-serif": { label: "Editorial serif", stack: '"Cormorant Garamond", "Playfair Display", "Iowan Old Style", "Palatino Linotype", Palatino, Georgia, serif' },
  "classic-serif": { label: "Classic serif", stack: 'ui-serif, Georgia, Cambria, "Times New Roman", Times, serif' },
  didone: { label: "Didone (high contrast)", stack: 'Didot, "Bodoni 72", "Bodoni MT", "Libre Bodoni", Georgia, serif' },
  "modern-sans": { label: "Modern sans", stack: 'ui-sans-serif, system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif' },
  "geometric-sans": { label: "Geometric sans", stack: 'Avenir, "Avenir Next", Montserrat, Corbel, "URW Gothic", "Century Gothic", sans-serif' },
  "humanist-sans": { label: "Humanist sans", stack: 'Seravek, "Gill Sans Nova", Ubuntu, Calibri, "DejaVu Sans", source-sans-pro, sans-serif' },
  mono: { label: "Monospace", stack: 'ui-monospace, "SF Mono", "Cascadia Code", Menlo, Consolas, monospace' },
} as const;
export type FontKey = keyof typeof FONT_STACKS;
export const FONT_KEYS = Object.keys(FONT_STACKS) as [FontKey, ...FontKey[]];

export const BUTTON_SHAPES = ["square", "rounded", "pill"] as const;
export const BUTTON_VARIANTS = ["solid", "outline"] as const;
export const CARD_RADII = ["none", "sm", "md", "lg"] as const;
export const CONTAINER_WIDTHS = ["narrow", "default", "wide", "full"] as const;
export const SPACING_SCALES = ["compact", "comfortable", "airy"] as const;

export const tokensSchema = z.object({
  colors: z
    .object({
      primary: hexColor.default("#1f1a17"),
      secondary: hexColor.default("#7a2e1f"),
      accent: hexColor.default("#b4532a"),
      background: hexColor.default("#fbf8f3"),
      text: hexColor.default("#1f1a17"),
      border: hexColor.default("#e6ded3"),
      sale: hexColor.default("#9f2a1c"),
    })
    .prefault({}),
  headingFont: z.enum(FONT_KEYS).default("editorial-serif"),
  bodyFont: z.enum(FONT_KEYS).default("modern-sans"),
  headingCase: z.enum(["normal", "uppercase"]).default("normal"),
  buttonShape: z.enum(BUTTON_SHAPES).default("square"),
  buttonVariant: z.enum(BUTTON_VARIANTS).default("solid"),
  cardRadius: z.enum(CARD_RADII).default("none"),
  containerWidth: z.enum(CONTAINER_WIDTHS).default("wide"),
  spacing: z.enum(SPACING_SCALES).default("airy"),
});
export type ThemeTokens = z.infer<typeof tokensSchema>;

export const headerSettingsSchema = z.object({
  logoPath: imagePath.default(""),
  logoAlt: plainText(120).default(""),
  logoMaxWidth: z.coerce.number().int().min(60).max(320).default(160),
  menuHandle: menuHandle.default("main"),
  showSearch: z.boolean().default(true),
  showAccount: z.boolean().default(true),
  showWishlist: z.boolean().default(true),
  showCart: z.boolean().default(true),
  sticky: z.boolean().default(true),
  /** How the main menu appears on small screens. */
  mobileMenu: z.enum(["drawer", "fullscreen"]).default("drawer"),
  /** Show the store name as text when no logo is uploaded. */
  showStoreName: z.boolean().default(true),
});
export type HeaderSettings = z.infer<typeof headerSettingsSchema>;

export const IMAGE_RATIOS = { portrait: "3 / 4", tall: "2 / 3", square: "1 / 1", landscape: "4 / 3" } as const;
export type ImageRatio = keyof typeof IMAGE_RATIOS;

export const productCardSchema = z.object({
  imageRatio: z.enum(["portrait", "tall", "square", "landscape"]).default("tall"),
  secondImageOnHover: z.boolean().default(true),
  showBadges: z.boolean().default(true),
  badgeStyle: z.enum(["minimal", "filled"]).default("minimal"),
  showComparePrice: z.boolean().default(true),
  showDiscountPercent: z.boolean().default(true),
  showQuickAdd: z.boolean().default(false),
  showWishlist: z.boolean().default(true),
  showRating: z.boolean().default(false),
  textAlign: z.enum(["left", "center"]).default("left"),
});
export type ProductCardSettings = z.infer<typeof productCardSchema>;
