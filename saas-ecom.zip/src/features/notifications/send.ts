import "server-only";
import { createSupabaseAdminClient } from "@/lib/supabase/admin";
import { serverEnv } from "@/lib/env/server";
import { sha256Hex } from "@/lib/crypto";
import { formatMoney, toMinor } from "@/lib/money";
import { logger } from "@/lib/observability/logger";
import { formatOrderNumber } from "@/features/checkout/settings";
import { orderPath, tenantStoreOrigin } from "@/features/checkout/order-access";
import {
  CUSTOMISABLE_KEYS,
  DEFAULT_TEMPLATES,
  ORDER_NOTIFICATION_KEYS,
  renderEmailHtml,
  renderHtmlBody,
  renderSubject,
  renderText,
  type OrderNotificationKey,
  type TemplateVars,
} from "./templates";

const RETURN_STATUS_LABELS: Record<string, string> = {
  requested: "Requested",
  approved: "Approved",
  rejected: "Rejected",
  received: "Received by the store",
  refunded: "Refunded",
  closed: "Closed",
};

type SendResult = { status: "sent" | "skipped" | "failed"; providerMessageId?: string; error?: string };

/** Transactional email via Resend's REST API; logs instead of sending when RESEND_API_KEY is unset. */
async function deliverEmail(msg: { to: string; subject: string; html: string; text: string; replyTo?: string | null; idempotencyKey: string }): Promise<SendResult> {
  const env = serverEnv();
  if (!env.RESEND_API_KEY) {
    logger.info("email.logged", { subject: msg.subject, reason: "RESEND_API_KEY not set" });
    return { status: "skipped", error: "email provider not configured" };
  }
  try {
    const res = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { Authorization: `Bearer ${env.RESEND_API_KEY}`, "Content-Type": "application/json", "Idempotency-Key": msg.idempotencyKey.slice(0, 256) },
      body: JSON.stringify({ from: env.EMAIL_FROM, to: [msg.to], subject: msg.subject, html: msg.html, text: msg.text, ...(msg.replyTo ? { reply_to: msg.replyTo } : {}) }),
      signal: AbortSignal.timeout(10_000),
    });
    const body = (await res.json().catch(() => ({}))) as { id?: string; message?: string };
    if (!res.ok) return { status: "failed", error: `resend ${res.status}: ${String(body.message ?? "").slice(0, 200)}` };
    return { status: "sent", providerMessageId: body.id };
  } catch (err) {
    return { status: "failed", error: err instanceof Error ? err.message.slice(0, 200) : "network error" };
  }
}

export type NotificationExtras = { refundAmountMinor?: number; cancelReason?: string | null; returnStatus?: string | null };

/**
 * Sends an order email to the shopper. Tenant id must be server-resolved (verified host,
 * membership or verified webhook); the order is loaded with BOTH tenant and id filters.
 * Never throws — a failed email must not undo an order state change.
 */
export async function sendOrderNotification(tenantId: string, orderId: string, key: OrderNotificationKey, extras: NotificationExtras = {}): Promise<void> {
  if (!ORDER_NOTIFICATION_KEYS.includes(key)) return;
  const admin = createSupabaseAdminClient();
  let recipientHash = "none";
  try {
    const { data: order } = await admin
      .from("orders")
      .select("id, order_number, email, grand_total, payment_method, customer_snapshot, shipping_address, cancel_reason, refunded_total")
      .eq("tenant_id", tenantId)
      .eq("id", orderId)
      .maybeSingle();
    if (!order) return;
    if (!order.email) {
      await admin.from("notification_logs").insert({ tenant_id: tenantId, template_key: key, channel: "email", recipient_hash: recipientHash, status: "skipped", error: "no email" });
      return;
    }
    recipientHash = sha256Hex(order.email.toLowerCase());

    const [store, template, shipment, items, origin, latestReturn] = await Promise.all([
      admin.from("stores").select("name, email, order_prefix").eq("tenant_id", tenantId).single(),
      CUSTOMISABLE_KEYS.has(key)
        ? admin.from("notification_templates").select("subject, body").eq("tenant_id", tenantId).eq("key", key).eq("channel", "email").eq("active", true).maybeSingle()
        : Promise.resolve({ data: null }),
      admin.from("shipments").select("carrier, tracking_number, tracking_url").eq("tenant_id", tenantId).eq("order_id", orderId).order("created_at", { ascending: false }).limit(1).maybeSingle(),
      admin.from("order_items").select("product_title, variant_title, quantity, line_total").eq("tenant_id", tenantId).eq("order_id", orderId),
      tenantStoreOrigin(tenantId),
      key === "return_update" && !extras.returnStatus
        ? admin.from("returns").select("status").eq("tenant_id", tenantId).eq("order_id", orderId).order("updated_at", { ascending: false }).limit(1).maybeSingle()
        : Promise.resolve({ data: null }),
    ]);

    const storeName = store.data?.name ?? "Our store";
    const address = (order.shipping_address ?? {}) as Record<string, unknown>;
    const snapshot = (order.customer_snapshot ?? {}) as Record<string, unknown>;
    const customerName = String(snapshot.first_name ?? address.name ?? "there").split(" ")[0] || "there";
    const vars: TemplateVars = {
      store_name: storeName,
      store_url: origin,
      customer_name: customerName,
      order_number: formatOrderNumber(store.data?.order_prefix ?? "#", order.order_number),
      order_total: formatMoney(toMinor(order.grand_total)),
      order_url: origin ? `${origin}${orderPath(order.id)}` : null,
      payment_method: order.payment_method === "cod" ? "Cash on Delivery" : "Paid online",
      carrier: shipment.data?.carrier ?? "our courier partner",
      tracking_number: shipment.data?.tracking_number ?? "—",
      tracking_url: shipment.data?.tracking_url ?? "",
      refund_amount: extras.refundAmountMinor !== undefined ? formatMoney(extras.refundAmountMinor) : formatMoney(toMinor(order.refunded_total)),
      cancel_reason: extras.cancelReason ?? order.cancel_reason ?? "",
      return_status: extras.returnStatus ?? RETURN_STATUS_LABELS[latestReturn.data?.status ?? ""] ?? "",
    };
    const tpl = template.data?.body ? { subject: template.data.subject || DEFAULT_TEMPLATES[key].subject, body: template.data.body } : DEFAULT_TEMPLATES[key];
    const subject = renderSubject(tpl.subject, vars);
    const html = renderEmailHtml({
      storeName,
      bodyHtml: renderHtmlBody(tpl.body, vars),
      ctaUrl: vars.order_url,
      lines: key === "order_placed" || key === "order_paid" ? (items.data ?? []).map((i) => ({ title: i.product_title, variant: i.variant_title, quantity: i.quantity, total: formatMoney(toMinor(i.line_total)) })) : undefined,
      total: key === "order_placed" || key === "order_paid" ? vars.order_total : null,
    });
    const text = `${renderText(tpl.body, vars)}${vars.order_url ? `\n\nView your order: ${vars.order_url}` : ""}`;

    const result = await deliverEmail({ to: order.email, subject, html, text, replyTo: store.data?.email, idempotencyKey: `${tenantId}:${orderId}:${key}:${extras.refundAmountMinor ?? ""}` });
    await admin.from("notification_logs").insert({
      tenant_id: tenantId,
      template_key: key,
      channel: "email",
      recipient_hash: recipientHash,
      status: result.status,
      provider_message_id: result.providerMessageId ?? null,
      error: result.error ?? null,
    });
    if (result.status === "failed") logger.warn("notification.failed", { tenantId, key, error: result.error });
  } catch (err) {
    logger.error("notification.error", { tenantId, key, error: err });
    await admin
      .from("notification_logs")
      .insert({ tenant_id: tenantId, template_key: key, channel: "email", recipient_hash: recipientHash, status: "failed", error: "internal error" })
      .then(
        () => undefined,
        () => undefined,
      );
  }
}

/** Plain transactional email (team invites and similar). Logs instead of sending when no provider is configured. */
export async function sendSimpleEmail(to: string, subject: string, text: string, idempotencyKey: string): Promise<"sent" | "skipped" | "failed"> {
  const escaped = text.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/\n/g, "<br>");
  const r = await deliverEmail({ to, subject, text, html: `<div style="font-family:system-ui,sans-serif;font-size:15px;line-height:1.5">${escaped}</div>`, idempotencyKey });
  return r.status;
}
