/**
 * Notification templates. PURE (unit tested). Seller-authored templates are treated as PLAIN
 * TEXT: the whole template is HTML-escaped, then `{{placeholder}}` values (also escaped) are
 * substituted, so neither a seller nor a shopper-supplied value (name, address) can inject markup.
 */

export const ORDER_NOTIFICATION_KEYS = [
  "order_placed",
  "order_paid",
  "order_shipped",
  "order_delivered",
  "order_cancelled",
  "refund_processed",
  "return_update",
] as const;
export type OrderNotificationKey = (typeof ORDER_NOTIFICATION_KEYS)[number];

/** Keys a seller can override in `notification_templates` (DB CHECK list). */
export const CUSTOMISABLE_KEYS: ReadonlySet<string> = new Set(["order_placed", "order_shipped", "order_delivered", "order_cancelled", "refund_processed", "return_update"]);

export const PLACEHOLDERS = [
  "store_name",
  "store_url",
  "customer_name",
  "order_number",
  "order_total",
  "order_url",
  "payment_method",
  "carrier",
  "tracking_number",
  "tracking_url",
  "refund_amount",
  "cancel_reason",
  "return_status",
] as const;
export type Placeholder = (typeof PLACEHOLDERS)[number];
export type TemplateVars = Partial<Record<Placeholder, string | null | undefined>>;

export type Template = { subject: string; body: string };

export const DEFAULT_TEMPLATES: Record<OrderNotificationKey, Template> = {
  order_placed: {
    subject: "Order {{order_number}} received — {{store_name}}",
    body: "Hi {{customer_name}},\n\nThank you for shopping with {{store_name}}! We've received your order {{order_number}} for {{order_total}} ({{payment_method}}).\n\nWe'll let you know as soon as it ships.",
  },
  order_paid: {
    subject: "Payment received for order {{order_number}}",
    body: "Hi {{customer_name}},\n\nWe've received your payment of {{order_total}} for order {{order_number}}. Your order is confirmed and we're getting it ready.",
  },
  order_shipped: {
    subject: "Your order {{order_number}} has shipped",
    body: "Hi {{customer_name}},\n\nGood news — order {{order_number}} is on its way via {{carrier}}.\nTracking number: {{tracking_number}}\n{{tracking_url}}",
  },
  order_delivered: {
    subject: "Order {{order_number}} delivered",
    body: "Hi {{customer_name}},\n\nYour order {{order_number}} has been delivered. We hope you love it! If anything isn't right, you can request a return from your account.",
  },
  order_cancelled: {
    subject: "Order {{order_number}} cancelled",
    body: "Hi {{customer_name}},\n\nYour order {{order_number}} has been cancelled. {{cancel_reason}}\n\nIf you paid online, any amount charged will be refunded to the original payment method.",
  },
  refund_processed: {
    subject: "Refund processed for order {{order_number}}",
    body: "Hi {{customer_name}},\n\nWe've processed a refund of {{refund_amount}} for order {{order_number}}. Depending on your bank it can take 5–7 working days to show up.",
  },
  return_update: {
    subject: "Update on your return for order {{order_number}}",
    body: "Hi {{customer_name}},\n\nThere's an update on your return request for order {{order_number}}: {{return_status}}. Open your order to see the details.",
  },
};

const ESCAPES: Record<string, string> = { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" };

export function escapeHtml(value: string): string {
  return value.replace(/[&<>"']/g, (c) => ESCAPES[c]!);
}

const PLACEHOLDER_RE = /\{\{\s*([a-z_]{1,40})\s*\}\}/g;
const KNOWN: ReadonlySet<string> = new Set(PLACEHOLDERS);

/** Plain-text substitution (for subjects and the text/plain part). Unknown placeholders render empty. */
export function renderText(template: string, vars: TemplateVars): string {
  return template.replace(PLACEHOLDER_RE, (_m, key: string) => (KNOWN.has(key) ? (vars[key as Placeholder] ?? "") : "")).trim();
}

/** Subject lines: single line, no control characters (header-injection safe), max 200 chars. */
export function renderSubject(template: string, vars: TemplateVars): string {
  return renderText(template, vars)
    .replace(/[\u0000-\u001f\u007f]+/g, " ")
    .replace(/\s{2,}/g, " ")
    .slice(0, 200)
    .trim();
}

/** HTML body: escape template AND values, then turn blank-line paragraphs / newlines into markup. */
export function renderHtmlBody(template: string, vars: TemplateVars): string {
  const escapedTemplate = escapeHtml(template);
  const substituted = escapedTemplate.replace(PLACEHOLDER_RE, (_m, key: string) => (KNOWN.has(key) ? escapeHtml(vars[key as Placeholder] ?? "") : ""));
  return substituted
    .trim()
    .split(/\n{2,}/)
    .map((p) => `<p style="margin:0 0 16px">${p.replace(/\n/g, "<br>")}</p>`)
    .join("");
}

export type EmailSummaryLine = { title: string; variant?: string | null; quantity: number; total: string };

/** Full HTML email. Every dynamic value is escaped; the CTA URL must be https or http://*.localhost. */
export function renderEmailHtml(input: { storeName: string; bodyHtml: string; ctaUrl?: string | null; ctaLabel?: string; lines?: EmailSummaryLine[]; total?: string | null }): string {
  const cta = input.ctaUrl && isSafeEmailUrl(input.ctaUrl)
    ? `<p style="margin:24px 0"><a href="${escapeHtml(input.ctaUrl)}" style="background:#111;color:#fff;padding:12px 20px;border-radius:6px;text-decoration:none;display:inline-block">${escapeHtml(input.ctaLabel ?? "View your order")}</a></p>`
    : "";
  const rows = (input.lines ?? [])
    .map(
      (l) =>
        `<tr><td style="padding:6px 0">${escapeHtml(l.title)}${l.variant ? ` <span style="color:#666">(${escapeHtml(l.variant)})</span>` : ""} × ${l.quantity}</td><td style="padding:6px 0;text-align:right">${escapeHtml(l.total)}</td></tr>`,
    )
    .join("");
  const table = rows
    ? `<table role="presentation" width="100%" style="border-collapse:collapse;border-top:1px solid #eee;margin-top:8px">${rows}${input.total ? `<tr><td style="padding:8px 0;border-top:1px solid #eee;font-weight:600">Total</td><td style="padding:8px 0;border-top:1px solid #eee;text-align:right;font-weight:600">${escapeHtml(input.total)}</td></tr>` : ""}</table>`
    : "";
  return `<!doctype html><html><body style="margin:0;background:#f6f6f6;font-family:-apple-system,Segoe UI,Roboto,sans-serif;color:#111"><div style="max-width:560px;margin:0 auto;padding:24px"><div style="background:#fff;border-radius:8px;padding:24px"><h1 style="font-size:18px;margin:0 0 16px">${escapeHtml(input.storeName)}</h1>${input.bodyHtml}${cta}${table}</div></div></body></html>`;
}

export function isSafeEmailUrl(url: string): boolean {
  try {
    const u = new URL(url);
    return u.protocol === "https:" || (u.protocol === "http:" && (u.hostname === "localhost" || u.hostname.endsWith(".localhost")));
  } catch {
    return false;
  }
}
