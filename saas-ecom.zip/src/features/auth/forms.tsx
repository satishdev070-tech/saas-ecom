"use client";

import Link from "next/link";
import { useActionState } from "react";
import { TextField } from "@/components/ui/field";
import { FormMessage, SubmitButton, fieldErrors } from "@/components/ui/form";
import { forgotPasswordAction, resetPasswordAction, signInAction, signUpAction } from "./actions";

export function SignInForm({ next }: { next?: string }) {
  const [state, action] = useActionState(signInAction, null);
  const errors = fieldErrors(state);
  return (
    <form action={action} className="space-y-4" noValidate>
      <input type="hidden" name="next" value={next ?? ""} />
      <FormMessage state={state} />
      <TextField label="Email" name="email" type="email" autoComplete="email" required errors={errors.email} />
      <TextField label="Password" name="password" type="password" autoComplete="current-password" required errors={errors.password} />
      <SubmitButton className="w-full">Sign in</SubmitButton>
      <div className="flex justify-between text-sm">
        <Link href="/forgot-password" className="text-muted hover:text-foreground">
          Forgot password?
        </Link>
        <Link href={next ? `/signup?next=${encodeURIComponent(next)}` : "/signup"} className="font-medium text-accent">
          Create account
        </Link>
      </div>
    </form>
  );
}

export function SignUpForm({ next }: { next?: string }) {
  const [state, action] = useActionState(signUpAction, null);
  const errors = fieldErrors(state);
  if (state?.ok && state.data.needsConfirmation) {
    return (
      <div role="status" className="space-y-2 text-sm">
        <h2 className="text-base font-semibold">Check your email</h2>
        <p className="text-muted">We sent you a confirmation link. Open it to finish creating your account.</p>
      </div>
    );
  }
  return (
    <form action={action} className="space-y-4" noValidate>
      <input type="hidden" name="next" value={next ?? ""} />
      <FormMessage state={state} />
      <TextField label="Your name" name="displayName" autoComplete="name" required errors={errors.displayName} />
      <TextField label="Email" name="email" type="email" autoComplete="email" required errors={errors.email} />
      <TextField label="Password" name="password" type="password" autoComplete="new-password" required errors={errors.password} hint="At least 10 characters with a letter and a number." />
      <SubmitButton className="w-full">Create account</SubmitButton>
      <p className="text-center text-sm text-muted">
        Already have an account?{" "}
        <Link href="/login" className="font-medium text-accent">
          Sign in
        </Link>
      </p>
    </form>
  );
}

export function ForgotPasswordForm() {
  const [state, action] = useActionState(forgotPasswordAction, null);
  const errors = fieldErrors(state);
  return (
    <form action={action} className="space-y-4" noValidate>
      <FormMessage state={state} success="If an account exists for that email, a reset link is on its way." />
      <TextField label="Email" name="email" type="email" autoComplete="email" required errors={errors.email} />
      <SubmitButton className="w-full">Send reset link</SubmitButton>
    </form>
  );
}

export function ResetPasswordForm() {
  const [state, action] = useActionState(resetPasswordAction, null);
  const errors = fieldErrors(state);
  return (
    <form action={action} className="space-y-4" noValidate>
      <FormMessage state={state} />
      <TextField label="New password" name="password" type="password" autoComplete="new-password" required errors={errors.password} />
      <TextField label="Confirm password" name="confirm" type="password" autoComplete="new-password" required errors={errors.confirm} />
      <SubmitButton className="w-full">Update password</SubmitButton>
    </form>
  );
}
