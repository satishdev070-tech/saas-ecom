"use server";

import { redirect } from "next/navigation";
import { createSupabaseServerClient } from "@/lib/supabase/server";
import { runAction, type ActionResult } from "@/lib/actions/result";
import { formToObject } from "@/lib/actions/form";
import { parseInput } from "@/lib/validation/common";
import { AppError } from "@/lib/errors";
import { safeRedirectPath } from "@/lib/http/safe-redirect";
import { clientIpKey, rateLimit } from "@/lib/rate-limit";
import { platformOrigin } from "@/lib/platform/urls";
import { forgotSchema, resetSchema, signInSchema, signUpSchema } from "./schemas";

export async function signInAction(_prev: ActionResult | null, fd: FormData): Promise<ActionResult> {
  let next = "/dashboard";
  const result = await runAction("auth.signIn", async () => {
    const input = parseInput(signInSchema, formToObject(fd));
    next = safeRedirectPath(input.next, "/dashboard");
    await rateLimit("login:ip", await clientIpKey(), 20, 600);
    await rateLimit("login:email", input.email, 8, 600);
    const supabase = await createSupabaseServerClient();
    const { error } = await supabase.auth.signInWithPassword({ email: input.email, password: input.password });
    // Same message for unknown email and wrong password (no account enumeration).
    if (error) throw new AppError("UNAUTHENTICATED", { message: "Email or password is incorrect." , fieldErrors: { _form: ["Email or password is incorrect."] } });
  });
  if (result.ok) redirect(next);
  return result;
}

export async function signUpAction(_prev: ActionResult<{ needsConfirmation: boolean }> | null, fd: FormData): Promise<ActionResult<{ needsConfirmation: boolean }>> {
  let next = "/onboarding";
  let confirmed = false;
  const result = await runAction("auth.signUp", async () => {
    const input = parseInput(signUpSchema, formToObject(fd));
    next = safeRedirectPath(input.next, "/onboarding");
    await rateLimit("signup:ip", await clientIpKey(), 10, 3600);
    const supabase = await createSupabaseServerClient();
    const { data, error } = await supabase.auth.signUp({
      email: input.email,
      password: input.password,
      options: {
        data: { display_name: input.displayName },
        emailRedirectTo: `${platformOrigin()}/auth/callback?next=${encodeURIComponent(next)}`,
      },
    });
    if (error) {
      throw new AppError("VALIDATION", { fieldErrors: { _form: [error.message.includes("registered") ? "An account with this email already exists." : "Couldn't create your account. Please try again."] } });
    }
    confirmed = Boolean(data.session);
    return { needsConfirmation: !data.session };
  });
  if (result.ok && confirmed) redirect(next);
  return result;
}

export async function forgotPasswordAction(_prev: ActionResult | null, fd: FormData): Promise<ActionResult> {
  return runAction("auth.forgotPassword", async () => {
    const input = parseInput(forgotSchema, formToObject(fd));
    await rateLimit("reset:ip", await clientIpKey(), 5, 3600);
    await rateLimit("reset:email", input.email, 3, 3600);
    const supabase = await createSupabaseServerClient();
    // Always report success so the form doesn't reveal which emails have accounts.
    await supabase.auth.resetPasswordForEmail(input.email, { redirectTo: `${platformOrigin()}/auth/callback?next=/reset-password` });
  });
}

export async function resetPasswordAction(_prev: ActionResult | null, fd: FormData): Promise<ActionResult> {
  const result = await runAction("auth.resetPassword", async () => {
    const input = parseInput(resetSchema, formToObject(fd));
    const supabase = await createSupabaseServerClient();
    const { error } = await supabase.auth.updateUser({ password: input.password });
    if (error) throw new AppError("UNAUTHENTICATED", { fieldErrors: { _form: ["Your reset link has expired. Request a new one."] } });
  });
  if (result.ok) redirect("/dashboard");
  return result;
}

export async function signOutAction(): Promise<void> {
  const supabase = await createSupabaseServerClient();
  await supabase.auth.signOut();
  redirect("/login");
}
