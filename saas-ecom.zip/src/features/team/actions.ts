"use server";

import { refresh } from "next/cache";
import { z } from "zod";
import { runAction, type ActionResult } from "@/lib/actions/result";
import { formToObject } from "@/lib/actions/form";
import { email, parseInput } from "@/lib/validation/common";
import { AppError } from "@/lib/errors";
import { assertPermission, requireTenant } from "@/lib/tenant/membership";
import { createSupabaseServerClient } from "@/lib/supabase/server";
import { mapDbError } from "@/lib/supabase/errors";
import { hashToken, randomToken } from "@/lib/crypto";
import { rateLimit } from "@/lib/rate-limit";
import { platformOrigin } from "@/lib/platform/urls";
import { audit } from "@/lib/audit";
import { sendSimpleEmail } from "@/features/notifications/send";

const ROLES = ["admin", "manager", "staff", "viewer"] as const;

async function manager() {
  const ctx = await requireTenant();
  assertPermission(ctx, "members.manage");
  return ctx;
}

export async function inviteMemberAction(_prev: ActionResult<{ link: string }> | null, fd: FormData): Promise<ActionResult<{ link: string }>> {
  const result = await runAction("team.invite", async () => {
    const ctx = await manager();
    const v = parseInput(z.object({ email, role: z.enum(ROLES) }), formToObject(fd));
    await rateLimit("team:invite", ctx.tenantId, 30, 3600);
    const token = randomToken(32);
    const supabase = await createSupabaseServerClient();
    const { error } = await supabase.from("tenant_invitations").insert({
      tenant_id: ctx.tenantId,
      email: v.email,
      role: v.role,
      token_hash: hashToken(token),
      expires_at: new Date(Date.now() + 7 * 86400_000).toISOString(),
      invited_by: ctx.user.id,
    });
    if (error?.code === "23505") throw new AppError("CONFLICT", { message: "There's already an open invitation for that email.", fieldErrors: { email: ["Already invited"] } });
    if (error) throw mapDbError(error);
    const link = `${platformOrigin()}/invite/${token}`;
    await sendSimpleEmail(v.email, `You're invited to ${ctx.tenantName}`, `${ctx.user.displayName ?? "A colleague"} invited you to help run ${ctx.tenantName} as ${v.role}.\n\nAccept the invitation: ${link}\n\nThis link expires in 7 days.`, `invite-${hashToken(token).slice(0, 24)}`);
    await audit({ tenantId: ctx.tenantId, actorUserId: ctx.user.id, action: "member.invited", entityType: "invitation", metadata: { email: v.email, role: v.role } });
    return { link };
  });
  if (result.ok) refresh();
  return result;
}

export async function revokeInvitationAction(_prev: ActionResult | null, fd: FormData): Promise<ActionResult> {
  const result = await runAction("team.revoke", async () => {
    const ctx = await manager();
    const { id } = parseInput(z.object({ id: z.uuid() }), formToObject(fd));
    const { error } = await (await createSupabaseServerClient()).from("tenant_invitations").update({ revoked_at: new Date().toISOString() }).eq("id", id).eq("tenant_id", ctx.tenantId);
    if (error) throw mapDbError(error);
    await audit({ tenantId: ctx.tenantId, actorUserId: ctx.user.id, action: "member.invite_revoked", entityType: "invitation", entityId: id });
  });
  if (result.ok) refresh();
  return result;
}

export async function changeMemberRoleAction(_prev: ActionResult | null, fd: FormData): Promise<ActionResult> {
  const result = await runAction("team.role", async () => {
    const ctx = await manager();
    const v = parseInput(z.object({ membershipId: z.uuid(), role: z.enum(ROLES) }), formToObject(fd));
    const { data, error } = await (await createSupabaseServerClient()).from("tenant_memberships").update({ role: v.role }).eq("id", v.membershipId).eq("tenant_id", ctx.tenantId).neq("role", "owner").select("user_id");
    if (error) throw mapDbError(error);
    if (!data?.length) throw new AppError("FORBIDDEN", { message: "The owner's role can't be changed." });
    if (data[0]!.user_id === ctx.user.id) throw new AppError("FORBIDDEN", { message: "You can't change your own role." });
    await audit({ tenantId: ctx.tenantId, actorUserId: ctx.user.id, action: "member.role_changed", entityType: "membership", entityId: v.membershipId, metadata: { role: v.role } });
  });
  if (result.ok) refresh();
  return result;
}

export async function removeMemberAction(_prev: ActionResult | null, fd: FormData): Promise<ActionResult> {
  const result = await runAction("team.remove", async () => {
    const ctx = await manager();
    const { membershipId } = parseInput(z.object({ membershipId: z.uuid() }), formToObject(fd));
    const supabase = await createSupabaseServerClient();
    const { data: m } = await supabase.from("tenant_memberships").select("user_id, role").eq("id", membershipId).eq("tenant_id", ctx.tenantId).maybeSingle();
    if (!m) throw new AppError("NOT_FOUND");
    if (m.role === "owner" || m.user_id === ctx.user.id) throw new AppError("FORBIDDEN", { message: "You can't remove the owner or yourself." });
    const { error } = await supabase.from("tenant_memberships").delete().eq("id", membershipId).eq("tenant_id", ctx.tenantId);
    if (error) throw mapDbError(error);
    await audit({ tenantId: ctx.tenantId, actorUserId: ctx.user.id, action: "member.removed", entityType: "membership", entityId: membershipId });
  });
  if (result.ok) refresh();
  return result;
}
