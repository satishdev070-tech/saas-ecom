"use client";

import { useActionState, useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { completeTestPaymentAction, confirmRazorpayPaymentAction } from "@/features/checkout/actions";
import { formatMoney } from "@/lib/money";

type RazorpayOptions = Record<string, unknown> & { handler: (r: { razorpay_order_id: string; razorpay_payment_id: string; razorpay_signature: string }) => void };
declare global {
  interface Window {
    Razorpay?: new (o: RazorpayOptions) => { open: () => void; on: (e: string, cb: (r: { error?: { description?: string } }) => void) => void };
  }
}

const SCRIPT = "https://checkout.razorpay.com/v1/checkout.js";

function loadScript(): Promise<boolean> {
  if (window.Razorpay) return Promise.resolve(true);
  return new Promise((resolve) => {
    const s = document.createElement("script");
    s.src = SCRIPT;
    s.async = true;
    s.onload = () => resolve(true);
    s.onerror = () => resolve(false);
    document.body.appendChild(s);
  });
}

export function RazorpayPay({
  token,
  keyId,
  providerOrderId,
  amountMinor,
  storeName,
  orderNumber,
  prefill,
  lastError,
}: {
  token: string;
  keyId: string;
  providerOrderId: string;
  amountMinor: number;
  storeName: string;
  orderNumber: string;
  prefill: { name?: string | null; email?: string | null; contact?: string | null };
  lastError: string | null;
}) {
  const router = useRouter();
  const [status, setStatus] = useState<"idle" | "loading" | "verifying" | "error">("idle");
  const [message, setMessage] = useState<string | null>(lastError);
  const opened = useRef(false);

  async function pay() {
    setStatus("loading");
    if (!(await loadScript()) || !window.Razorpay) {
      setStatus("error");
      setMessage("Couldn't load the payment window. Check your connection and try again.");
      return;
    }
    const rzp = new window.Razorpay({
      key: keyId,
      order_id: providerOrderId,
      amount: amountMinor,
      currency: "INR",
      name: storeName,
      description: `Order ${orderNumber}`,
      prefill: { name: prefill.name ?? undefined, email: prefill.email ?? undefined, contact: prefill.contact ?? undefined },
      modal: { ondismiss: () => setStatus("idle") },
      handler: async (r) => {
        setStatus("verifying");
        const res = await confirmRazorpayPaymentAction({ t: token, ...r });
        if (res.ok) router.replace(res.data.redirectTo);
        else {
          setStatus("error");
          setMessage(res.error.message);
        }
      },
    });
    rzp.on("payment.failed", (r) => {
      setStatus("error");
      setMessage(r.error?.description ?? "Payment failed. You can try again.");
    });
    rzp.open();
    setStatus("idle");
  }

  useEffect(() => {
    if (opened.current) return;
    opened.current = true;
    void pay();
    // open once on arrival; the button re-opens it
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div className="space-y-4">
      <button type="button" onClick={() => void pay()} disabled={status === "loading" || status === "verifying"} className="sf-btn w-full">
        {status === "verifying" ? "Confirming payment…" : status === "loading" ? "Opening payment…" : `Pay ${formatMoney(amountMinor)}`}
      </button>
      {message ? (
        <p role="alert" className="text-sm text-[var(--sf-sale)]">
          {message}
        </p>
      ) : null}
    </div>
  );
}

/** Test-mode payment (manual provider) for stores without Razorpay configured. */
export function TestPay({ token }: { token: string }) {
  const [state, action, pending] = useActionState(completeTestPaymentAction, null);
  return (
    <form action={action} className="space-y-2">
      <input type="hidden" name="t" value={token} />
      <button type="submit" disabled={pending} className="sf-btn w-full">
        {pending ? "Processing…" : "Complete test payment"}
      </button>
      <p className="sf-muted text-xs">Test mode: no real money is charged.</p>
      {state && !state.ok ? <p role="alert" className="text-sm text-[var(--sf-sale)]">{state.error.message}</p> : null}
    </form>
  );
}
