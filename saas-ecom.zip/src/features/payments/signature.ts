import { createHmac, timingSafeEqual } from "node:crypto";

/** Pure signature helpers (unit tested). Constant-time comparisons only. */

export function hmacSha256Hex(secret: string, payload: string | Buffer): string {
  return createHmac("sha256", secret).update(payload).digest("hex");
}

/** Constant-time comparison of two hex strings (false on any length/format mismatch). */
export function safeEqualHex(expectedHex: string, givenHex: string | null | undefined): boolean {
  if (!givenHex || !/^[0-9a-f]+$/i.test(givenHex) || givenHex.length !== expectedHex.length) return false;
  const a = Buffer.from(expectedHex, "hex");
  const b = Buffer.from(givenHex.toLowerCase(), "hex");
  return a.length === b.length && timingSafeEqual(a, b);
}

/**
 * Razorpay Checkout success handler signature:
 * HMAC_SHA256(key_secret, razorpay_order_id + "|" + razorpay_payment_id), hex.
 */
export function verifyRazorpayPaymentSignature(input: { orderId: string; paymentId: string; signature: string | null | undefined; keySecret: string }): boolean {
  if (!input.orderId || !input.paymentId || !input.keySecret) return false;
  return safeEqualHex(hmacSha256Hex(input.keySecret, `${input.orderId}|${input.paymentId}`), input.signature);
}

/** Razorpay webhook: X-Razorpay-Signature = HMAC_SHA256(webhook_secret, raw request body), hex. */
export function verifyRazorpayWebhookSignature(rawBody: string | Buffer, signature: string | null | undefined, webhookSecret: string): boolean {
  if (!webhookSecret) return false;
  return safeEqualHex(hmacSha256Hex(webhookSecret, rawBody), signature);
}

/** Constant-time check of an `Authorization: Bearer <secret>` header (hash first so lengths match). */
export function bearerMatches(header: string | null | undefined, secret: string | undefined): boolean {
  if (!secret || !header?.startsWith("Bearer ")) return false;
  const given = createHmac("sha256", "cron").update(header.slice(7)).digest();
  const expected = createHmac("sha256", "cron").update(secret).digest();
  return timingSafeEqual(given, expected);
}
