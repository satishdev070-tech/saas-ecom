import "server-only";
import { createSupabaseAdminClient } from "@/lib/supabase/admin";
import { decryptSecret, encryptSecret } from "@/lib/crypto";
import { mapDbError } from "@/lib/supabase/errors";
import { AppError } from "@/lib/errors";
import { audit } from "@/lib/audit";
import { storeOrigin } from "@/lib/platform/urls";
import { assertPermission, type TenantContext } from "@/lib/tenant/membership";
import { serverEnv } from "@/lib/env/server";
import { logger } from "@/lib/observability/logger";

export type RazorpayCredentials = { keyId: string; keySecret: string; webhookSecret: string | null; mode: "test" | "live" };

/**
 * Tenant Razorpay credentials from `tenant_payment_settings` (no RLS policies: server only).
 * Secrets are AES-256-GCM ciphertext written with `encryptSecret(value)` (default purpose
 * "tenant-secrets"); they are decrypted only here, in memory, per request.
 */
export async function loadRazorpayCredentials(tenantId: string, opts: { requireEnabled?: boolean } = {}): Promise<RazorpayCredentials | null> {
  const { data, error } = await createSupabaseAdminClient()
    .from("tenant_payment_settings")
    .select("provider, mode, key_id, key_secret_encrypted, webhook_secret_encrypted, enabled")
    .eq("tenant_id", tenantId)
    .maybeSingle();
  if (error || !data || data.provider !== "razorpay") return null;
  if ((opts.requireEnabled ?? true) && !data.enabled) return null;
  if (!data.key_id || !data.key_secret_encrypted) return null;
  try {
    return {
      keyId: data.key_id,
      keySecret: decryptSecret(data.key_secret_encrypted),
      webhookSecret: data.webhook_secret_encrypted ? decryptSecret(data.webhook_secret_encrypted) : null,
      mode: data.mode === "live" ? "live" : "test",
    };
  } catch (err) {
    logger.error("payments.credentials_decrypt_failed", { tenantId, error: err });
    return null;
  }
}

export type OnlineProviderId = "razorpay" | "manual";

/** Which provider handles "Pay online" for this tenant, if any. The manual test provider never runs in production. */
export async function onlinePaymentProvider(tenantId: string): Promise<OnlineProviderId | null> {
  if (await loadRazorpayCredentials(tenantId)) return "razorpay";
  return isManualProviderEnabled() ? "manual" : null;
}

export function isManualProviderEnabled(): boolean {
  return serverEnv().NODE_ENV !== "production" && process.env.NODE_ENV !== "production";
}

// ---------------------------------------------------------------------------------------------
// Seller settings helpers (the dashboard Payments settings page calls these; UI lives with D).

export type RazorpaySettingsSummary = {
  configured: boolean;
  enabled: boolean;
  mode: "test" | "live";
  keyId: string | null;
  hasWebhookSecret: boolean;
  keySecretLast4: string | null;
  updatedAt: string | null;
};

const KEY_ID_RE = /^rzp_(test|live)_[A-Za-z0-9]{8,32}$/;

/** Read-only summary for the settings page. Secrets never leave the server (last 4 chars only). */
export async function getRazorpaySettingsSummary(ctx: TenantContext): Promise<RazorpaySettingsSummary> {
  assertPermission(ctx, "payments.manage");
  const { data } = await createSupabaseAdminClient()
    .from("tenant_payment_settings")
    .select("mode, key_id, key_secret_encrypted, webhook_secret_encrypted, enabled, updated_at")
    .eq("tenant_id", ctx.tenantId)
    .maybeSingle();
  let last4: string | null = null;
  if (data?.key_secret_encrypted) {
    try {
      last4 = decryptSecret(data.key_secret_encrypted).slice(-4);
    } catch {
      last4 = "????";
    }
  }
  return {
    configured: Boolean(data?.key_id && data.key_secret_encrypted),
    enabled: Boolean(data?.enabled),
    mode: data?.mode === "live" ? "live" : "test",
    keyId: data?.key_id ?? null,
    hasWebhookSecret: Boolean(data?.webhook_secret_encrypted),
    keySecretLast4: last4,
    updatedAt: data?.updated_at ?? null,
  };
}

/**
 * Saves the tenant's Razorpay credentials (payments.manage). Secrets are encrypted with
 * encryptSecret() before they touch the database; blank secret fields keep the stored value.
 * Enabling requires a key id + key secret. Audited (without secret values).
 */
export async function saveRazorpayCredentials(
  ctx: TenantContext,
  input: { keyId?: string | null; keySecret?: string | null; webhookSecret?: string | null; enabled: boolean },
): Promise<RazorpaySettingsSummary> {
  assertPermission(ctx, "payments.manage");
  const keyId = input.keyId?.trim() || null;
  if (keyId && !KEY_ID_RE.test(keyId)) throw new AppError("VALIDATION", { fieldErrors: { keyId: ["Key IDs look like rzp_test_XXXXXXXX or rzp_live_XXXXXXXX"] } });
  const admin = createSupabaseAdminClient();
  const { data: current } = await admin.from("tenant_payment_settings").select("key_id, key_secret_encrypted, webhook_secret_encrypted").eq("tenant_id", ctx.tenantId).maybeSingle();

  const keySecret = input.keySecret?.trim() || null;
  const webhookSecret = input.webhookSecret?.trim() || null;
  const nextKeyId = keyId ?? current?.key_id ?? null;
  const keySecretEncrypted = keySecret ? encryptSecret(keySecret) : (current?.key_secret_encrypted ?? null);
  const webhookSecretEncrypted = webhookSecret ? encryptSecret(webhookSecret) : (current?.webhook_secret_encrypted ?? null);
  if (input.enabled && (!nextKeyId || !keySecretEncrypted)) {
    throw new AppError("VALIDATION", { fieldErrors: { _form: ["Add your Razorpay key id and key secret before enabling online payments."] } });
  }

  const { error } = await admin.from("tenant_payment_settings").upsert(
    {
      tenant_id: ctx.tenantId,
      provider: "razorpay",
      mode: nextKeyId?.startsWith("rzp_live_") ? "live" : "test",
      key_id: nextKeyId,
      key_secret_encrypted: keySecretEncrypted,
      webhook_secret_encrypted: webhookSecretEncrypted,
      enabled: input.enabled,
      updated_at: new Date().toISOString(),
    },
    { onConflict: "tenant_id" },
  );
  if (error) throw mapDbError(error, { tenantId: ctx.tenantId });
  await audit({
    tenantId: ctx.tenantId,
    actorUserId: ctx.user.id,
    action: "payments.razorpay_updated",
    entityType: "tenant_payment_settings",
    entityId: ctx.tenantId,
    metadata: { key_id: nextKeyId, enabled: input.enabled, key_secret_changed: Boolean(keySecret), webhook_secret_changed: Boolean(webhookSecret) },
  });
  return getRazorpaySettingsSummary(ctx);
}

/** Webhook URL the seller pastes into Razorpay (Settings -> Webhooks). Tenant = the store host. */
export function razorpayWebhookUrl(storeHost: string): string {
  return `${storeOrigin(storeHost)}/api/webhooks/razorpay`;
}
