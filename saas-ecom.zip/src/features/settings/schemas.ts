import { z } from "zod";
import { gstin, pincode } from "@/lib/validation/common";
import { bool, intWithDefault, optionalHttpsUrl, optionalInt, optionalRupees, optionalText, rupeesOrZero } from "./fields";
import { TEMPLATE_CHANNELS, TEMPLATE_KEYS } from "./notification-templates";

/** Settings input schemas (pure). */

export const GA4_ID_RE = /^G-[A-Z0-9]{4,15}$/;
export const META_PIXEL_RE = /^\d{8,20}$/;

const blankToUndef = (v: unknown) => (typeof v === "string" && v.trim() === "" ? undefined : v);

const optionalPhone = z.preprocess(
  blankToUndef,
  z
    .string()
    .trim()
    .transform((v) => v.replace(/[\s()-]/g, ""))
    .pipe(z.string().regex(/^(?:\+91|91|0)?[6-9]\d{9}$/, "Enter a valid 10-digit Indian mobile number"))
    .transform((v) => `+91${v.slice(-10)}`)
    .optional(),
);

export const storeDetailsSchema = z.object({
  name: z.string({ error: "Enter your store name" }).trim().min(2, "Enter your store name").max(120),
  tagline: optionalText(200),
  description: optionalText(2000),
  email: z.preprocess(blankToUndef, z.email("Enter a valid email").trim().toLowerCase().max(254).optional()),
  phone: optionalPhone,
  whatsapp: optionalPhone,
  addressLine1: optionalText(200),
  addressLine2: optionalText(200),
  city: optionalText(80),
  state: optionalText(80),
  postalCode: z.preprocess(blankToUndef, pincode.optional()),
  instagram: optionalHttpsUrl,
  facebook: optionalHttpsUrl,
  youtube: optionalHttpsUrl,
  pinterest: optionalHttpsUrl,
  x: optionalHttpsUrl,
  gstin: z.preprocess(blankToUndef, gstin.optional()),
  legalName: optionalText(200),
  seoTitle: optionalText(70),
  seoDescription: optionalText(160),
  ga4: z.preprocess(blankToUndef, z.string().trim().toUpperCase().regex(GA4_ID_RE, "GA4 IDs look like G-XXXXXXXXXX").optional()),
  metaPixel: z.preprocess(blankToUndef, z.string().trim().regex(META_PIXEL_RE, "Meta Pixel IDs are 8–20 digits").optional()),
  orderPrefix: z.preprocess((v) => (v === undefined ? "#" : v), z.string().trim().max(8, "At most 8 characters").regex(/^[A-Za-z0-9#-]*$/, "Letters, numbers, # or - only")),
  lowStockDefault: intWithDefault(0, 100_000, 5),
  removeLogo: bool,
  removeFavicon: bool,
});
export type StoreDetailsInput = z.infer<typeof storeDetailsSchema>;

export const shippingRateSchema = z
  .object({
    id: z.preprocess(blankToUndef, z.uuid().optional()),
    name: z.string({ error: "Enter a name" }).trim().min(1, "Enter a name").max(80),
    price: rupeesOrZero,
    minSubtotal: rupeesOrZero,
    maxSubtotal: optionalRupees,
    minWeight: intWithDefault(0, 100_000, 0),
    maxWeight: optionalInt(1, 100_000),
    pincodePrefixes: z
      .preprocess((v) => (typeof v === "string" ? v : ""), z.string())
      .transform((s) => [...new Set(s.split(/[,\s]+/).map((p) => p.trim()).filter(Boolean))])
      .pipe(z.array(z.string().regex(/^[1-9]\d{0,5}$/, "PIN prefixes are 1–6 digits and can't start with 0")).max(200)),
    daysMin: intWithDefault(0, 60, 3),
    daysMax: intWithDefault(0, 90, 7),
    codAllowed: bool,
    active: bool,
    position: intWithDefault(0, 1000, 0),
  })
  .superRefine((v, ctx) => {
    if (v.maxSubtotal !== null && v.maxSubtotal <= v.minSubtotal) ctx.addIssue({ code: "custom", path: ["maxSubtotal"], message: "Must be more than the minimum" });
    if (v.maxWeight !== null && v.maxWeight <= v.minWeight) ctx.addIssue({ code: "custom", path: ["maxWeight"], message: "Must be more than the minimum weight" });
    if (v.daysMax < v.daysMin) ctx.addIssue({ code: "custom", path: ["daysMax"], message: "Must be at least the minimum days" });
  });
export type ShippingRateInput = z.infer<typeof shippingRateSchema>;

export const pincodeRuleSchema = z.object({
  prefix: z.string({ error: "Enter a PIN prefix" }).trim().regex(/^[1-9]\d{0,5}$/, "1–6 digits, not starting with 0"),
  deliverable: bool,
  codAllowed: bool,
  extraDays: intWithDefault(0, 30, 0),
});

export const codSettingsSchema = z
  .object({ enabled: bool, fee: rupeesOrZero, minOrder: rupeesOrZero, maxOrder: rupeesOrZero })
  .superRefine((v, ctx) => {
    if (v.maxOrder > 0 && v.maxOrder <= v.minOrder) ctx.addIssue({ code: "custom", path: ["maxOrder"], message: "Must be more than the minimum (or 0 for no limit)" });
  });

export const RAZORPAY_KEY_ID_RE = /^rzp_(test|live)_[A-Za-z0-9]{8,32}$/;

export const razorpaySettingsSchema = z
  .object({
    keyId: z.preprocess(blankToUndef, z.string().trim().regex(RAZORPAY_KEY_ID_RE, "Key IDs look like rzp_test_XXXXXXXX or rzp_live_XXXXXXXX").optional()),
    /** Blank = keep the stored secret. */
    keySecret: z.preprocess(blankToUndef, z.string().trim().min(8, "That doesn't look like a key secret").max(200).optional()),
    webhookSecret: z.preprocess(blankToUndef, z.string().trim().min(8, "Use at least 8 characters").max(200).optional()),
    enabled: bool,
  })
  .transform((v) => ({ ...v, mode: v.keyId?.startsWith("rzp_live_") ? ("live" as const) : ("test" as const) }));

export const notificationTemplateSchema = z.object({
  key: z.enum(TEMPLATE_KEYS),
  channel: z.enum(TEMPLATE_CHANNELS).default("email"),
  subject: optionalText(200),
  body: z.string({ error: "Enter the message" }).trim().min(1, "Enter the message").max(20000),
  active: bool,
});
