import "server-only";
import { cache } from "react";
import { createSupabaseServerClient } from "@/lib/supabase/server";
import { createSupabaseAdminClient } from "@/lib/supabase/admin";
import { mapDbError } from "@/lib/supabase/errors";
import { decryptSecret } from "@/lib/crypto";
import { logger } from "@/lib/observability/logger";
import { assertPermission, type TenantContext } from "@/lib/tenant/membership";
import type { Tables } from "@/lib/supabase/database.types";

/** Store profile row for the active tenant (RLS: store.read). Memoised per request. */
export const getStoreProfile = cache(async (tenantId: string): Promise<Tables<"stores">> => {
  const supabase = await createSupabaseServerClient();
  const { data, error } = await supabase.from("stores").select("*").eq("tenant_id", tenantId).single();
  if (error) throw mapDbError(error, { tenantId });
  return data;
});

export async function listShippingRates(tenantId: string) {
  const supabase = await createSupabaseServerClient();
  const { data, error } = await supabase.from("shipping_rates").select("*").eq("tenant_id", tenantId).order("position").order("name");
  if (error) throw mapDbError(error);
  return data;
}

export async function listPincodeRules(tenantId: string) {
  const supabase = await createSupabaseServerClient();
  const { data, error } = await supabase.from("pincode_rules").select("*").eq("tenant_id", tenantId).order("prefix");
  if (error) throw mapDbError(error);
  return data;
}

export async function listNotificationTemplates(tenantId: string) {
  const supabase = await createSupabaseServerClient();
  const { data, error } = await supabase.from("notification_templates").select("*").eq("tenant_id", tenantId);
  if (error) throw mapDbError(error);
  return data;
}

export type RazorpayView = {
  configured: boolean;
  mode: "test" | "live";
  keyId: string | null;
  keySecretLast4: string | null;
  webhookSecretLast4: string | null;
  enabled: boolean;
  updatedAt: string | null;
};

function last4(enc: string | null): string | null {
  if (!enc) return null;
  try {
    return decryptSecret(enc).slice(-4);
  } catch (err) {
    logger.error("payments.secret_unreadable", { error: err });
    return "????";
  }
}

/**
 * Razorpay settings for display. tenant_payment_settings has no RLS policies (server-only),
 * so this uses the secret-key client AFTER checking payments.manage, scoped to ctx.tenantId.
 * Secrets never leave the server: only their last 4 characters are returned.
 */
export async function getRazorpaySettings(ctx: TenantContext): Promise<RazorpayView> {
  assertPermission(ctx, "payments.manage");
  const admin = createSupabaseAdminClient();
  const { data, error } = await admin.from("tenant_payment_settings").select("*").eq("tenant_id", ctx.tenantId).maybeSingle();
  if (error) throw mapDbError(error);
  return {
    configured: !!data?.key_id && !!data.key_secret_encrypted,
    mode: data?.mode === "live" ? "live" : "test",
    keyId: data?.key_id ?? null,
    keySecretLast4: last4(data?.key_secret_encrypted ?? null),
    webhookSecretLast4: last4(data?.webhook_secret_encrypted ?? null),
    enabled: data?.enabled ?? false,
    updatedAt: data?.updated_at ?? null,
  };
}
