import "server-only";
import { createSupabaseServerClient } from "@/lib/supabase/server";
import { mapDbError } from "@/lib/supabase/errors";

export const REVIEWS_PAGE_SIZE = 25;

export async function listReviews(tenantId: string, f: { status?: string; rating?: number; page: number }) {
  let q = (await createSupabaseServerClient())
    .from("reviews")
    .select("id, rating, title, body, author_name, status, verified_purchase, created_at, products!inner(id, title)", { count: "exact" })
    .eq("tenant_id", tenantId);
  if (f.status) q = q.eq("status", f.status);
  if (f.rating) q = q.eq("rating", f.rating);
  const from = (f.page - 1) * REVIEWS_PAGE_SIZE;
  const { data, count, error } = await q.order("created_at", { ascending: false }).range(from, from + REVIEWS_PAGE_SIZE - 1);
  if (error) throw mapDbError(error);
  return { rows: data ?? [], total: count ?? 0 };
}
