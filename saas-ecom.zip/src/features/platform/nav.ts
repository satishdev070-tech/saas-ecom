import type { PlatformPermission } from "@/lib/permissions/matrix";

/**
 * Super-admin navigation (single source). Items are hidden when the platform role lacks the
 * permission; each page also calls requirePlatform(permission) and RLS enforces the same keys.
 */
export type AdminNavItem = { href: string; label: string; permission: PlatformPermission };
export type AdminNavGroup = { label: string; items: AdminNavItem[] };

export const ADMIN_NAV: readonly AdminNavGroup[] = [
  {
    label: "Overview",
    items: [{ href: "/admin", label: "Dashboard", permission: "platform.tenants.read" }],
  },
  {
    label: "Tenants",
    items: [
      { href: "/admin/tenants", label: "Tenants", permission: "platform.tenants.read" },
      { href: "/admin/domains", label: "Domains", permission: "platform.tenants.read" },
      { href: "/admin/support", label: "Support sessions", permission: "platform.support.impersonate" },
    ],
  },
  {
    label: "Billing & features",
    items: [
      { href: "/admin/plans", label: "Plans", permission: "platform.plans.manage" },
      { href: "/admin/flags", label: "Feature flags", permission: "platform.flags.manage" },
    ],
  },
  {
    label: "Monitoring",
    items: [
      { href: "/admin/usage", label: "Usage & storage", permission: "platform.usage.read" },
      { href: "/admin/audit", label: "Audit log", permission: "platform.audit.read" },
      { href: "/admin/health", label: "Integrations", permission: "platform.settings.manage" },
    ],
  },
  {
    label: "Platform",
    items: [
      { href: "/admin/users", label: "Platform users", permission: "platform.users.manage" },
      { href: "/admin/settings", label: "Settings", permission: "platform.settings.manage" },
    ],
  },
];

export function adminNavFor(permissions: ReadonlySet<PlatformPermission>): AdminNavGroup[] {
  return ADMIN_NAV.map((g) => ({ ...g, items: g.items.filter((i) => permissions.has(i.permission)) })).filter((g) => g.items.length > 0);
}

/** "/admin" is active only on itself; other items also match their sub-pages. */
export function isAdminNavActive(pathname: string, href: string): boolean {
  if (href === "/admin") return pathname === "/admin";
  return pathname === href || pathname.startsWith(`${href}/`);
}
