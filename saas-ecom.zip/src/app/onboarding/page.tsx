import type { Metadata } from "next";
import { requireUser } from "@/lib/auth/session";
import { publicEnv } from "@/lib/env/public";
import { CreateStoreForm } from "@/features/tenants/forms";
import { PLATFORM_NAME } from "@/config/platform";

export const metadata: Metadata = { title: "Create your store", robots: { index: false } };

export default async function OnboardingPage() {
  await requireUser("/onboarding");
  return (
    <main className="flex flex-1 items-center justify-center px-4 py-12">
      <div className="w-full max-w-md">
        <p className="mb-2 text-center text-sm uppercase tracking-widest text-muted">{PLATFORM_NAME}</p>
        <div className="rounded-lg border border-border bg-surface p-6">
          <h1 className="mb-1 text-lg font-semibold">Name your store</h1>
          <p className="mb-5 text-sm text-muted">You get a 14-day free trial. No card needed.</p>
          <CreateStoreForm rootDomain={publicEnv().NEXT_PUBLIC_PLATFORM_ROOT_DOMAIN} />
        </div>
      </div>
    </main>
  );
}
