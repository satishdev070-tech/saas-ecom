import type { Metadata } from "next";
import Link from "next/link";
import { requireTenant } from "@/lib/tenant/membership";
import { DASHBOARD_NAV } from "@/components/dashboard/nav";
import { NavLinks } from "@/components/dashboard/nav-links";
import { switchTenantAction } from "@/features/tenants/actions";
import { signOutAction } from "@/features/auth/actions";
import { storeOrigin, storeSubdomain } from "@/lib/platform/urls";
import { Badge } from "@/components/ui/layout";

export const metadata: Metadata = { title: { default: "Dashboard", template: "%s · Dashboard" }, robots: { index: false, follow: false } };

export default async function DashboardLayout({ children }: LayoutProps<"/dashboard">) {
  const ctx = await requireTenant();
  const groups = DASHBOARD_NAV.map((g) => ({ ...g, items: g.items.filter((i) => ctx.permissions.has(i.permission)) })).filter((g) => g.items.length);
  const storeUrl = storeOrigin(storeSubdomain(ctx.tenantSlug));

  const sidebar = (
    <div className="flex h-full flex-col gap-6">
      <div className="px-3">
        {ctx.memberships.length > 1 ? (
          <form action={switchTenantAction} className="flex gap-2">
            <label htmlFor="tenant-switch" className="sr-only">
              Store
            </label>
            <select id="tenant-switch" name="tenantId" defaultValue={ctx.tenantId} className="min-w-0 flex-1 rounded-md border border-border bg-surface px-2 py-1.5 text-sm">
              {ctx.memberships.map((m) => (
                <option key={m.tenantId} value={m.tenantId}>
                  {m.tenantName}
                </option>
              ))}
            </select>
            <button type="submit" className="rounded-md border border-border px-2 text-sm">
              Go
            </button>
          </form>
        ) : (
          <p className="truncate font-semibold">{ctx.tenantName}</p>
        )}
        <a href={storeUrl} target="_blank" rel="noopener noreferrer" className="mt-1 block truncate text-xs text-muted hover:text-foreground">
          View store ↗
        </a>
      </div>
      <NavLinks groups={groups} />
      <div className="mt-auto border-t border-border px-3 pt-4 text-sm">
        <p className="truncate text-muted">{ctx.user.email}</p>
        <p className="text-xs capitalize text-muted">{ctx.role}</p>
        <form action={signOutAction}>
          <button type="submit" className="mt-2 text-sm font-medium text-accent">
            Sign out
          </button>
        </form>
      </div>
    </div>
  );

  return (
    <div className="flex min-h-full flex-1">
      <aside className="hidden w-60 shrink-0 border-r border-border bg-surface py-5 lg:block">{sidebar}</aside>
      <div className="flex min-w-0 flex-1 flex-col">
        <header className="flex items-center justify-between gap-3 border-b border-border bg-surface px-4 py-3 lg:hidden">
          <details className="group relative">
            <summary className="cursor-pointer list-none rounded-md border border-border px-3 py-1.5 text-sm">Menu</summary>
            <div className="absolute left-0 z-20 mt-2 max-h-[80vh] w-64 overflow-y-auto rounded-lg border border-border bg-surface py-4 shadow-lg">{sidebar}</div>
          </details>
          <p className="truncate text-sm font-semibold">{ctx.tenantName}</p>
        </header>
        {ctx.tenantStatus === "suspended" ? (
          <div role="alert" className="border-b border-error/30 bg-error/10 px-4 py-2 text-sm text-error">
            This store is suspended and hidden from shoppers. Contact support to restore it.
          </div>
        ) : ctx.tenantStatus === "trial" ? (
          <div className="border-b border-border bg-background px-4 py-2 text-sm text-muted">
            <Badge tone="accent">Trial</Badge> <span className="ml-1">You&apos;re on a free trial.</span>{" "}
            <Link href="/dashboard/settings" className="underline">
              Store settings
            </Link>
          </div>
        ) : null}
        <main className="mx-auto w-full max-w-6xl flex-1 px-4 py-6 sm:px-6">{children}</main>
      </div>
    </div>
  );
}
