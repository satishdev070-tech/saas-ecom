import type { Metadata } from "next";
import { requireTenantPermission } from "@/lib/tenant/membership";
import { Card, PageHeader } from "@/components/ui/layout";
import { listNotificationTemplates } from "@/features/settings/queries";
import { DEFAULT_TEMPLATES, TEMPLATE_KEYS, TEMPLATE_META } from "@/features/settings/notification-templates";
import { TemplateForm } from "@/features/dashboard-ui/forms";

export const metadata: Metadata = { title: "Notifications" };

export default async function NotificationsPage() {
  const ctx = await requireTenantPermission("settings.write");
  const saved = await listNotificationTemplates(ctx.tenantId);
  return (
    <div className="space-y-6">
      <PageHeader title="Customer notifications" description="Emails sent to shoppers. Edit the wording; {{placeholders}} are filled in automatically." />
      {TEMPLATE_KEYS.map((k) => {
        const s = saved.find((t) => t.key === k && t.channel === "email");
        const d = DEFAULT_TEMPLATES[k];
        return (
          <Card key={k} title={TEMPLATE_META[k].label} description={TEMPLATE_META[k].description}>
            <TemplateForm tkey={k} subject={s?.subject ?? d.subject} body={s?.body ?? d.body} active={s?.active ?? true} custom={Boolean(s)} variables={TEMPLATE_META[k].placeholders} />
          </Card>
        );
      })}
    </div>
  );
}
