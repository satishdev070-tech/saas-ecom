import type { Metadata } from "next";
import { requireTenantPermission } from "@/lib/tenant/membership";
import { createSupabaseServerClient } from "@/lib/supabase/server";
import { Badge, Card, PageHeader, Table, td, th } from "@/components/ui/layout";
import { InviteForm, MemberControls, RevokeInvite } from "@/features/dashboard-ui/forms";
import { formatDate } from "@/features/analytics/dates";

export const metadata: Metadata = { title: "Team" };

export default async function TeamPage() {
  const ctx = await requireTenantPermission("members.manage");
  const supabase = await createSupabaseServerClient();
  const [{ data: members }, { data: invites }] = await Promise.all([
    supabase.rpc("list_tenant_members", { p_tenant: ctx.tenantId }),
    supabase.from("tenant_invitations").select("id, email, role, expires_at").eq("tenant_id", ctx.tenantId).is("accepted_at", null).is("revoked_at", null).gt("expires_at", new Date().toISOString()),
  ]);
  return (
    <div className="space-y-6">
      <PageHeader title="Team" description="Invite staff and choose what they can do." />
      <Card title="Invite someone">
        <InviteForm />
      </Card>
      <Table caption="Members">
        <thead><tr><th className={th}>Member</th><th className={th}>Role</th><th className={th}>Joined</th><th className={th}><span className="sr-only">Actions</span></th></tr></thead>
        <tbody>
          {(members ?? []).map((m) => (
            <tr key={m.membership_id}>
              <td className={td}><span className="font-medium">{m.display_name || m.email}</span><span className="block text-xs text-muted">{m.email}</span></td>
              <td className={td}><Badge tone={m.role === "owner" ? "accent" : "neutral"}>{m.role}</Badge></td>
              <td className={td}>{formatDate(m.created_at)}</td>
              <td className={td}>{m.role !== "owner" && m.user_id !== ctx.user.id ? <MemberControls membershipId={m.membership_id} role={m.role} /> : null}</td>
            </tr>
          ))}
        </tbody>
      </Table>
      {invites?.length ? (
        <Card title="Pending invitations">
          <ul className="divide-y divide-border text-sm">
            {invites.map((i) => (
              <li key={i.id} className="flex items-center justify-between py-2">
                <span>{i.email} · {i.role} · expires {formatDate(i.expires_at)}</span>
                <RevokeInvite id={i.id} />
              </li>
            ))}
          </ul>
        </Card>
      ) : null}
    </div>
  );
}
