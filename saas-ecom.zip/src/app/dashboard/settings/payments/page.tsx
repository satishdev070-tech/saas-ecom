import type { Metadata } from "next";
import { requireTenantPermission } from "@/lib/tenant/membership";
import { Card, PageHeader } from "@/components/ui/layout";
import { getRazorpaySettings } from "@/features/settings/queries";
import { razorpayWebhookUrl } from "@/features/payments/credentials";
import { RazorpayForm } from "@/features/dashboard-ui/forms";

export const metadata: Metadata = { title: "Payments" };

export default async function PaymentsPage() {
  const ctx = await requireTenantPermission("payments.manage");
  const rz = await getRazorpaySettings(ctx);
  const webhook = await razorpayWebhookUrl(ctx.tenantId);
  return (
    <div className="space-y-6">
      <PageHeader title="Payments" description="Accept UPI, cards, net banking and wallets through your own Razorpay account. Cash on delivery is set under Shipping." />
      <Card title="Razorpay" description={rz.configured ? `Connected (${rz.mode} mode)${rz.keySecretLast4 ? ` · secret ending ${rz.keySecretLast4}` : ""}` : "Not connected"}>
        <RazorpayForm keyId={rz.keyId ?? ""} enabled={rz.enabled} hasSecret={Boolean(rz.keySecretLast4)} hasWebhookSecret={Boolean(rz.webhookSecretLast4)} />
      </Card>
      <Card title="Webhook" description="In Razorpay Dashboard → Webhooks, add this URL with the events payment.captured, payment.failed and refund.processed, and use the same webhook secret as above.">
        <p className="break-all rounded bg-background p-3 font-mono text-sm">{webhook}</p>
      </Card>
      <p className="text-xs text-muted">Secrets are encrypted before they&apos;re stored and are never shown again.</p>
    </div>
  );
}
