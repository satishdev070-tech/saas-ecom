import { requireTenant } from "@/lib/tenant/membership";
import { PageHeader } from "@/components/ui/layout";

/** Placeholder home; the dashboard-ops agent replaces this with the overview + setup checklist. */
export default async function DashboardHome() {
  const ctx = await requireTenant();
  return <PageHeader title={`Welcome, ${ctx.user.displayName ?? "there"}`} description={ctx.tenantName} />;
}
