import type { Metadata, Viewport } from "next";
import { PLATFORM_NAME, PLATFORM_TAGLINE } from "@/config/platform";
import "./globals.css";

/**
 * Root layout shared by platform pages and storefronts. Storefront layouts override
 * metadata per tenant (generateMetadata) and inject theme tokens; nothing tenant-specific
 * belongs here.
 */
export const metadata: Metadata = {
  title: { default: PLATFORM_NAME, template: `%s · ${PLATFORM_NAME}` },
  description: PLATFORM_TAGLINE,
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({ children }: LayoutProps<"/">) {
  return (
    <html lang="en-IN" className="h-full antialiased">
      <body className="flex min-h-full flex-col">{children}</body>
    </html>
  );
}
