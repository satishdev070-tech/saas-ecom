import type { Metadata } from "next";
import Link from "next/link";
import { requirePlatform } from "@/lib/platform/access";
import { adminNavFor } from "@/features/platform/nav";
import { getMyActiveSupportSessions } from "@/features/platform/server/queries";
import { NavLinks } from "@/components/dashboard/nav-links";
import type { NavGroup } from "@/components/dashboard/nav";
import { signOutAction } from "@/features/auth/actions";
import { PLATFORM_NAME } from "@/config/platform";

export const metadata: Metadata = { title: { default: "Admin", template: "%s · Admin" }, robots: { index: false, follow: false } };

export default async function AdminLayout({ children }: LayoutProps<"/admin">) {
  const ctx = await requirePlatform();
  const groups = adminNavFor(ctx.permissions) as unknown as NavGroup[];
  const sessions = ctx.permissions.has("platform.support.impersonate") ? await getMyActiveSupportSessions(ctx.user.id) : [];
  const sidebar = (
    <div className="flex h-full flex-col gap-6">
      <div className="px-3">
        <p className="font-semibold">{PLATFORM_NAME}</p>
        <p className="text-xs uppercase tracking-wide text-muted">Platform console</p>
      </div>
      <NavLinks groups={groups} />
      <div className="mt-auto border-t border-border px-3 pt-4 text-sm">
        <p className="truncate text-muted">{ctx.user.email}</p>
        <p className="text-xs text-muted">{ctx.role.replace("_", " ")}</p>
        <form action={signOutAction}>
          <button type="submit" className="mt-2 text-sm font-medium text-accent">
            Sign out
          </button>
        </form>
      </div>
    </div>
  );
  return (
    <div className="flex min-h-full flex-1">
      <aside className="hidden w-60 shrink-0 border-r border-border bg-surface py-5 lg:block">{sidebar}</aside>
      <div className="flex min-w-0 flex-1 flex-col">
        <header className="flex items-center justify-between gap-3 border-b border-border bg-surface px-4 py-3 lg:hidden">
          <details className="relative">
            <summary className="cursor-pointer list-none rounded-md border border-border px-3 py-1.5 text-sm">Menu</summary>
            <div className="absolute left-0 z-20 mt-2 max-h-[80vh] w-64 overflow-y-auto rounded-lg border border-border bg-surface py-4 shadow-lg">{sidebar}</div>
          </details>
          <p className="text-sm font-semibold">Platform console</p>
        </header>
        {sessions.length ? (
          <div role="status" className="border-b border-warning/30 bg-warning/10 px-4 py-2 text-sm">
            Active support session{sessions.length > 1 ? "s" : ""}:{" "}
            {sessions.map((s, i) => (
              <span key={s.id}>
                {i ? ", " : ""}
                <Link href={`/admin/tenants/${s.tenantId}/support`} className="font-medium underline">
                  {s.tenantName ?? "store"}
                </Link>
              </span>
            ))}
          </div>
        ) : null}
        <main className="mx-auto w-full max-w-6xl flex-1 px-4 py-6 sm:px-6">{children}</main>
      </div>
    </div>
  );
}
