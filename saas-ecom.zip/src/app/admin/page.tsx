import type { Metadata } from "next";
import Link from "next/link";
import { requirePlatform } from "@/lib/platform/access";
import { getPlatformOverview, getSignupSeries, topTenantsThisMonth } from "@/features/platform/server/queries";
import { Card, PageHeader, StatCard, Table, td, th } from "@/components/ui/layout";
import { formatMoney, toMinor } from "@/lib/money";

export const metadata: Metadata = { title: "Dashboard" };

export default async function AdminHome() {
  await requirePlatform("platform.tenants.read");
  const [o, series, top] = await Promise.all([getPlatformOverview(), getSignupSeries(12), topTenantsThisMonth("gmv", 8)]);
  const max = Math.max(1, ...series.map((p) => p.value));
  return (
    <div className="space-y-6">
      <PageHeader title="Platform overview" description="All stores on the platform, this month." actions={<Link href="/admin/tenants/new" className="inline-flex h-10 items-center rounded-md bg-primary px-4 text-sm font-medium text-primary-foreground">New store</Link>} />
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Stores" value={o.totalTenants} hint={`${o.statusCounts.active} active · ${o.statusCounts.trial} trial`} />
        <StatCard label="New stores (30 days)" value={o.new30d} hint={`${o.new7d} in the last 7 days`} />
        <StatCard label="GMV this month" value={formatMoney(o.monthGmvMinor)} hint={`${o.monthOrders} orders`} />
        <StatCard label="Needs attention" value={o.trialsEnding7d + o.customDomainsPending} hint={`${o.trialsEnding7d} trials ending · ${o.customDomainsPending} domains pending`} />
      </div>
      <div className="grid gap-6 lg:grid-cols-2">
        <Card title="New stores per week">
          <ol className="flex h-40 items-end gap-1" aria-label="New stores per week">
            {series.map((p) => (
              <li key={p.key} className="flex flex-1 flex-col items-center gap-1" title={`${p.label}: ${p.value}`}>
                <span className="w-full rounded-t bg-accent/70" style={{ height: `${Math.max(2, (p.value / max) * 120)}px` }} />
                <span className="sr-only">
                  {p.label}: {p.value}
                </span>
              </li>
            ))}
          </ol>
          <p className="mt-2 text-xs text-muted">Last 12 weeks · suspended {o.statusCounts.suspended} · cancelled {o.statusCounts.cancelled}</p>
        </Card>
        <Card title="Top stores by GMV this month">
          {top.length ? (
            <Table>
              <thead>
                <tr>
                  <th className={th}>Store</th>
                  <th className={`${th} text-right`}>GMV</th>
                </tr>
              </thead>
              <tbody>
                {top.map((t) => (
                  <tr key={t.tenantId}>
                    <td className={td}>
                      <Link href={`/admin/tenants/${t.tenantId}`} className="font-medium hover:underline">
                        {t.tenantName ?? t.tenantId}
                      </Link>
                    </td>
                    <td className={`${td} text-right tabular-nums`}>{formatMoney(toMinor(t.value))}</td>
                  </tr>
                ))}
              </tbody>
            </Table>
          ) : (
            <p className="text-sm text-muted">No sales recorded this month yet.</p>
          )}
        </Card>
      </div>
    </div>
  );
}
