import type { Metadata } from "next";
import Link from "next/link";
import { requirePlatform } from "@/lib/platform/access";
import { tenantListFilterSchema } from "@/features/platform/schemas";
import { listPlans, listTenants } from "@/features/platform/server/queries";
import { Badge, PageHeader, Table, td, th } from "@/components/ui/layout";
import { EmptyState } from "@/components/ui/states";
import { Pagination } from "@/components/ui/pagination";
import { formatDate } from "@/features/analytics/dates";

export const metadata: Metadata = { title: "Tenants" };
const TONE = { trial: "accent", active: "success", suspended: "error", cancelled: "neutral" } as const;
const ctl = "rounded-md border border-border bg-surface px-3 py-2 text-sm";

export default async function TenantsPage({ searchParams }: PageProps<"/admin/tenants">) {
  const ctx = await requirePlatform("platform.tenants.read");
  const f = tenantListFilterSchema.parse(await searchParams);
  const [{ rows, total }, plans] = await Promise.all([listTenants(f), listPlans()]);
  return (
    <div>
      <PageHeader
        title="Tenants"
        description={`${total} store${total === 1 ? "" : "s"}`}
        actions={
          ctx.permissions.has("platform.tenants.manage") ? (
            <Link href="/admin/tenants/new" className="inline-flex h-10 items-center rounded-md bg-primary px-4 text-sm font-medium text-primary-foreground">
              New store
            </Link>
          ) : null
        }
      />
      <form className="mb-4 flex flex-wrap gap-2" role="search">
        <label className="sr-only" htmlFor="q">
          Search
        </label>
        <input id="q" name="q" defaultValue={f.q ?? ""} placeholder="Name or slug" className={`${ctl} min-w-48 flex-1`} />
        <label className="sr-only" htmlFor="status">
          Status
        </label>
        <select id="status" name="status" defaultValue={f.status ?? ""} className={ctl}>
          <option value="">All statuses</option>
          {Object.keys(TONE).map((s) => (
            <option key={s} value={s}>
              {s}
            </option>
          ))}
        </select>
        <label className="sr-only" htmlFor="plan">
          Plan
        </label>
        <select id="plan" name="plan" defaultValue={f.plan ?? ""} className={ctl}>
          <option value="">All plans</option>
          {plans.map((p) => (
            <option key={p.id} value={p.id}>
              {p.name}
            </option>
          ))}
        </select>
        <button className={ctl}>Filter</button>
      </form>
      {rows.length ? (
        <Table>
          <thead>
            <tr>
              <th className={th}>Store</th>
              <th className={th}>Status</th>
              <th className={th}>Plan</th>
              <th className={th}>Trial ends</th>
              <th className={th}>Created</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((t) => (
              <tr key={t.id}>
                <td className={td}>
                  <Link href={`/admin/tenants/${t.id}`} className="font-medium hover:underline">
                    {t.name}
                  </Link>
                  <p className="text-xs text-muted">{t.slug}</p>
                </td>
                <td className={td}>
                  <Badge tone={TONE[t.status]}>{t.status}</Badge>
                </td>
                <td className={td}>{t.planName ?? "—"}</td>
                <td className={td}>{t.status === "trial" ? formatDate(t.trialEndsAt) : "—"}</td>
                <td className={td}>{formatDate(t.createdAt)}</td>
              </tr>
            ))}
          </tbody>
        </Table>
      ) : (
        <EmptyState title="No stores match" description="Try a different search or filter." />
      )}
      <Pagination page={f.page} pageSize={f.pageSize} total={total} basePath="/admin/tenants" params={{ q: f.q, status: f.status, plan: f.plan }} />
    </div>
  );
}
