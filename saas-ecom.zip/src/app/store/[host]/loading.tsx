export default function StoreLoading() {
  return (
    <div className="sf-container sf-section" aria-busy="true" aria-label="Loading">
      <div className="mb-8 h-8 w-48 animate-pulse rounded bg-[var(--sf-border)]" />
      <div className="grid grid-cols-2 gap-4 @[64rem]:grid-cols-4">
        {Array.from({ length: 8 }, (_, i) => (
          <div key={i} className="aspect-[3/4] animate-pulse rounded bg-[var(--sf-border)]" />
        ))}
      </div>
    </div>
  );
}
