import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { resolveStorefrontTenant } from "@/lib/tenant/resolve";
import { storefrontAvailability } from "@/lib/tenant/context";
import { assetUrl } from "@/lib/storage/assets";
import { canonicalUrl } from "@/features/storefront/urls";
import { toDescription } from "@/features/storefront/seo";
import { ThemeTokensStyle } from "@/features/theme/tokens-style";
import { SectionList } from "@/features/theme/render/sections";
import { getRenderContext } from "@/features/theme/render/load";
import { StoreUnavailable } from "./store-unavailable";
import "@/features/theme/storefront.css";

/**
 * Storefront shell for every tenant host (reached only via the proxy rewrite). Renders the
 * published theme's header/footer groups around every store page, including cart,
 * checkout and account pages.
 */
export async function generateMetadata({ params }: LayoutProps<"/store/[host]">): Promise<Metadata> {
  const { host } = await params;
  const tenant = await resolveStorefrontTenant(host);
  if (!tenant || storefrontAvailability(tenant.status) !== "open") return { robots: { index: false, follow: false } };
  const { sf } = await getRenderContext(host);
  const icon = assetUrl(sf.store.faviconPath);
  return {
    metadataBase: new URL(canonicalUrl(tenant.primaryHost, "/")),
    title: { default: sf.store.seo.title || sf.store.name, template: `%s · ${sf.store.name}` },
    description: toDescription(sf.store.seo.description || sf.store.description || sf.store.tagline),
    applicationName: sf.store.name,
    icons: icon ? { icon } : undefined,
    robots: sf.preview || sf.store.seo.noindex ? { index: false, follow: false } : undefined,
    openGraph: { siteName: sf.store.name, locale: "en_IN", type: "website" },
  };
}

export default async function StorefrontLayout({ children, params }: LayoutProps<"/store/[host]">) {
  const { host } = await params;
  const tenant = await resolveStorefrontTenant(host);
  if (!tenant) notFound();
  switch (storefrontAvailability(tenant.status)) {
    case "unavailable":
      notFound();
    case "suspended":
      return <StoreUnavailable storeName={tenant.name} />;
    case "open":
      break;
  }
  const ctx = await getRenderContext(host);
  return (
    <div data-sf-root className="sf-root">
      <ThemeTokensStyle tokens={ctx.sf.theme.tokens} />
      <a href="#main" className="sr-only focus:not-sr-only focus:absolute focus:left-2 focus:top-2 focus:z-50 focus:bg-white focus:p-2">
        Skip to content
      </a>
      {ctx.sf.preview ? (
        <div role="status" className="bg-amber-100 px-4 py-2 text-center text-xs text-amber-900">
          Previewing your unpublished theme.{" "}
          <Link href="/preview?exit=1" className="underline">
            Exit preview
          </Link>
        </div>
      ) : null}
      <SectionList sections={ctx.sf.theme.layout.header} ctx={ctx} />
      <main id="main" className="flex-1">
        {children}
      </main>
      <SectionList sections={ctx.sf.theme.layout.footer} ctx={ctx} />
    </div>
  );
}
