import type { Metadata } from "next";
import { after } from "next/server";
import Link from "next/link";
import { getRenderContext } from "@/features/theme/render/load";
import { SectionList } from "@/features/theme/render/sections";
import { categoryTrail, getAllCategories, getProductBySlug, listProducts } from "@/features/storefront/server/catalog";
import { getProductReviews } from "@/features/storefront/server/content";
import { redirectOrNotFound } from "@/features/storefront/server/redirects";
import { buildPageMetadata, jsonLdString, productJsonLd, toDescription } from "@/features/storefront/seo";
import { paths } from "@/features/storefront/urls";
import { productTypeLabel } from "@/features/storefront/constants";
import { assetUrl } from "@/lib/storage/assets";
import { formatMoney } from "@/lib/money";
import { createSupabaseServerClient } from "@/lib/supabase/server";
import { getStoreCustomer } from "@/features/customer-account/session";
import { Breadcrumbs } from "@/features/storefront/components/breadcrumbs";
import { ProductPurchase } from "@/features/storefront/components/pdp";
import { PincodeCheck, RecentlyViewed, ReviewForm, WishlistButton } from "@/features/storefront/components/islands";
import { ProductRow } from "@/features/storefront/components/product-card";
import { Stars } from "@/features/storefront/components/price";
import { trackStoreEvent } from "@/features/storefront/server/events";

export async function generateMetadata({ params }: PageProps<"/store/[host]/products/[slug]">): Promise<Metadata> {
  const { host, slug } = await params;
  const { sf } = await getRenderContext(host);
  const p = await getProductBySlug(sf.tenant.tenantId, slug);
  if (!p) return {};
  return buildPageMetadata({
    primaryHost: sf.tenant.primaryHost,
    path: paths.product(p.slug),
    title: p.seo.title || p.title,
    description: toDescription(p.seo.description || p.shortDescription || p.description),
    imageUrl: assetUrl(p.seo.ogImagePath || p.media[0]?.path),
    siteName: sf.store.name,
    noindex: p.seo.noindex,
  });
}

function Detail({ title, children, open = false }: { title: string; children: React.ReactNode; open?: boolean }) {
  return (
    <details open={open} className="group sf-border border-b py-4">
      <summary className="flex cursor-pointer list-none items-center justify-between font-medium">
        {title}
        <span aria-hidden className="transition group-open:rotate-45">
          +
        </span>
      </summary>
      <div className="sf-muted mt-3 whitespace-pre-line text-sm leading-relaxed">{children}</div>
    </details>
  );
}

export default async function ProductPage({ params }: PageProps<"/store/[host]/products/[slug]">) {
  const { host, slug } = await params;
  const ctx = await getRenderContext(host);
  const { sf } = ctx;
  const tenantId = sf.tenant.tenantId;
  const p = await getProductBySlug(tenantId, slug);
  if (!p) return redirectOrNotFound(tenantId, paths.product(slug));

  const [categories, related, reviewData, customer] = await Promise.all([
    getAllCategories(tenantId),
    listProducts(tenantId, p.categoryId ? { p_category: p.categoryId, p_exclude: p.id, p_limit: 8, p_offset: 0, p_sort: "best_selling" } : { p_exclude: p.id, p_limit: 8, p_offset: 0, p_sort: "newest" }),
    sf.features.reviews ? getProductReviews(tenantId, p.id, 10) : Promise.resolve({ reviews: [], distribution: [] }),
    getStoreCustomer(tenantId),
  ]);
  let saved = false;
  if (customer) {
    const supabase = await createSupabaseServerClient();
    const { data } = await supabase.from("wishlist_items").select("product_id").eq("customer_id", customer.id).eq("product_id", p.id).maybeSingle();
    saved = Boolean(data);
  }
  after(() => trackStoreEvent({ tenantId, name: "product_view", path: paths.product(p.slug), productId: p.id }));

  const trail = categoryTrail(categories, p.categoryId);
  const prices = p.variants.map((v) => v.priceMinor);
  const cod = sf.store.cod;
  const codNote = sf.features.cod && cod.enabled ? `Cash on delivery available${cod.maxOrderMinor ? ` on orders up to ${formatMoney(cod.maxOrderMinor)}` : ""}${cod.feeMinor ? ` (${formatMoney(cod.feeMinor)} fee)` : ""}.` : null;
  const ld = productJsonLd({
    primaryHost: sf.tenant.primaryHost,
    path: paths.product(p.slug),
    name: p.title,
    description: toDescription(p.shortDescription || p.description, 500),
    images: p.media.map((m) => assetUrl(m.path)).filter((u): u is string => !!u).slice(0, 6),
    sku: p.variants[0]?.sku,
    brand: p.brand || sf.store.name,
    storeName: sf.store.name,
    lowPriceMinor: Math.min(...prices),
    highPriceMinor: Math.max(...prices),
    offerCount: p.variants.length,
    inStock: p.variants.some((v) => v.inStock),
    ratingAvg: p.ratingAvg,
    ratingCount: p.ratingCount,
  });

  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: jsonLdString(ld) }} />
      <div className="sf-container sf-section space-y-6">
        <Breadcrumbs
          primaryHost={sf.tenant.primaryHost}
          items={[{ name: "Home", path: "/" }, ...trail.map((c) => ({ name: c.name, path: paths.category(c.slug) })), { name: p.title, path: paths.product(p.slug) }]}
        />
        <ProductPurchase title={p.title} options={p.options} variants={p.variants} media={p.media} sizeChart={p.sizeChart} codNote={codNote} />
        <div className="grid gap-8 @[64rem]:ml-auto @[64rem]:w-[calc(50%-1.5rem)]">
          <div className="space-y-4">
            {p.ratingCount > 0 ? (
              <a href="#reviews" className="inline-flex">
                <Stars rating={p.ratingAvg} count={p.ratingCount} />
              </a>
            ) : null}
            <WishlistButton productId={p.id} initiallySaved={saved} />
            <PincodeCheck />
          </div>
          <div>
            {p.shortDescription || p.description ? <Detail title="Description" open>{p.description || p.shortDescription}</Detail> : null}
            <Detail title="Product details">
              <dl className="grid grid-cols-[auto_1fr] gap-x-6 gap-y-1">
                <dt>Type</dt>
                <dd>{productTypeLabel(p.productType)}</dd>
                {p.attributes.map((a) => (
                  <div key={a.label} className="contents">
                    <dt>{a.label}</dt>
                    <dd>{a.value}</dd>
                  </div>
                ))}
              </dl>
            </Detail>
            {p.care ? <Detail title="Fabric & care">{p.care}</Detail> : null}
            <Detail title="Shipping & returns">{[p.shippingInfo, p.returnInfo].filter(Boolean).join("\n\n") || "See our shipping and returns policies."}</Detail>
          </div>
        </div>
      </div>

      {sf.features.reviews ? (
        <section id="reviews" aria-labelledby="reviews-h" className="sf-container sf-section grid gap-10 @[64rem]:grid-cols-[1fr_2fr]">
          <div className="space-y-3">
            <h2 id="reviews-h" className="sf-heading text-3xl">
              Reviews
            </h2>
            {p.ratingCount ? <Stars rating={p.ratingAvg} count={p.ratingCount} /> : <p className="sf-muted text-sm">No reviews yet.</p>}
            {customer ? (
              <details className="pt-2">
                <summary className="sf-btn sf-btn-outline cursor-pointer list-none">Write a review</summary>
                <div className="pt-4">
                  <ReviewForm productId={p.id} />
                </div>
              </details>
            ) : (
              <p className="text-sm">
                <Link href={`/account/login?next=${encodeURIComponent(paths.product(p.slug))}`} className="sf-link">
                  Sign in
                </Link>{" "}
                to write a review.
              </p>
            )}
          </div>
          <ul className="space-y-6">
            {reviewData.reviews.map((r) => (
              <li key={r.id} className="sf-border space-y-1 border-b pb-6">
                <Stars rating={r.rating} small />
                {r.title ? <p className="font-medium">{r.title}</p> : null}
                {r.body ? <p className="sf-muted text-sm">{r.body}</p> : null}
                <p className="text-xs">
                  {r.authorName}
                  {r.verified ? " · Verified buyer" : ""} · {new Date(r.createdAt).toLocaleDateString("en-IN", { dateStyle: "medium" })}
                </p>
              </li>
            ))}
          </ul>
        </section>
      ) : null}

      {related.cards.length ? (
        <section aria-labelledby="related-h" className="sf-container sf-section">
          <h2 id="related-h" className="sf-heading mb-6 text-3xl">
            You may also like
          </h2>
          <ProductRow products={related.cards} settings={sf.theme.productCard} />
        </section>
      ) : null}
      <RecentlyViewed current={{ slug: p.slug, title: p.title }} />
      <SectionList sections={sf.theme.templates.product} ctx={ctx} />
    </>
  );
}
