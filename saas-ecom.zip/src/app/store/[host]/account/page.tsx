import type { Metadata } from "next";
import { getRenderContext } from "@/features/theme/render/load";
import { requireStoreCustomer } from "@/features/customer-account/session";
import { ProfileForm } from "@/features/customer-account/components/forms";
import { AccountNav } from "./account-nav";

export const metadata: Metadata = { title: "Your account", robots: { index: false } };

export default async function AccountPage({ params }: PageProps<"/store/[host]/account">) {
  const { host } = await params;
  const { sf } = await getRenderContext(host);
  const c = await requireStoreCustomer(sf.tenant.tenantId, "/account");
  return (
    <div className="sf-container sf-section mx-auto max-w-3xl">
      <h1 className="sf-heading mb-6 text-4xl">Hello{c.firstName ? `, ${c.firstName}` : ""}</h1>
      <AccountNav current="profile" />
      <p className="sf-muted mb-6 text-sm">{c.email}</p>
      <ProfileForm initial={{ firstName: c.firstName ?? "", lastName: c.lastName ?? "", phone: (c.phone ?? "").replace(/^\+91/, ""), acceptsMarketing: c.acceptsMarketing }} />
    </div>
  );
}
