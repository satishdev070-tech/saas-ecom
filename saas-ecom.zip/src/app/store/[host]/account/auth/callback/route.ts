import { NextResponse, type NextRequest } from "next/server";
import { createSupabaseServerClient } from "@/lib/supabase/server";
import { safeRedirectPath } from "@/lib/http/safe-redirect";
import { findStoreTenant } from "@/features/cart/context";
import { ensureStoreCustomer } from "@/features/customer-account/session";

/** Shopper email confirmation / magic-link landing on the store host. */
export async function GET(request: NextRequest) {
  const url = request.nextUrl;
  const origin = `${url.protocol}//${request.headers.get("host") ?? url.host}`;
  const next = safeRedirectPath(url.searchParams.get("next"), "/account");
  const code = url.searchParams.get("code");
  if (code) {
    const supabase = await createSupabaseServerClient();
    const { error } = await supabase.auth.exchangeCodeForSession(code);
    if (!error) {
      const tenant = await findStoreTenant();
      if (tenant) await ensureStoreCustomer(tenant.tenantId);
      return NextResponse.redirect(new URL(next, origin));
    }
  }
  return NextResponse.redirect(new URL("/account/login?error=link", origin));
}
