import type { Metadata } from "next";
import { safeRedirectPath } from "@/lib/http/safe-redirect";
import { StoreSignUp } from "@/features/customer-account/components/forms";

export const metadata: Metadata = { title: "Create account", robots: { index: false } };

export default async function StoreRegister({ searchParams }: PageProps<"/store/[host]/account/register">) {
  const sp = await searchParams;
  const next = safeRedirectPath(typeof sp.next === "string" ? sp.next : null, "/account");
  return (
    <div className="sf-container sf-section mx-auto max-w-md space-y-6">
      <h1 className="sf-heading text-center text-4xl">Create account</h1>
      <StoreSignUp next={next} />
    </div>
  );
}
