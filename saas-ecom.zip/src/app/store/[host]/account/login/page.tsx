import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { getRenderContext } from "@/features/theme/render/load";
import { getStoreCustomer } from "@/features/customer-account/session";
import { safeRedirectPath } from "@/lib/http/safe-redirect";
import { StoreSignIn } from "@/features/customer-account/components/forms";

export const metadata: Metadata = { title: "Sign in", robots: { index: false } };

export default async function StoreLogin({ params, searchParams }: PageProps<"/store/[host]/account/login">) {
  const { host } = await params;
  const sp = await searchParams;
  const next = safeRedirectPath(typeof sp.next === "string" ? sp.next : null, "/account");
  const { sf } = await getRenderContext(host);
  if (await getStoreCustomer(sf.tenant.tenantId)) redirect(next);
  return (
    <div className="sf-container sf-section mx-auto max-w-md space-y-6">
      <h1 className="sf-heading text-center text-4xl">Sign in</h1>
      {sp.verify ? <p className="text-center text-sm">Please confirm your email address to continue.</p> : null}
      {sp.error ? <p role="alert" className="text-center text-sm">That link is invalid or has expired.</p> : null}
      <StoreSignIn next={next} />
    </div>
  );
}
