import type { Metadata } from "next";
import { ForgotPasswordForm } from "@/features/auth/forms";

export const metadata: Metadata = { title: "Reset password", robots: { index: false } };

export default function ForgotPasswordPage() {
  return (
    <>
      <h1 className="mb-4 text-lg font-semibold">Reset your password</h1>
      <ForgotPasswordForm />
    </>
  );
}
