import type { Metadata } from "next";
import { ResetPasswordForm } from "@/features/auth/forms";
import { requireUser } from "@/lib/auth/session";

export const metadata: Metadata = { title: "Choose a new password", robots: { index: false } };

export default async function ResetPasswordPage() {
  // The recovery link signs the user in via /auth/callback before landing here.
  await requireUser("/reset-password");
  return (
    <>
      <h1 className="mb-4 text-lg font-semibold">Choose a new password</h1>
      <ResetPasswordForm />
    </>
  );
}
