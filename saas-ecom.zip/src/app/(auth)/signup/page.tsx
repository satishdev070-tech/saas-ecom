import type { Metadata } from "next";
import { SignUpForm } from "@/features/auth/forms";
import { safeRedirectPath } from "@/lib/http/safe-redirect";

export const metadata: Metadata = { title: "Create your account" };

export default async function SignupPage({ searchParams }: PageProps<"/signup">) {
  const sp = await searchParams;
  const next = safeRedirectPath(typeof sp.next === "string" ? sp.next : undefined, "/onboarding");
  return (
    <>
      <h1 className="mb-1 text-lg font-semibold">Start selling online</h1>
      <p className="mb-4 text-sm text-muted">Create your account, then set up your store in two minutes.</p>
      <SignUpForm next={next} />
    </>
  );
}
