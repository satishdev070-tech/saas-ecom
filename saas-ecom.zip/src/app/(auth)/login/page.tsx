import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { SignInForm } from "@/features/auth/forms";
import { getSessionUser } from "@/lib/auth/session";
import { safeRedirectPath } from "@/lib/http/safe-redirect";

export const metadata: Metadata = { title: "Sign in", robots: { index: false } };

export default async function LoginPage({ searchParams }: PageProps<"/login">) {
  const sp = await searchParams;
  const next = safeRedirectPath(typeof sp.next === "string" ? sp.next : undefined, "/dashboard");
  if (await getSessionUser()) redirect(next);
  return (
    <>
      <h1 className="mb-4 text-lg font-semibold">Sign in to your store</h1>
      {sp.error ? <p role="alert" className="mb-3 text-sm text-error">That link is invalid or has expired.</p> : null}
      <SignInForm next={next} />
    </>
  );
}
