import type { TenantPermission } from "@/lib/permissions/matrix";

/**
 * Seller dashboard navigation (single source). Each module's pages live under the href.
 * Items are hidden when the member's role lacks the permission; the page itself also
 * checks with requireTenantPermission(), and RLS enforces it in the database.
 */
export type NavItem = { href: string; label: string; permission: TenantPermission };
export type NavGroup = { label: string; items: NavItem[] };

export const DASHBOARD_NAV: NavGroup[] = [
  {
    label: "Store",
    items: [
      { href: "/dashboard", label: "Home", permission: "store.read" },
      { href: "/dashboard/orders", label: "Orders", permission: "orders.read" },
      { href: "/dashboard/returns", label: "Returns", permission: "orders.read" },
      { href: "/dashboard/customers", label: "Customers", permission: "customers.read" },
      { href: "/dashboard/analytics", label: "Analytics", permission: "analytics.read" },
    ],
  },
  {
    label: "Catalog",
    items: [
      { href: "/dashboard/products", label: "Products", permission: "catalog.read" },
      { href: "/dashboard/collections", label: "Collections", permission: "catalog.read" },
      { href: "/dashboard/categories", label: "Categories", permission: "catalog.read" },
      { href: "/dashboard/inventory", label: "Inventory", permission: "inventory.read" },
      { href: "/dashboard/size-charts", label: "Size charts", permission: "catalog.read" },
      { href: "/dashboard/reviews", label: "Reviews", permission: "reviews.moderate" },
    ],
  },
  {
    label: "Marketing & content",
    items: [
      { href: "/dashboard/discounts", label: "Discounts", permission: "marketing.read" },
      { href: "/dashboard/theme", label: "Theme", permission: "theme.edit" },
      { href: "/dashboard/content/pages", label: "Pages", permission: "content.write" },
      { href: "/dashboard/content/blog", label: "Blog", permission: "content.write" },
      { href: "/dashboard/content/menus", label: "Navigation", permission: "content.write" },
      { href: "/dashboard/content/faqs", label: "FAQs", permission: "content.write" },
    ],
  },
  {
    label: "Settings",
    items: [
      { href: "/dashboard/settings", label: "Store details", permission: "store.read" },
      { href: "/dashboard/settings/shipping", label: "Shipping", permission: "store.read" },
      { href: "/dashboard/settings/payments", label: "Payments", permission: "payments.manage" },
      { href: "/dashboard/settings/taxes", label: "Taxes", permission: "settings.write" },
      { href: "/dashboard/settings/domains", label: "Domains", permission: "store.read" },
      { href: "/dashboard/settings/team", label: "Team", permission: "members.manage" },
      { href: "/dashboard/settings/notifications", label: "Notifications", permission: "settings.write" },
    ],
  },
];
