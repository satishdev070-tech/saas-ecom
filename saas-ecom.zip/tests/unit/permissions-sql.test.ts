import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";
import { PLATFORM_ROLE_PERMISSIONS, TENANT_ROLE_PERMISSIONS } from "@/lib/permissions/matrix";

/** The SQL seed of role_permissions must match the TypeScript matrix exactly. */
const sql = readFileSync("supabase/migrations/20260924000600_reference_data.sql", "utf8");

function pairs(table: string): Set<string> {
  const block = sql.split(`insert into public.${table}`)[1]!.split("on conflict")[0]!;
  return new Set([...block.matchAll(/\('([a-z_]+)','([a-z_.]+)'\)/g)].map((m) => `${m[1]}:${m[2]}`));
}

describe("role permissions SQL <-> matrix", () => {
  it("tenant roles match", () => {
    const expected = new Set(Object.entries(TENANT_ROLE_PERMISSIONS).flatMap(([r, ps]) => [...ps].map((p) => `${r}:${p}`)));
    expect(pairs("role_permissions")).toEqual(expected);
  });
  it("platform roles match", () => {
    const expected = new Set(Object.entries(PLATFORM_ROLE_PERMISSIONS).flatMap(([r, ps]) => [...ps].map((p) => `${r}:${p}`)));
    expect(pairs("platform_role_permissions")).toEqual(expected);
  });
});
