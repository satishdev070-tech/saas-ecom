# Implementation Status

_Last updated: 2026-09-25_

## Phase overview

| # | Phase | Status | Notes |
|---|-------|--------|-------|
| 0 | Repository audit | ✅ Done | Greenfield |
| 1 | Foundation | ✅ Done | Env, Supabase clients, host routing, permissions, errors, validation, UI primitives |
| 2 | Schema, RLS, storage, seed, types | ✅ Done | 13 migrations, RLS on every table, composite tenant FKs, storage buckets, seed |
| 3 | Auth & tenant | ✅ Done | Signup/login/magic link/reset, onboarding, invites, tenant switcher |
| 4 | Catalog | ✅ Done | Products + variants (option1–3), media, categories, collections (manual + rules), size charts, CSV import/export |
| 5 | Inventory | ✅ Done | Per-variant stock, adjustments ledger, thresholds, concurrency-safe reservation in `place_order` |
| 6 | Theme engine | ✅ Done | Theme config JSON, 23 section types, draft/publish/rollback, editor with live iframe preview |
| 7 | Storefront | ✅ Done | Home, listings with filters, PDP, search, pages, blog, FAQ, contact, stores, SEO, sitemap/robots |
| 8 | Checkout & orders | ✅ Done | Cart cookie, checkout, Razorpay + COD, webhook, order status, invoices, customer accounts |
| 9 | Seller dashboard | ✅ Done | Orders, returns, customers, discounts, reviews, content, analytics, settings, team, domains |
| 10 | Super admin | ✅ Done | `/admin` console (below) |
| 11 | Cloudflare / domains | ✅ Done | Custom domains + verification cron, `workers/domain-router` edge Worker |
| 12 | Hardening | 🟡 Partial | Rate limits, framing policy, secret redaction done; full CSP with nonces open (ADR-018) |
| 13 | Launch readiness | 🟡 Partial | CI workflow added; hosting target (ADR-011) and brand/domain (ADR-021) still to confirm |

## Verification (2026-09-25)

| Gate | Result |
|------|--------|
| `pnpm typecheck` | ✅ clean |
| `pnpm lint` (0 warnings) | ✅ clean |
| `pnpm test` (unit) | ✅ 22 files, 227 tests |
| `pnpm test:db` (RLS + SQL functions on Postgres 16) | ✅ 5 files, 71 tests; all 13 migrations apply from scratch |
| `pnpm build` | ✅ 70 routes; builds **without** runtime secrets |
| Runtime smoke (`next start`) | ✅ `/`, `/pricing`, `/features`, `/og`, `/privacy`, `/login` → 200; `/admin` → login redirect; store host → tenant lookup + 404 when unknown; framing headers correct per host |

Not verified here (needs a real Supabase project + Razorpay test keys): end-to-end checkout, webhook delivery, email sending, Cloudflare custom hostname API.

## What's in each area

### Storefront (`src/app/store/[host]/**`, `src/features/storefront`, `src/features/theme/render`)
Host-resolved tenant (verified `domains` row or signed edge header), theme tokens + section registry, header/footer/mega menu,
collection/category/search listings with filters and sort, PDP (gallery, zoom, size guide, variants, PIN check, reviews, recently viewed),
cart, checkout, pay (Razorpay/test), order confirmation + printable invoice, account (orders, addresses, wishlist), CMS pages, blog, FAQ,
contact, store locator, per-store sitemap/robots, redirects, suspended/preview states, event tracking.

### Seller dashboard (`src/app/dashboard/**`)
Products (editor, bulk, import/export), collections, categories, size charts, inventory, orders (fulfilment, cancel, refunds, invoices),
returns, customers (+export), discounts, reviews moderation, content (pages, blog, menus, FAQs, locations, redirects), analytics,
theme editor, domains, settings (store, shipping, PIN rules, COD, payments, taxes, notifications, team).

### Super admin (`src/app/admin/**`, `src/features/platform`)
Overview (stores, GMV, signups, trials ending, pending domains), tenants list/search/filter, tenant detail (status with reason + confirmation,
plan change, trial extension, usage vs plan limits, storage, domains + re-check, team, feature-flag overrides with effective source,
audit trail), create store for a user, plans CRUD (prices, limits, features), feature flags, platform users (roles/disable/remove),
platform-wide audit log with filters, platform settings, usage & storage, custom-domain overview, integration presence (booleans only),
**support sessions**: time-boxed, reason-required, audited, read-only view of a store's orders/products via RLS viewer grants.

### Marketing site (`src/app/(marketing)/**`, `src/features/marketing-site`)
Landing page (hero, demo-store preview with theme look switcher + device toggle, problem→solution, themes, builder, features, fashion
features, illustrative metrics, how it works, pricing with monthly/yearly toggle from live `plans`, FAQ, CTA), `/pricing`, `/features`,
`/privacy`, `/terms`, OG image route, JSON-LD (Organization, SoftwareApplication, FAQPage).

### Edge (`workers/domain-router`)
Cloudflare for SaaS Worker: strips client `x-paliya-*` headers, signs the customer host (HMAC-SHA256, 5-min window), proxies to the origin,
rewrites origin-host redirects, strips `x-middleware-rewrite`. Cross-tested against the app verifier.

## Security checklist

- Tenant never taken from the browser: storefront = verified host; dashboard = membership; admin = platform membership + permission.
- RLS on every table; composite `(tenant_id, id)` FKs; guard triggers block privileged column edits from `authenticated`.
- Service-role client limited to `lib/supabase/admin.ts` uses listed in ADR-006; `server-only` enforced.
- All inputs zod-validated (`parseInput`); PostgREST search terms sanitised; no raw SQL from input.
- Redirects via `safeRedirect`; storefront `[...rest]` uses stored redirects only.
- Webhooks: Razorpay HMAC verified; cron endpoints require `CRON_SECRET`.
- Uploads: MIME sniff + size limits per bucket; private bucket for invoices.
- Prices snapshotted into `order_items`; stock reserved atomically in `place_order`.
- Audit log for tenant admin actions, platform actions and support sessions.
- Framing: storefronts `frame-ancestors 'self' <platform origin>`; everything else `frame-ancestors 'self'` + `X-Frame-Options`.
- Rate limits (Postgres-backed) on login/OTP, signup, cart, checkout, account actions, storefront forms, invites, exports, support sessions and domain verification.
- Logs redact secrets/PII; admin integration page reports env presence only.

## Open risks / follow-ups

1. **Decisions needed:** ADR-011 hosting (Vercel vs Cloudflare/OpenNext), ADR-021 real brand + root domain.
2. Full CSP with nonces (script-src) not yet enabled — needs Razorpay checkout script allowance (ADR-018).
3. Storefront renders dynamically; Cache Components adoption deferred (ADR-010) — add CDN caching once hosting is chosen.
4. Suspended stores return 200 with an "unavailable" page (App Router layouts can't set 503).
5. Email/Shiprocket/Cloudflare adapters are implemented against their APIs but untested against live accounts.
6. Subscription billing for plans (charging sellers) is out of scope; plans are assigned by admins/onboarding.

## Running locally

```
cp .env.example .env.local        # fill Supabase + APP_SECRET
pnpm install
pnpm dev                          # platform: http://localhost:3000, stores: http://{slug}.localhost:3000
pnpm check                        # typecheck → lint → unit tests → build
pnpm test:db                      # local Postgres 16 + Supabase shim; applies migrations + seed, runs RLS tests
pnpm db:types                     # regenerate src/lib/supabase/database.types.ts from migrations
```
